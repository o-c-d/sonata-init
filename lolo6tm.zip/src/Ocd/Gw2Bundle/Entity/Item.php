<?php

namespace Ocd\Gw2Bundle\Entity;
 
use Doctrine\ORM\Mapping as ORM;

/**
 * GW2_Item
 * @ORM\Table(name="gw2_item")
 * @ORM\Entity(repositoryClass="Ocd\Gw2Bundle\Repository\ItemRepository")
 */
class Item
{
    /**
     * @ORM\Id
     * @ORM\Column(name="id", type="integer");
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
   private $id;

    /**
     * @ORM\Column(name="item_id", type="integer", unique=true)
     */
    private $item_id;

    /**
     * @ORM\Column(name="name", type="string", length=100)
     */
    private $name;

    /**
     * @ORM\Column(name="icon", type="string")
     */
    private $icon;

    /**
     * @ORM\Column(name="description", type="text", nullable=true)
     */
    private $description;

    /**
     * @ORM\Column(name="type", type="string", length=100)
     */
    private $type;

    /**
     * @ORM\Column(name="rarity", type="string", length=100, nullable=true)
     */
    private $rarity;

    /**
     * @ORM\Column(name="level", type="integer", nullable=true)
     */
    private $level;

    /**
     * @ORM\Column(name="vendor_value", type="integer", nullable=true)
     */
    private $vendor_value;

    /**
     * @ORM\Column(name="default_skin", type="integer", nullable=true)
     */
    private $default_skin;

    /**
     * @ORM\Column(name="flags", type="text", nullable=true)
     */
    private $flags;

    /**
     * @ORM\Column(name="game_types", type="text", nullable=true)
     */
    private $game_types;

    /**
     * @ORM\Column(name="restrictions", type="text", nullable=true)
     */
    private $restrictions;

    /**
     * @ORM\Column(name="details", type="text", nullable=true)
     */
    private $details;

    /**
     * @ORM\Column(name="recipe_id", type="integer", nullable=true)
     */
    private $recipe_id;

    /**
     * @ORM\Column(name="timemaj", type="integer")
     */
    private $timemaj;
	
	
	public function apiHydrator($api_item) {
			$this->setItemId($api_item->id) ;
			if(isset($api_item->name)) $this->setName($api_item->name) ;
			if(isset($api_item->icon)) $this->setIcon($api_item->icon) ;
			if(isset($api_item->description)) $this->setDescription($api_item->description) ;
			if(isset($api_item->type)) $this->setType($api_item->type) ;
			if(isset($api_item->rarity)) $this->setRarity($api_item->rarity) ;
			if(isset($api_item->level)) $this->setLevel($api_item->level) ;
			if(isset($api_item->vendor_value)) $this->setVendorValue($api_item->vendor_value) ;
			if(isset($api_item->default_skin)) $this->setDefaultSkin($api_item->default_skin) ;
			if(isset($api_item->flags)) $this->setFlags($api_item->flags) ;
			if(isset($api_item->game_types)) $this->setGameTypes($api_item->game_types) ;
			if(isset($api_item->restrictions)) $this->setRestrictions($api_item->restrictions) ;
			if(isset($api_item->details)) $this->setDetails($api_item->details) ;
			if(isset($api_item->recipe_id)) $this->setRecipeId($api_item->recipe_id) ;
			$this->setTimemaj(time()) ;
		
	}
	
	
    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set itemId
     *
     * @param integer $itemId
     *
     * @return GW2_Item
     */
    public function setItemId($itemId)
    {
        $this->item_id = $itemId;

        return $this;
    }

    /**
     * Get itemId
     *
     * @return integer
     */
    public function getItemId()
    {
        return $this->item_id;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return GW2_Item
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set icon
     *
     * @param string $icon
     *
     * @return GW2_Item
     */
    public function setIcon($icon)
    {
        $this->icon = $icon;

        return $this;
    }

    /**
     * Get icon
     *
     * @return string
     */
    public function getIcon()
    {
        return $this->icon;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return GW2_Item
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set type
     *
     * @param string $type
     *
     * @return GW2_Item
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set rarity
     *
     * @param string $rarity
     *
     * @return GW2_Item
     */
    public function setRarity($rarity)
    {
        $this->rarity = $rarity;

        return $this;
    }

    /**
     * Get rarity
     *
     * @return string
     */
    public function getRarity()
    {
        return $this->rarity;
    }

    /**
     * Set level
     *
     * @param integer $level
     *
     * @return GW2_Item
     */
    public function setLevel($level)
    {
        $this->level = $level;

        return $this;
    }

    /**
     * Get level
     *
     * @return integer
     */
    public function getLevel()
    {
        return $this->level;
    }

    /**
     * Set vendorValue
     *
     * @param integer $vendorValue
     *
     * @return GW2_Item
     */
    public function setVendorValue($vendorValue)
    {
        $this->vendor_value = $vendorValue;

        return $this;
    }

    /**
     * Get vendorValue
     *
     * @return integer
     */
    public function getVendorValue()
    {
        return $this->vendor_value;
    }

    /**
     * Set defaultSkin
     *
     * @param integer $defaultSkin
     *
     * @return GW2_Item
     */
    public function setDefaultSkin($defaultSkin)
    {
        $this->default_skin = $defaultSkin;

        return $this;
    }

    /**
     * Get defaultSkin
     *
     * @return integer
     */
    public function getDefaultSkin()
    {
        return $this->default_skin;
    }

    /**
     * Set flags
     *
     * @param string $flags
     *
     * @return GW2_Item
     */
    public function setFlags($flags)
    {
        $this->flags = $flags;

        return $this;
    }

    /**
     * Get flags
     *
     * @return string
     */
    public function getFlags()
    {
        return $this->flags;
    }

    /**
     * Set gameTypes
     *
     * @param string $gameTypes
     *
     * @return GW2_Item
     */
    public function setGameTypes($gameTypes)
    {
        $this->game_types = $gameTypes;

        return $this;
    }

    /**
     * Get gameTypes
     *
     * @return string
     */
    public function getGameTypes()
    {
        return $this->game_types;
    }

    /**
     * Set restrictions
     *
     * @param string $restrictions
     *
     * @return GW2_Item
     */
    public function setRestrictions($restrictions)
    {
        $this->restrictions = $restrictions;

        return $this;
    }

    /**
     * Get restrictions
     *
     * @return string
     */
    public function getRestrictions()
    {
        return $this->restrictions;
    }

    /**
     * Set details
     *
     * @param string $details
     *
     * @return GW2_Item
     */
    public function setDetails($details)
    {
        $this->details = $details;

        return $this;
    }

    /**
     * Get details
     *
     * @return string
     */
    public function getDetails()
    {
        return $this->details;
    }

    /**
     * Set recipeId
     *
     * @param integer $recipeId
     *
     * @return GW2_Item
     */
    public function setRecipeId($recipeId)
    {
        $this->recipe_id = $recipeId;

        return $this;
    }

    /**
     * Get recipeId
     *
     * @return integer
     */
    public function getRecipeId()
    {
        return $this->recipe_id;
    }

    /**
     * Set timemaj
     *
     * @param integer $timemaj
     *
     * @return GW2_Item
     */
    public function setTimemaj($timemaj)
    {
        $this->timemaj = $timemaj;

        return $this;
    }

    /**
     * Get timemaj
     *
     * @return integer
     */
    public function getTimemaj()
    {
        return $this->timemaj;
    }
}
