<?php

namespace Ocd\Gw2Bundle\Repository;

use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\Tools\Pagination\Paginator;

class ItemRepository extends EntityRepository
{
	
	public function getCountItems() {
		$count = $this->createQueryBuilder('i')->select('count(i)')->getQuery()->getSingleScalarResult();
		return $count ;
	}
	
	public function getLastItem() {
		$count = $this->createQueryBuilder('i')->select('max(i.item_id)')->getQuery()->getSingleScalarResult();
		return $count ;
	}
	
	public function getRaritiesList() {
		$rarities = $this->createQueryBuilder('i')->select('i.rarity')->groupBy('i.rarity')->getQuery()->getArrayResult();
		return $rarities ;
	}
	
	public function getTypesList() {
		$types = $this->createQueryBuilder('i')->select('i.type')->groupBy('i.type')->getQuery()->getArrayResult();
		return $types ;
	}
	
    /**
     * Get the paginated list of items
     *
     * @param int $page
     * @param int $maxperpage
     * @param string $sortby
     * @return Paginator
     */
    public function getList($page=1, $maxperpage=100, $filters=array())
    {
        $q = $this->createQueryBuilder('i')->select('i');
		if(isset($filters['type'])&&strlen($filters['type'])>0) $q->andWhere('i.type = \''.$filters['type'].'\'');
		if(isset($filters['rarity'])&&strlen($filters['rarity'])>0) $q->andWhere('i.rarity = \''.$filters['rarity'].'\'');
		$q->setFirstResult(($page-1) * $maxperpage)->setMaxResults($maxperpage)->getQuery()->getResult();
			return new Paginator($q);
    }

}