<?php

namespace Ocd\Gw2Bundle\Library ;

/**/
class OcdGw2ApiRequest {

    public function __construct()
    {
    }
   /**
   * Envoie une requete cUrl
   *
   * @param string $url
   * @return array
   */
   
   public function send_request($api_request_uri="") {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $api_request_uri);
	curl_setopt($ch, CURLOPT_CAINFO, __DIR__ . '/../Resources/cert/cacert.pem');
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	if( ! $body = curl_exec($ch)) echo (curl_error($ch));
	curl_close($ch);
	return $body ;
   }
   
   
  public function getAccountInfos($item_id=null)
  {
	if(null == $item_id) return false ;
	$api_uri = "https://api.guildwars2.com/v2/account?ids=".$item_id;
	$body = $this->send_request($api_uri) ;
	$item = json_decode($body) ;
    return $item ;
  }
   
  public function getAccountTokenInfos($item_id=null)
  {
	if(null == $item_id) return false ;
	$api_uri = "https://api.guildwars2.com/v2/token?ids=".$item_id;
	$body = $this->send_request($api_uri) ;
	$item = json_decode($body) ;
    return $item ;
  }
   
  public function getItem($item_id=null)
  {
	if(null == $item_id) return false ;
	$api_uri = "https://api.guildwars2.com/v2/items?ids=".$item_id;
	$body = $this->send_request($api_uri) ;
	$item = json_decode($body) ;
    return $item ;
  }
   
  public function listeItemsId($url="")
  {
	$api_uri = "https://api.guildwars2.com/v2/items.json";
	$body = $this->send_request($api_uri) ;
	$item_ids = json_decode($body) ;
    return $item_ids ;
  }
  
}