<?php
// src/Acme/BasicCmsBundle/Document/Site.php
namespace Ocd\CmsBundle\Document;

use Doctrine\ODM\PHPCR\Mapping\Annotations as PHPCR;

/**
 * @PHPCR\Document()
 */
class Site
{
    /**
     * @PHPCR\Id()
     */
    protected $id;

    /**
     * @PHPCR\Nodename()
     */
    protected $name;

    /**
     * @PHPCR\String(nullable=true)
     */
    protected $title;

    /**
     * @PHPCR\String(nullable=true)
     */
    protected $baseline;

    /**
     * @PHPCR\String(nullable=true)
     */
    protected $description;

    /**
     * @PHPCR\ReferenceOne(targetDocument="Ocd\CmsBundle\Document\Page")
     */
    protected $homepage;

    /**
     * @PHPCR\Children()
     */
    protected $children;
	
    public function getHomepage()
    {
        return $this->homepage;
    }

    public function setHomepage($homepage)
    {
        $this->homepage = $homepage;
    }

    public function getName()
    {
        return $this->name;
    }

    public function setName($name)
    {
        $this->name = $name;
    }

    public function getTitle()
    {
        return $this->title;
    }

    public function setTitle($title)
    {
        $this->title = $title;
    }

    public function getBaseline()
    {
        return $this->baseline;
    }

    public function setBaseline($baseline)
    {
        $this->baseline = $baseline;
    }

    public function getDescription()
    {
        return $this->description;
    }

    public function setDescription($description)
    {
        $this->description = $description;
    }

    public function setId($id)
    {
        $this->id = $id;
    }
    public function getChildren()
    {
        return $this->children;
    }
}