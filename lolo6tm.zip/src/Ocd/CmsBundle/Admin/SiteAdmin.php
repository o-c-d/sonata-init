<?php
// src/Ocd/CmsBundle/Admin/SiteAdmin.php
namespace Ocd\CmsBundle\Admin;

use Sonata\DoctrinePHPCRAdminBundle\Admin\Admin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;

class SiteAdmin extends Admin
{
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
            ->addIdentifier('name', 'text')
        ;
    }

    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('form.group_general')
            ->add('name', 'text')
            ->add('title', 'text')
            ->add('baseline', 'text')
            ->add('description', 'textarea')
            ->add('homepage', 'sonata_type_model_list', array())
        ->end();
    }

    public function prePersist($document)
    {
       // $parent = $this->getModelManager()->find(null, '/cms/pages');
       // $document->setParentDocument($parent);
    }

    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper->add('name', 'doctrine_phpcr_string');
    }

    public function getExportFormats()
    {
        return array();
    }
}