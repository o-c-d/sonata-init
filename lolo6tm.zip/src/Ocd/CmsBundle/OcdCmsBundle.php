<?php

namespace Ocd\CmsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OcdCmsBundle extends Bundle
{
}
