<?php

/* ApplicationSonataPageBundle::base_layout.html.twig */
class __TwigTemplate_cc5c9affc342614278d255db97f08d73fc725720140a930fb5003a0464a41d0e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'sonata_page_html_tag' => array($this, 'block_sonata_page_html_tag'),
            'sonata_page_head' => array($this, 'block_sonata_page_head'),
            'sonata_page_stylesheets' => array($this, 'block_sonata_page_stylesheets'),
            'page_stylesheets' => array($this, 'block_page_stylesheets'),
            'sonata_page_javascripts' => array($this, 'block_sonata_page_javascripts'),
            'page_javascripts' => array($this, 'block_page_javascripts'),
            'sonata_page_body_tag' => array($this, 'block_sonata_page_body_tag'),
            'sonata_page_top_bar' => array($this, 'block_sonata_page_top_bar'),
            'page_top_bar' => array($this, 'block_page_top_bar'),
            'sonata_page_container' => array($this, 'block_sonata_page_container'),
            'page_container' => array($this, 'block_page_container'),
            'sonata_page_asset_footer' => array($this, 'block_sonata_page_asset_footer'),
            'page_asset_footer' => array($this, 'block_page_asset_footer'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 11
        $this->displayBlock('sonata_page_html_tag', $context, $blocks);
        // line 15
        echo "    ";
        $this->displayBlock('sonata_page_head', $context, $blocks);
        // line 45
        echo "
    ";
        // line 46
        $this->displayBlock('sonata_page_body_tag', $context, $blocks);
        // line 49
        echo "
        ";
        // line 50
        $this->displayBlock('sonata_page_top_bar', $context, $blocks);
        // line 141
        echo "
        ";
        // line 142
        $this->displayBlock('sonata_page_container', $context, $blocks);
        // line 145
        echo "
        ";
        // line 146
        $this->displayBlock('sonata_page_asset_footer', $context, $blocks);
        // line 168
        echo "
        <!-- monitoring:3e9fda56df2cdd3b039f189693ab7844fbb2d4f6 -->
\t\t<!-- Google Analytics -->
\t\t<script>
\t\t(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
\t\t(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
\t\tm=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
\t\t})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

\t\tga('create', 'UA-116502-9', 'auto');
\t\tga('send', 'pageview');

\t\t</script>
\t\t<!-- End Google Analytics -->
    </body>
</html>
";
    }

    // line 11
    public function block_sonata_page_html_tag($context, array $blocks = array())
    {
        // line 12
        echo "<!DOCTYPE html>
<html ";
        // line 13
        echo $this->env->getExtension('sonata_seo')->getHtmlAttributes();
        echo ">
";
    }

    // line 15
    public function block_sonata_page_head($context, array $blocks = array())
    {
        // line 16
        echo "        <head ";
        echo $this->env->getExtension('sonata_seo')->getHeadAttributes();
        echo ">

            <!--[if IE]><meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\"><![endif]-->
            ";
        // line 19
        echo $this->env->getExtension('sonata_seo')->getTitle();
        echo "
            ";
        // line 20
        echo $this->env->getExtension('sonata_seo')->getMetadatas();
        echo "

            ";
        // line 22
        $this->displayBlock('sonata_page_stylesheets', $context, $blocks);
        // line 29
        echo "
            ";
        // line 30
        $this->displayBlock('sonata_page_javascripts', $context, $blocks);
        // line 43
        echo "        </head>
    ";
    }

    // line 22
    public function block_sonata_page_stylesheets($context, array $blocks = array())
    {
        // line 23
        echo "                ";
        $this->displayBlock('page_stylesheets', $context, $blocks);
        // line 28
        echo "            ";
    }

    // line 23
    public function block_page_stylesheets($context, array $blocks = array())
    {
        echo " ";
        // line 24
        echo "                    ";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["sonata_page"]) ? $context["sonata_page"] : null), "assets", array()), "stylesheets", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["stylesheet"]) {
            // line 25
            echo "                        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl($context["stylesheet"]), "html", null, true);
            echo "\" media=\"all\">
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['stylesheet'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        echo "                ";
    }

    // line 30
    public function block_sonata_page_javascripts($context, array $blocks = array())
    {
        // line 31
        echo "                ";
        $this->displayBlock('page_javascripts', $context, $blocks);
        // line 41
        echo "
            ";
    }

    // line 31
    public function block_page_javascripts($context, array $blocks = array())
    {
        echo " ";
        // line 32
        echo "                    <!-- Le HTML5 shim, for IE6-8 support of HTML elements -->
                    <!--[if lt IE 9]>
                        <script src=\"http://html5shim.googlecode.com/svn/trunk/html5.js\"></script>
                    <![endif]-->

                    ";
        // line 37
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["sonata_page"]) ? $context["sonata_page"] : null), "assets", array()), "javascripts", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["js"]) {
            // line 38
            echo "                        <script src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl($context["js"]), "html", null, true);
            echo "\"></script>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['js'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 40
        echo "                ";
    }

    // line 46
    public function block_sonata_page_body_tag($context, array $blocks = array())
    {
        // line 47
        echo "        <body class=\"sonata-bc\">
    ";
    }

    // line 50
    public function block_sonata_page_top_bar($context, array $blocks = array())
    {
        // line 51
        echo "            ";
        $this->displayBlock('page_top_bar', $context, $blocks);
        // line 140
        echo "        ";
    }

    // line 51
    public function block_page_top_bar($context, array $blocks = array())
    {
        echo " ";
        // line 52
        echo "                ";
        if (($this->getAttribute((isset($context["sonata_page"]) ? $context["sonata_page"] : null), "isEditor", array()) || (($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "security", array()) && $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "security", array()), "token", array())) && $this->env->getExtension('security')->isGranted("ROLE_PREVIOUS_ADMIN")))) {
            // line 53
            echo "
                    ";
            // line 54
            if (($this->getAttribute((isset($context["sonata_page"]) ? $context["sonata_page"] : null), "isEditor", array()) && $this->getAttribute((isset($context["sonata_page"]) ? $context["sonata_page"] : null), "isInlineEditionOn", array()))) {
                // line 55
                echo "                        <!-- CMS specific variables -->
                        <script>
                            jQuery(document).ready(function() {
                                Sonata.Page.init({
                                    url: {
                                        block_save_position: '";
                // line 60
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["sonata_admin"]) ? $context["sonata_admin"] : null), "objectUrl", array(0 => "sonata.page.admin.page", 1 => "edit", 2 => (isset($context["page"]) ? $context["page"] : null)), "method"), "html", null, true);
                echo "',
                                        block_edit:          '";
                // line 61
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["sonata_admin"]) ? $context["sonata_admin"] : null), "url", array(0 => "sonata.page.admin.page|sonata.page.admin.block", 1 => "edit", 2 => array("id" => $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "id", array()), "childId" => "BLOCK_ID")), "method"), "html", null, true);
                echo "'
                                    }
                                });
                            });
                        </script>
                    ";
            }
            // line 67
            echo "
                    <header class=\"sonata-bc sonata-page-top-bar navbar navbar-inverse navbar-fixed-top\" role=\"banner\">
                        <div class=\"container\">
                            <ul class=\"nav navbar-nav\">
                                ";
            // line 71
            if ((($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "security", array()) && $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "security", array()), "token", array())) && $this->env->getExtension('security')->isGranted("ROLE_SONATA_ADMIN"))) {
                // line 72
                echo "                                    <li><a href=\"";
                echo $this->env->getExtension('routing')->getPath("sonata_admin_dashboard");
                echo "\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("header.sonata_admin_dashboard", array(), "SonataPageBundle"), "html", null, true);
                echo "</a></li>
                                ";
            }
            // line 74
            echo "
                                ";
            // line 75
            if ($this->getAttribute((isset($context["sonata_page"]) ? $context["sonata_page"] : null), "isEditor", array())) {
                // line 76
                echo "                                    ";
                $context["sites"] = $this->getAttribute((isset($context["sonata_page"]) ? $context["sonata_page"] : null), "siteavailables", array());
                // line 77
                echo "
                                    ";
                // line 78
                if (((twig_length_filter($this->env, (isset($context["sites"]) ? $context["sites"] : null)) > 1) && array_key_exists("site", $context))) {
                    // line 79
                    echo "                                        <li class=\"dropdown\">
                                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">";
                    // line 80
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["site"]) ? $context["site"] : null), "name", array()), "html", null, true);
                    echo " <span class=\"caret\"></span></a>
                                            <ul class=\"dropdown-menu\">
                                                ";
                    // line 82
                    $context['_parent'] = (array) $context;
                    $context['_seq'] = twig_ensure_traversable((isset($context["sites"]) ? $context["sites"] : null));
                    foreach ($context['_seq'] as $context["_key"] => $context["site"]) {
                        // line 83
                        echo "                                                    <li><a href=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["site"], "url", array()), "html", null, true);
                        echo "\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["site"], "name", array()), "html", null, true);
                        echo "</a></li>
                                                ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['site'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 85
                    echo "                                            </ul>
                                        </li>
                                    ";
                }
                // line 88
                echo "
                                    <li class=\"dropdown\">
                                        <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">Page <span class=\"caret\"></span></a>
                                        <ul class=\"dropdown-menu\">
                                            ";
                // line 92
                if (array_key_exists("page", $context)) {
                    // line 93
                    echo "                                                <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["sonata_admin"]) ? $context["sonata_admin"] : null), "objectUrl", array(0 => "sonata.page.admin.page", 1 => "edit", 2 => (isset($context["page"]) ? $context["page"] : null)), "method"), "html", null, true);
                    echo "\" target=\"_new\">";
                    echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("header.edit_page", array(), "SonataPageBundle"), "html", null, true);
                    echo "</a></li>
                                                <li><a href=\"";
                    // line 94
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["sonata_admin"]) ? $context["sonata_admin"] : null), "objectUrl", array(0 => "sonata.page.admin.page|sonata.page.admin.snapshot", 1 => "list", 2 => (isset($context["page"]) ? $context["page"] : null)), "method"), "html", null, true);
                    echo "\" target=\"_new\">";
                    echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("header.create_snapshot", array(), "SonataPageBundle"), "html", null, true);
                    echo "</a></li>
                                                <li class=\"divider\"></li>
                                            ";
                }
                // line 97
                echo "
                                            <li><a href=\"";
                // line 98
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["sonata_admin"]) ? $context["sonata_admin"] : null), "url", array(0 => "sonata.page.admin.page", 1 => "list"), "method"), "html", null, true);
                echo "\" target=\"_new\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("header.view_all_pages", array(), "SonataPageBundle"), "html", null, true);
                echo "</a></li>

                                            ";
                // line 100
                if ((array_key_exists("error_codes", $context) && twig_length_filter($this->env, (isset($context["error_codes"]) ? $context["error_codes"] : null)))) {
                    // line 101
                    echo "                                                <li class=\"divider\"></li>
                                                <li><a href=\"";
                    // line 102
                    echo $this->env->getExtension('routing')->getPath("sonata_page_exceptions_list");
                    echo "\" target=\"_new\">";
                    echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("header.view_all_exceptions", array(), "SonataPageBundle"), "html", null, true);
                    echo "</a></li>
                                            ";
                }
                // line 104
                echo "                                        </ul>
                                    </li>

                                    ";
                // line 107
                if (array_key_exists("page", $context)) {
                    // line 108
                    echo "                                        <li>
                                            <a href=\"";
                    // line 109
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["sonata_admin"]) ? $context["sonata_admin"] : null), "url", array(0 => "sonata.page.admin.page", 1 => "compose", 2 => array("id" => $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "id", array()))), "method"), "html", null, true);
                    echo "\">
                                                <i class=\"fa fa-magic\"></i>
                                                ";
                    // line 111
                    echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("header.compose_page", array(), "SonataPageBundle"), "html", null, true);
                    echo "
                                            </a>
                                        </li>
                                    ";
                }
                // line 115
                echo "
                                    ";
                // line 116
                if ((array_key_exists("page", $context) &&  !$this->getAttribute((isset($context["page"]) ? $context["page"] : null), "enabled", array()))) {
                    // line 117
                    echo "                                        <li><span style=\"padding-left: 20px; background: red;\"><strong><em>";
                    echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("header.page_is_disabled", array(), "SonataPageBundle"), "html", null, true);
                    echo "</em></strong></span></li>
                                    ";
                }
                // line 119
                echo "
                                    ";
                // line 120
                if (($this->getAttribute((isset($context["sonata_page"]) ? $context["sonata_page"] : null), "isInlineEditionOn", array()) && array_key_exists("page", $context))) {
                    // line 121
                    echo "                                        <li>
                                            <form class=\"form-inline\" style=\"margin: 0px\">
                                                <label class=\"checkbox inline\" for=\"page-action-enabled-edit\"><input type=\"checkbox\" id=\"page-action-enabled-edit\">";
                    // line 123
                    echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("header.show_zone", array(), "SonataPageBundle"), "html", null, true);
                    echo "</label>
                                                <input type=\"submit\" class=\"btn\" value=\"";
                    // line 124
                    echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("btn_save_position", array(), "SonataPageBundle"), "html", null, true);
                    echo "\" id=\"page-action-save-position\">
                                            </form>
                                        </li>
                                    ";
                }
                // line 128
                echo "                                ";
            }
            // line 129
            echo "
                                ";
            // line 130
            if ((($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "security", array()) && $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "security", array()), "token", array())) && $this->env->getExtension('security')->isGranted("ROLE_PREVIOUS_ADMIN"))) {
                // line 131
                echo "                                    <li><a href=\"";
                echo $this->env->getExtension('routing')->getUrl("homepage", array("_switch_user" => "_exit"));
                echo "\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("header.switch_user_exit", array(), "SonataPageBundle"), "html", null, true);
                echo "</a></li>
                                ";
            }
            // line 133
            echo "
                            </ul>
                        </div>
                    </header>

                ";
        }
        // line 139
        echo "            ";
    }

    // line 142
    public function block_sonata_page_container($context, array $blocks = array())
    {
        // line 143
        echo "            ";
        $this->displayBlock('page_container', $context, $blocks);
        echo " ";
        // line 144
        echo "        ";
    }

    // line 143
    public function block_page_container($context, array $blocks = array())
    {
    }

    // line 146
    public function block_sonata_page_asset_footer($context, array $blocks = array())
    {
        // line 147
        echo "            ";
        $this->displayBlock('page_asset_footer', $context, $blocks);
        // line 167
        echo "        ";
    }

    // line 147
    public function block_page_asset_footer($context, array $blocks = array())
    {
        echo " ";
        // line 148
        echo "                ";
        if (array_key_exists("page", $context)) {
            // line 149
            echo "                    ";
            if ( !twig_test_empty($this->getAttribute((isset($context["page"]) ? $context["page"] : null), "javascript", array()))) {
                // line 150
                echo "                        <script>
                            ";
                // line 151
                echo $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "javascript", array());
                echo "
                        </script>
                    ";
            }
            // line 154
            echo "                    ";
            if ( !twig_test_empty($this->getAttribute((isset($context["page"]) ? $context["page"] : null), "stylesheet", array()))) {
                // line 155
                echo "                        <style>
                            ";
                // line 156
                echo $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "stylesheet", array());
                echo "
                        </style>
                    ";
            }
            // line 159
            echo "                ";
        }
        // line 160
        echo "                ";
        // line 164
        echo "                ";
        echo call_user_func_array($this->env->getFunction('sonata_block_include_stylesheets')->getCallable(), array("screen", $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "basePath", array())));
        echo "
                ";
        // line 165
        echo call_user_func_array($this->env->getFunction('sonata_block_include_javascripts')->getCallable(), array("screen", $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "basePath", array())));
        echo "
            ";
    }

    public function getTemplateName()
    {
        return "ApplicationSonataPageBundle::base_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  491 => 165,  486 => 164,  484 => 160,  481 => 159,  475 => 156,  472 => 155,  469 => 154,  463 => 151,  460 => 150,  457 => 149,  454 => 148,  450 => 147,  446 => 167,  443 => 147,  440 => 146,  435 => 143,  431 => 144,  427 => 143,  424 => 142,  420 => 139,  412 => 133,  404 => 131,  402 => 130,  399 => 129,  396 => 128,  389 => 124,  385 => 123,  381 => 121,  379 => 120,  376 => 119,  370 => 117,  368 => 116,  365 => 115,  358 => 111,  353 => 109,  350 => 108,  348 => 107,  343 => 104,  336 => 102,  333 => 101,  331 => 100,  324 => 98,  321 => 97,  313 => 94,  306 => 93,  304 => 92,  298 => 88,  293 => 85,  282 => 83,  278 => 82,  273 => 80,  270 => 79,  268 => 78,  265 => 77,  262 => 76,  260 => 75,  257 => 74,  249 => 72,  247 => 71,  241 => 67,  232 => 61,  228 => 60,  221 => 55,  219 => 54,  216 => 53,  213 => 52,  209 => 51,  205 => 140,  202 => 51,  199 => 50,  194 => 47,  191 => 46,  187 => 40,  178 => 38,  174 => 37,  167 => 32,  163 => 31,  158 => 41,  155 => 31,  152 => 30,  148 => 27,  139 => 25,  134 => 24,  130 => 23,  126 => 28,  123 => 23,  120 => 22,  115 => 43,  113 => 30,  110 => 29,  108 => 22,  103 => 20,  99 => 19,  92 => 16,  89 => 15,  83 => 13,  80 => 12,  77 => 11,  57 => 168,  55 => 146,  52 => 145,  50 => 142,  47 => 141,  45 => 50,  42 => 49,  40 => 46,  37 => 45,  34 => 15,  32 => 11,);
    }
}
