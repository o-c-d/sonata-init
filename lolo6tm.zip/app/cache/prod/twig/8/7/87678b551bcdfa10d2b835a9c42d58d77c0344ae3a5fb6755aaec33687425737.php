<?php

/* ApplicationSonataPageBundle::2columns_layout.html.twig */
class __TwigTemplate_87678b551bcdfa10d2b835a9c42d58d77c0344ae3a5fb6755aaec33687425737 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 12
        $this->parent = $this->loadTemplate("ApplicationSonataPageBundle::layout.html.twig", "ApplicationSonataPageBundle::2columns_layout.html.twig", 12);
        $this->blocks = array(
            'page_content' => array($this, 'block_page_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "ApplicationSonataPageBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 14
    public function block_page_content($context, array $blocks = array())
    {
        // line 15
        echo "    ";
        if (array_key_exists("page", $context)) {
            // line 16
            echo "        <div class=\"col-md-6\">
            ";
            // line 17
            if (($this->getAttribute((isset($context["page"]) ? $context["page"] : null), "name", array()) != "global")) {
                // line 18
                echo "                ";
                echo $this->env->getExtension('sonata_page')->renderContainer("left_col", "global");
                echo "
            ";
            }
            // line 20
            echo "            ";
            echo $this->env->getExtension('sonata_page')->renderContainer("left_col", (isset($context["page"]) ? $context["page"] : null));
            echo "
        </div>
        <div class=\"col-md-6\">
            ";
            // line 23
            if (($this->getAttribute((isset($context["page"]) ? $context["page"] : null), "name", array()) != "global")) {
                // line 24
                echo "                ";
                echo $this->env->getExtension('sonata_page')->renderContainer("right_col", "global");
                echo "
            ";
            }
            // line 26
            echo "            ";
            echo $this->env->getExtension('sonata_page')->renderContainer("right_col", (isset($context["page"]) ? $context["page"] : null));
            echo "
        </div>
        <div style=\"clear: both\"></div>
    ";
        }
        // line 30
        echo "
    ";
        // line 31
        $this->displayParentBlock("page_content", $context, $blocks);
        echo "

";
    }

    public function getTemplateName()
    {
        return "ApplicationSonataPageBundle::2columns_layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  71 => 31,  68 => 30,  60 => 26,  54 => 24,  52 => 23,  45 => 20,  39 => 18,  37 => 17,  34 => 16,  31 => 15,  28 => 14,  11 => 12,);
    }
}
