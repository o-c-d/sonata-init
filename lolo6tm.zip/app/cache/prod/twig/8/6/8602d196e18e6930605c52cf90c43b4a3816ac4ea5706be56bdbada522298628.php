<?php

/* SonataPageBundle:Block:block_container.html.twig */
class __TwigTemplate_8602d196e18e6930605c52cf90c43b4a3816ac4ea5706be56bdbada522298628 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 12
        $this->parent = $this->loadTemplate("SonataBlockBundle:Block:block_container.html.twig", "SonataPageBundle:Block:block_container.html.twig", 12);
        $this->blocks = array(
            'block_child_render' => array($this, 'block_block_child_render'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "SonataBlockBundle:Block:block_container.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 14
    public function block_block_child_render($context, array $blocks = array())
    {
        // line 15
        echo "    ";
        echo $this->env->getExtension('sonata_page')->renderBlock((isset($context["child"]) ? $context["child"] : null));
        echo "
";
    }

    public function getTemplateName()
    {
        return "SonataPageBundle:Block:block_container.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 15,  28 => 14,  11 => 12,);
    }
}
