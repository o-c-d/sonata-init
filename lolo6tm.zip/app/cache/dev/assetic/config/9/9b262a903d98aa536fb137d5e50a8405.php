<?php

// OcdCorporateBundle:Nouveau dossier:layout.html.twig
return array (
  '7fdef9b' => 
  array (
    0 => 
    array (
      0 => 'bundles/ocdcorporate/css/html5_boilerplate.css',
      1 => 'bundles/ocdcorporate/css/bootstrap.min.css',
      2 => 'bundles/ocdcorporate/css/bootstrap-responsive.min.css',
      3 => 'bundles/ocdcorporate/css/font-awesome.min.css',
      4 => 'bundles/ocdcorporate/css/main_layout.css',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/css/7fdef9b.css',
      'name' => '7fdef9b',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  'b24e3bf' => 
  array (
    0 => 
    array (
      0 => '@OcdCorporateBundle/Resources/public/js/jquery-2.1.4.min.js',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/js/b24e3bf.js',
      'name' => 'b24e3bf',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '2f80f34' => 
  array (
    0 => 
    array (
      0 => '@OcdCorporateBundle/Resources/public/js/bootstrap.js',
      1 => '@OcdCorporateBundle/Resources/public/js/corporate.js',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/js/2f80f34.js',
      'name' => '2f80f34',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
