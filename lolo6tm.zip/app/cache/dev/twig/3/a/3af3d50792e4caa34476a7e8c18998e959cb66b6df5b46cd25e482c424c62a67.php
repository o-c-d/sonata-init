<?php

/* SonataBlockBundle:Block:block_core_menu.html.twig */
class __TwigTemplate_3af3d50792e4caa34476a7e8c18998e959cb66b6df5b46cd25e482c424c62a67 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'block' => array($this, 'block_block'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 12
        return $this->loadTemplate($this->getAttribute($this->getAttribute((isset($context["sonata_block"]) ? $context["sonata_block"] : $this->getContext($context, "sonata_block")), "templates", array()), "block_base", array()), "SonataBlockBundle:Block:block_core_menu.html.twig", 12);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_56cfbc12cab720ed2f04fbb9afea1ebf9cd9ac1bf4b6488718c66447552fed61 = $this->env->getExtension("native_profiler");
        $__internal_56cfbc12cab720ed2f04fbb9afea1ebf9cd9ac1bf4b6488718c66447552fed61->enter($__internal_56cfbc12cab720ed2f04fbb9afea1ebf9cd9ac1bf4b6488718c66447552fed61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataBlockBundle:Block:block_core_menu.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_56cfbc12cab720ed2f04fbb9afea1ebf9cd9ac1bf4b6488718c66447552fed61->leave($__internal_56cfbc12cab720ed2f04fbb9afea1ebf9cd9ac1bf4b6488718c66447552fed61_prof);

    }

    // line 14
    public function block_block($context, array $blocks = array())
    {
        $__internal_ec5e10f4ae861ac8db0cbbb85c7f19dcea04730a8f29462acac248a254c511d5 = $this->env->getExtension("native_profiler");
        $__internal_ec5e10f4ae861ac8db0cbbb85c7f19dcea04730a8f29462acac248a254c511d5->enter($__internal_ec5e10f4ae861ac8db0cbbb85c7f19dcea04730a8f29462acac248a254c511d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "block"));

        // line 15
        echo "    ";
        echo $this->env->getExtension('knp_menu')->render((isset($context["menu"]) ? $context["menu"] : $this->getContext($context, "menu")), (isset($context["menu_options"]) ? $context["menu_options"] : $this->getContext($context, "menu_options")));
        echo "
";
        
        $__internal_ec5e10f4ae861ac8db0cbbb85c7f19dcea04730a8f29462acac248a254c511d5->leave($__internal_ec5e10f4ae861ac8db0cbbb85c7f19dcea04730a8f29462acac248a254c511d5_prof);

    }

    public function getTemplateName()
    {
        return "SonataBlockBundle:Block:block_core_menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  39 => 15,  33 => 14,  18 => 12,);
    }
}
