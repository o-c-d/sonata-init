<?php

/* SonataSeoBundle:Block:_facebook_sdk.html.twig */
class __TwigTemplate_8cd795ffc2a369f0d0893d086460128a8552b6408a7f41d8dca26f23ae708c41 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'facebook_sdk' => array($this, 'block_facebook_sdk'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3a7ecaae2d734fd4cde71e4f3b5221f2ce5238c14d34b7af9efb79dc5d691a23 = $this->env->getExtension("native_profiler");
        $__internal_3a7ecaae2d734fd4cde71e4f3b5221f2ce5238c14d34b7af9efb79dc5d691a23->enter($__internal_3a7ecaae2d734fd4cde71e4f3b5221f2ce5238c14d34b7af9efb79dc5d691a23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataSeoBundle:Block:_facebook_sdk.html.twig"));

        // line 11
        $this->displayBlock('facebook_sdk', $context, $blocks);
        
        $__internal_3a7ecaae2d734fd4cde71e4f3b5221f2ce5238c14d34b7af9efb79dc5d691a23->leave($__internal_3a7ecaae2d734fd4cde71e4f3b5221f2ce5238c14d34b7af9efb79dc5d691a23_prof);

    }

    public function block_facebook_sdk($context, array $blocks = array())
    {
        $__internal_1b49dad7cce954f7b51791f1579ec1f7a2cfd76b195b1d4c3bd55a8a58591a3c = $this->env->getExtension("native_profiler");
        $__internal_1b49dad7cce954f7b51791f1579ec1f7a2cfd76b195b1d4c3bd55a8a58591a3c->enter($__internal_1b49dad7cce954f7b51791f1579ec1f7a2cfd76b195b1d4c3bd55a8a58591a3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "facebook_sdk"));

        // line 12
        ob_start();
        // line 13
        echo "
    <div id=\"fb-root\"></div>
    <script>(function(d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s); js.id = id;
            js.src = \"//connect.facebook.net/en_US/all.js#xfbml=1\";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));
    </script>

";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_1b49dad7cce954f7b51791f1579ec1f7a2cfd76b195b1d4c3bd55a8a58591a3c->leave($__internal_1b49dad7cce954f7b51791f1579ec1f7a2cfd76b195b1d4c3bd55a8a58591a3c_prof);

    }

    public function getTemplateName()
    {
        return "SonataSeoBundle:Block:_facebook_sdk.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 13,  35 => 12,  23 => 11,);
    }
}
