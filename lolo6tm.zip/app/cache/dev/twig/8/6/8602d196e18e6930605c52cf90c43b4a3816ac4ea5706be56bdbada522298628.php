<?php

/* SonataPageBundle:Block:block_container.html.twig */
class __TwigTemplate_8602d196e18e6930605c52cf90c43b4a3816ac4ea5706be56bdbada522298628 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 12
        $this->parent = $this->loadTemplate("SonataBlockBundle:Block:block_container.html.twig", "SonataPageBundle:Block:block_container.html.twig", 12);
        $this->blocks = array(
            'block_child_render' => array($this, 'block_block_child_render'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "SonataBlockBundle:Block:block_container.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_61e34f841bee71d6e4a34e1f87bc5eeba914f5e06703def1d634b36d32a8764e = $this->env->getExtension("native_profiler");
        $__internal_61e34f841bee71d6e4a34e1f87bc5eeba914f5e06703def1d634b36d32a8764e->enter($__internal_61e34f841bee71d6e4a34e1f87bc5eeba914f5e06703def1d634b36d32a8764e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataPageBundle:Block:block_container.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_61e34f841bee71d6e4a34e1f87bc5eeba914f5e06703def1d634b36d32a8764e->leave($__internal_61e34f841bee71d6e4a34e1f87bc5eeba914f5e06703def1d634b36d32a8764e_prof);

    }

    // line 14
    public function block_block_child_render($context, array $blocks = array())
    {
        $__internal_24d8667c9d02a3f6aca9a325c94134f6b50aebdc4f53b4e22369d949e2a5d8ad = $this->env->getExtension("native_profiler");
        $__internal_24d8667c9d02a3f6aca9a325c94134f6b50aebdc4f53b4e22369d949e2a5d8ad->enter($__internal_24d8667c9d02a3f6aca9a325c94134f6b50aebdc4f53b4e22369d949e2a5d8ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "block_child_render"));

        // line 15
        echo "    ";
        echo $this->env->getExtension('sonata_page')->renderBlock((isset($context["child"]) ? $context["child"] : $this->getContext($context, "child")));
        echo "
";
        
        $__internal_24d8667c9d02a3f6aca9a325c94134f6b50aebdc4f53b4e22369d949e2a5d8ad->leave($__internal_24d8667c9d02a3f6aca9a325c94134f6b50aebdc4f53b4e22369d949e2a5d8ad_prof);

    }

    public function getTemplateName()
    {
        return "SonataPageBundle:Block:block_container.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 15,  34 => 14,  11 => 12,);
    }
}
