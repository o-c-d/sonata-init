<?php

/* SonataBlockBundle:Block:block_core_text.html.twig */
class __TwigTemplate_8766b6ba162c343d53e4db4aa012fb3ca2efebc4ae29a298cfa0d9f745cbd07c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'block' => array($this, 'block_block'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 12
        return $this->loadTemplate($this->getAttribute($this->getAttribute((isset($context["sonata_block"]) ? $context["sonata_block"] : $this->getContext($context, "sonata_block")), "templates", array()), "block_base", array()), "SonataBlockBundle:Block:block_core_text.html.twig", 12);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d184e4b30fad8b9442f12568a1ac17ac56d4f3839c8e411719ecaaca2f3475ab = $this->env->getExtension("native_profiler");
        $__internal_d184e4b30fad8b9442f12568a1ac17ac56d4f3839c8e411719ecaaca2f3475ab->enter($__internal_d184e4b30fad8b9442f12568a1ac17ac56d4f3839c8e411719ecaaca2f3475ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataBlockBundle:Block:block_core_text.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d184e4b30fad8b9442f12568a1ac17ac56d4f3839c8e411719ecaaca2f3475ab->leave($__internal_d184e4b30fad8b9442f12568a1ac17ac56d4f3839c8e411719ecaaca2f3475ab_prof);

    }

    // line 14
    public function block_block($context, array $blocks = array())
    {
        $__internal_7bfc87be29c18b52ae1e3313cb88db59670823992ca26ff94b30f297b95c0aca = $this->env->getExtension("native_profiler");
        $__internal_7bfc87be29c18b52ae1e3313cb88db59670823992ca26ff94b30f297b95c0aca->enter($__internal_7bfc87be29c18b52ae1e3313cb88db59670823992ca26ff94b30f297b95c0aca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "block"));

        // line 15
        echo "    ";
        echo $this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "content", array());
        echo "
";
        
        $__internal_7bfc87be29c18b52ae1e3313cb88db59670823992ca26ff94b30f297b95c0aca->leave($__internal_7bfc87be29c18b52ae1e3313cb88db59670823992ca26ff94b30f297b95c0aca_prof);

    }

    public function getTemplateName()
    {
        return "SonataBlockBundle:Block:block_core_text.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  39 => 15,  33 => 14,  18 => 12,);
    }
}
