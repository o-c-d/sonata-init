<?php

/* ApplicationSonataPageBundle::2columns_layout.html.twig */
class __TwigTemplate_87678b551bcdfa10d2b835a9c42d58d77c0344ae3a5fb6755aaec33687425737 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 12
        $this->parent = $this->loadTemplate("ApplicationSonataPageBundle::layout.html.twig", "ApplicationSonataPageBundle::2columns_layout.html.twig", 12);
        $this->blocks = array(
            'page_content' => array($this, 'block_page_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "ApplicationSonataPageBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7744cb8a25f717dbea446de64922a60b85f6fd446e1e88270f070fa3480a238e = $this->env->getExtension("native_profiler");
        $__internal_7744cb8a25f717dbea446de64922a60b85f6fd446e1e88270f070fa3480a238e->enter($__internal_7744cb8a25f717dbea446de64922a60b85f6fd446e1e88270f070fa3480a238e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ApplicationSonataPageBundle::2columns_layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7744cb8a25f717dbea446de64922a60b85f6fd446e1e88270f070fa3480a238e->leave($__internal_7744cb8a25f717dbea446de64922a60b85f6fd446e1e88270f070fa3480a238e_prof);

    }

    // line 14
    public function block_page_content($context, array $blocks = array())
    {
        $__internal_3bd13f8e2dddb3f4d6590458b7d37f75062bd389ea4e3d249a6a1ee4e922fa5f = $this->env->getExtension("native_profiler");
        $__internal_3bd13f8e2dddb3f4d6590458b7d37f75062bd389ea4e3d249a6a1ee4e922fa5f->enter($__internal_3bd13f8e2dddb3f4d6590458b7d37f75062bd389ea4e3d249a6a1ee4e922fa5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        // line 15
        echo "    ";
        if (array_key_exists("page", $context)) {
            // line 16
            echo "        <div class=\"col-md-6\">
            ";
            // line 17
            if (($this->getAttribute((isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")), "name", array()) != "global")) {
                // line 18
                echo "                ";
                echo $this->env->getExtension('sonata_page')->renderContainer("left_col", "global");
                echo "
            ";
            }
            // line 20
            echo "            ";
            echo $this->env->getExtension('sonata_page')->renderContainer("left_col", (isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")));
            echo "
        </div>
        <div class=\"col-md-6\">
            ";
            // line 23
            if (($this->getAttribute((isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")), "name", array()) != "global")) {
                // line 24
                echo "                ";
                echo $this->env->getExtension('sonata_page')->renderContainer("right_col", "global");
                echo "
            ";
            }
            // line 26
            echo "            ";
            echo $this->env->getExtension('sonata_page')->renderContainer("right_col", (isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")));
            echo "
        </div>
        <div style=\"clear: both\"></div>
    ";
        }
        // line 30
        echo "
    ";
        // line 31
        $this->displayParentBlock("page_content", $context, $blocks);
        echo "

";
        
        $__internal_3bd13f8e2dddb3f4d6590458b7d37f75062bd389ea4e3d249a6a1ee4e922fa5f->leave($__internal_3bd13f8e2dddb3f4d6590458b7d37f75062bd389ea4e3d249a6a1ee4e922fa5f_prof);

    }

    public function getTemplateName()
    {
        return "ApplicationSonataPageBundle::2columns_layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 31,  77 => 30,  69 => 26,  63 => 24,  61 => 23,  54 => 20,  48 => 18,  46 => 17,  43 => 16,  40 => 15,  34 => 14,  11 => 12,);
    }
}
