<?php

/* SonataPageBundle:Block:block_base.html.twig */
class __TwigTemplate_77418dea8db1ac722a75b2d4ac73f24001316802ca4020ca03d56f587c60469b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'block_class' => array($this, 'block_block_class'),
            'block_role' => array($this, 'block_block_role'),
            'block' => array($this, 'block_block'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fcc06bf2f9f0153cd7721f02e380cc84d8dcc3ba0320e269e6585ead810af6b7 = $this->env->getExtension("native_profiler");
        $__internal_fcc06bf2f9f0153cd7721f02e380cc84d8dcc3ba0320e269e6585ead810af6b7->enter($__internal_fcc06bf2f9f0153cd7721f02e380cc84d8dcc3ba0320e269e6585ead810af6b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataPageBundle:Block:block_base.html.twig"));

        // line 11
        echo "
";
        // line 12
        if ($this->getAttribute((isset($context["sonata_page"]) ? $context["sonata_page"] : $this->getContext($context, "sonata_page")), "isInlineEditionOn", array())) {
            // line 13
            echo "    <div id=\"cms-block-";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["block"]) ? $context["block"] : $this->getContext($context, "block")), "id", array()), "html", null, true);
            echo "\"
         class=\"cms-block";
            // line 14
            if ($this->getAttribute((isset($context["block"]) ? $context["block"] : $this->getContext($context, "block")), "hasParent", array(), "method")) {
                echo " cms-block-element";
            }
            $this->displayBlock('block_class', $context, $blocks);
            echo "\"
        ";
            // line 15
            if (($this->getAttribute((isset($context["sonata_page"]) ? $context["sonata_page"] : $this->getContext($context, "sonata_page")), "isEditor", array()) && $this->getAttribute((isset($context["block"]) ? $context["block"] : null), "page", array(), "any", true, true))) {
                // line 16
                echo "            data-id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["block"]) ? $context["block"] : $this->getContext($context, "block")), "id", array()), "html", null, true);
                echo "\"
            data-name=\"";
                // line 17
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["block"]) ? $context["block"] : $this->getContext($context, "block")), "name", array()), "html", null, true);
                echo "\"
            data-role=\"";
                // line 18
                $this->displayBlock('block_role', $context, $blocks);
                echo "\"
            data-page-id=\"";
                // line 19
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["block"]) ? $context["block"] : $this->getContext($context, "block")), "page", array()), "id", array()), "html", null, true);
                echo "\"
        ";
            }
            // line 21
            echo "        >
";
        } elseif ($this->getAttribute(        // line 22
(isset($context["sonata_page"]) ? $context["sonata_page"] : $this->getContext($context, "sonata_page")), "isEditor", array(), "method")) {
            // line 23
            echo "    <!-- start rendering, block.id: ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["block"]) ? $context["block"] : $this->getContext($context, "block")), "id", array()), "html", null, true);
            echo " - page.id: ";
            if ($this->getAttribute((isset($context["block"]) ? $context["block"] : null), "page", array(), "any", true, true)) {
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["block"]) ? $context["block"] : $this->getContext($context, "block")), "page", array()), "id", array()), "html", null, true);
            } else {
                echo "no related page";
            }
            echo " - name: ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["block"]) ? $context["block"] : $this->getContext($context, "block")), "name", array()), "html", null, true);
            echo " -->
";
        }
        // line 25
        echo "
";
        // line 26
        $this->displayBlock('block', $context, $blocks);
        // line 27
        echo "
";
        // line 28
        if ($this->getAttribute((isset($context["sonata_page"]) ? $context["sonata_page"] : $this->getContext($context, "sonata_page")), "isInlineEditionOn", array())) {
            // line 29
            echo "    </div>
";
        } elseif ($this->getAttribute(        // line 30
(isset($context["sonata_page"]) ? $context["sonata_page"] : $this->getContext($context, "sonata_page")), "isEditor", array(), "method")) {
            // line 31
            echo "    <!-- end rendering, block.id: ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["block"]) ? $context["block"] : $this->getContext($context, "block")), "id", array()), "html", null, true);
            echo " - page.id: ";
            if ($this->getAttribute((isset($context["block"]) ? $context["block"] : null), "page", array(), "any", true, true)) {
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["block"]) ? $context["block"] : $this->getContext($context, "block")), "page", array()), "id", array()), "html", null, true);
            } else {
                echo "no related page";
            }
            echo "  - name: ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["block"]) ? $context["block"] : $this->getContext($context, "block")), "name", array()), "html", null, true);
            echo " -->
";
        }
        
        $__internal_fcc06bf2f9f0153cd7721f02e380cc84d8dcc3ba0320e269e6585ead810af6b7->leave($__internal_fcc06bf2f9f0153cd7721f02e380cc84d8dcc3ba0320e269e6585ead810af6b7_prof);

    }

    // line 14
    public function block_block_class($context, array $blocks = array())
    {
        $__internal_bf641446246f2f0ab6e71a5b302bf59bdbcbfffd4cb6e984712d85611e03de4f = $this->env->getExtension("native_profiler");
        $__internal_bf641446246f2f0ab6e71a5b302bf59bdbcbfffd4cb6e984712d85611e03de4f->enter($__internal_bf641446246f2f0ab6e71a5b302bf59bdbcbfffd4cb6e984712d85611e03de4f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "block_class"));

        
        $__internal_bf641446246f2f0ab6e71a5b302bf59bdbcbfffd4cb6e984712d85611e03de4f->leave($__internal_bf641446246f2f0ab6e71a5b302bf59bdbcbfffd4cb6e984712d85611e03de4f_prof);

    }

    // line 18
    public function block_block_role($context, array $blocks = array())
    {
        $__internal_68797bfcb25a04890fb118bc4cc54c16e40b8aca83bf49c1dfb1aa6a1bc73c9d = $this->env->getExtension("native_profiler");
        $__internal_68797bfcb25a04890fb118bc4cc54c16e40b8aca83bf49c1dfb1aa6a1bc73c9d->enter($__internal_68797bfcb25a04890fb118bc4cc54c16e40b8aca83bf49c1dfb1aa6a1bc73c9d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "block_role"));

        echo "block";
        
        $__internal_68797bfcb25a04890fb118bc4cc54c16e40b8aca83bf49c1dfb1aa6a1bc73c9d->leave($__internal_68797bfcb25a04890fb118bc4cc54c16e40b8aca83bf49c1dfb1aa6a1bc73c9d_prof);

    }

    // line 26
    public function block_block($context, array $blocks = array())
    {
        $__internal_40fb5233ab76dcce5ff09a3fa6562d249cc49009fb2dddcb2e22c32f7fce0247 = $this->env->getExtension("native_profiler");
        $__internal_40fb5233ab76dcce5ff09a3fa6562d249cc49009fb2dddcb2e22c32f7fce0247->enter($__internal_40fb5233ab76dcce5ff09a3fa6562d249cc49009fb2dddcb2e22c32f7fce0247_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "block"));

        echo "EMPTY CONTENT";
        
        $__internal_40fb5233ab76dcce5ff09a3fa6562d249cc49009fb2dddcb2e22c32f7fce0247->leave($__internal_40fb5233ab76dcce5ff09a3fa6562d249cc49009fb2dddcb2e22c32f7fce0247_prof);

    }

    public function getTemplateName()
    {
        return "SonataPageBundle:Block:block_base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 26,  126 => 18,  115 => 14,  96 => 31,  94 => 30,  91 => 29,  89 => 28,  86 => 27,  84 => 26,  81 => 25,  67 => 23,  65 => 22,  62 => 21,  57 => 19,  53 => 18,  49 => 17,  44 => 16,  42 => 15,  35 => 14,  30 => 13,  28 => 12,  25 => 11,);
    }
}
