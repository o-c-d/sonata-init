<?php

/* ApplicationSonataPageBundle::layout.html.twig */
class __TwigTemplate_e9cb127842960606bff0ed023d93fec65a0975ce6c63a67a4a347b7aea54ce16 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 11
        $this->parent = $this->loadTemplate("ApplicationSonataPageBundle::base_layout.html.twig", "ApplicationSonataPageBundle::layout.html.twig", 11);
        $this->blocks = array(
            'sonata_page_container' => array($this, 'block_sonata_page_container'),
            'sonata_page_breadcrumb' => array($this, 'block_sonata_page_breadcrumb'),
            'page_content' => array($this, 'block_page_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "ApplicationSonataPageBundle::base_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f6b33a5ed12592b5722ad1412d41f60737c1718cb06772cd7d5f2195e2a96b8b = $this->env->getExtension("native_profiler");
        $__internal_f6b33a5ed12592b5722ad1412d41f60737c1718cb06772cd7d5f2195e2a96b8b->enter($__internal_f6b33a5ed12592b5722ad1412d41f60737c1718cb06772cd7d5f2195e2a96b8b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ApplicationSonataPageBundle::layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f6b33a5ed12592b5722ad1412d41f60737c1718cb06772cd7d5f2195e2a96b8b->leave($__internal_f6b33a5ed12592b5722ad1412d41f60737c1718cb06772cd7d5f2195e2a96b8b_prof);

    }

    // line 13
    public function block_sonata_page_container($context, array $blocks = array())
    {
        $__internal_b74993f0712988144bf5e398cd7c648f150d7ee2a96b169b552e117dbda11ddd = $this->env->getExtension("native_profiler");
        $__internal_b74993f0712988144bf5e398cd7c648f150d7ee2a96b169b552e117dbda11ddd->enter($__internal_b74993f0712988144bf5e398cd7c648f150d7ee2a96b169b552e117dbda11ddd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_container"));

        // line 14
        echo "    <div class=\"container\">
        <div class=\"content\">
            <div class=\"row page-header\">
                ";
        // line 17
        echo $this->env->getExtension('sonata_page')->renderContainer("header", "global");
        echo "
            </div>

            ";
        // line 20
        $this->displayBlock('sonata_page_breadcrumb', $context, $blocks);
        // line 28
        echo "
            ";
        // line 29
        if (array_key_exists("page", $context)) {
            // line 30
            echo "                <div class=\"row\">
                    ";
            // line 31
            if (($this->getAttribute((isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")), "name", array()) != "global")) {
                // line 32
                echo "                        ";
                echo $this->env->getExtension('sonata_page')->renderContainer("content_top", "global");
                echo "
                    ";
            }
            // line 34
            echo "                    ";
            echo $this->env->getExtension('sonata_page')->renderContainer("content_top", (isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")));
            echo "
                </div>
            ";
        }
        // line 37
        echo "
            <div class=\"row\">
                ";
        // line 39
        $this->displayBlock('page_content', $context, $blocks);
        // line 51
        echo "            </div>

            ";
        // line 53
        if (array_key_exists("page", $context)) {
            // line 54
            echo "                <div class=\"row\">
                    ";
            // line 55
            echo $this->env->getExtension('sonata_page')->renderContainer("content_bottom", (isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")));
            echo "

                    ";
            // line 57
            if (($this->getAttribute((isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")), "name", array()) != "global")) {
                // line 58
                echo "                        ";
                echo $this->env->getExtension('sonata_page')->renderContainer("content_bottom", "global");
                echo "
                    ";
            }
            // line 60
            echo "                </div>
            ";
        }
        // line 62
        echo "        </div>

        <footer class=\"row\">
            ";
        // line 65
        echo $this->env->getExtension('sonata_page')->renderContainer("footer", "global");
        echo "
        </footer>
    </div>
";
        
        $__internal_b74993f0712988144bf5e398cd7c648f150d7ee2a96b169b552e117dbda11ddd->leave($__internal_b74993f0712988144bf5e398cd7c648f150d7ee2a96b169b552e117dbda11ddd_prof);

    }

    // line 20
    public function block_sonata_page_breadcrumb($context, array $blocks = array())
    {
        $__internal_d50ba17286c9ddaa517b8df1defdbd8f35c93c84a771d9bfb6d335801a0952da = $this->env->getExtension("native_profiler");
        $__internal_d50ba17286c9ddaa517b8df1defdbd8f35c93c84a771d9bfb6d335801a0952da->enter($__internal_d50ba17286c9ddaa517b8df1defdbd8f35c93c84a771d9bfb6d335801a0952da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_breadcrumb"));

        // line 21
        echo "                <div class=\"row\">
                    ";
        // line 22
        if ( !array_key_exists("sonata_seo_context", $context)) {
            // line 23
            echo "                        ";
            $context["sonata_seo_context"] = "homepage";
            // line 24
            echo "                    ";
        }
        // line 25
        echo "                    ";
        echo call_user_func_array($this->env->getFunction('sonata_block_render_event')->getCallable(), array("breadcrumb", array("context" => (isset($context["sonata_seo_context"]) ? $context["sonata_seo_context"] : $this->getContext($context, "sonata_seo_context")), "current_uri" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "requestUri", array()))));
        echo "
                </div>
            ";
        
        $__internal_d50ba17286c9ddaa517b8df1defdbd8f35c93c84a771d9bfb6d335801a0952da->leave($__internal_d50ba17286c9ddaa517b8df1defdbd8f35c93c84a771d9bfb6d335801a0952da_prof);

    }

    // line 39
    public function block_page_content($context, array $blocks = array())
    {
        $__internal_35bdeb134d265c981a541a91e96ec1993e5666ba4cd3f831d225669b4dbe36df = $this->env->getExtension("native_profiler");
        $__internal_35bdeb134d265c981a541a91e96ec1993e5666ba4cd3f831d225669b4dbe36df->enter($__internal_35bdeb134d265c981a541a91e96ec1993e5666ba4cd3f831d225669b4dbe36df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_content"));

        // line 40
        echo "                    ";
        if (array_key_exists("content", $context)) {
            // line 41
            echo "                        ";
            echo (isset($context["content"]) ? $context["content"] : $this->getContext($context, "content"));
            echo "
                    ";
        } else {
            // line 43
            echo "                        ";
            $context["content"] = $this->renderBlock("content", $context, $blocks);
            // line 44
            echo "                        ";
            if ((twig_length_filter($this->env, (isset($context["content"]) ? $context["content"] : $this->getContext($context, "content"))) > 0)) {
                // line 45
                echo "                            ";
                echo (isset($context["content"]) ? $context["content"] : $this->getContext($context, "content"));
                echo "
                        ";
            } elseif (            // line 46
array_key_exists("page", $context)) {
                // line 47
                echo "                            ";
                echo $this->env->getExtension('sonata_page')->renderContainer("content", (isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")));
                echo "
                        ";
            }
            // line 49
            echo "                    ";
        }
        // line 50
        echo "                ";
        
        $__internal_35bdeb134d265c981a541a91e96ec1993e5666ba4cd3f831d225669b4dbe36df->leave($__internal_35bdeb134d265c981a541a91e96ec1993e5666ba4cd3f831d225669b4dbe36df_prof);

    }

    public function getTemplateName()
    {
        return "ApplicationSonataPageBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  191 => 50,  188 => 49,  182 => 47,  180 => 46,  175 => 45,  172 => 44,  169 => 43,  163 => 41,  160 => 40,  154 => 39,  143 => 25,  140 => 24,  137 => 23,  135 => 22,  132 => 21,  126 => 20,  115 => 65,  110 => 62,  106 => 60,  100 => 58,  98 => 57,  93 => 55,  90 => 54,  88 => 53,  84 => 51,  82 => 39,  78 => 37,  71 => 34,  65 => 32,  63 => 31,  60 => 30,  58 => 29,  55 => 28,  53 => 20,  47 => 17,  42 => 14,  36 => 13,  11 => 11,);
    }
}
