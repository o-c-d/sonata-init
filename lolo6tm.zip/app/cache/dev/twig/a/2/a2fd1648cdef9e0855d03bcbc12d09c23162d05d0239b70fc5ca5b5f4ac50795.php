<?php

/* CoreSphereConsoleBundle:Toolbar:toolbar.html.twig */
class __TwigTemplate_a2fd1648cdef9e0855d03bcbc12d09c23162d05d0239b70fc5ca5b5f4ac50795 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("WebProfilerBundle:Profiler:layout.html.twig", "CoreSphereConsoleBundle:Toolbar:toolbar.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "WebProfilerBundle:Profiler:layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c974f2b97dd2c30b790f144f3e99703f51d13fd2d170d1369c8af11d1b84c1fd = $this->env->getExtension("native_profiler");
        $__internal_c974f2b97dd2c30b790f144f3e99703f51d13fd2d170d1369c8af11d1b84c1fd->enter($__internal_c974f2b97dd2c30b790f144f3e99703f51d13fd2d170d1369c8af11d1b84c1fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CoreSphereConsoleBundle:Toolbar:toolbar.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c974f2b97dd2c30b790f144f3e99703f51d13fd2d170d1369c8af11d1b84c1fd->leave($__internal_c974f2b97dd2c30b790f144f3e99703f51d13fd2d170d1369c8af11d1b84c1fd_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_a1c514afa73db4f13c00451bd4b65a3385df2b368a1145ee46951c9a3f6f1c7d = $this->env->getExtension("native_profiler");
        $__internal_a1c514afa73db4f13c00451bd4b65a3385df2b368a1145ee46951c9a3f6f1c7d->enter($__internal_a1c514afa73db4f13c00451bd4b65a3385df2b368a1145ee46951c9a3f6f1c7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        // line 4
        echo "    ";
        ob_start();
        // line 5
        echo "        <a href=\"";
        echo $this->env->getExtension('routing')->getPath("console");
        echo "\" class=\"coresphere_console_popover\">
            <img width=\"13\" height=\"28\" alt=\"Console\" src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAcCAYAAABh2p9gAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJ
bWFnZVJlYWR5ccllPAAAAG5JREFUeNpi/P//PwM1ARMDlcGogZQDlhMnTlAtmi0sLBip70IkNiOF
rsMwkKGiouL/CE42Bw4cAGOqGejg4AA3mGouRDaYnGSD1YXoFhCyhIVYm4l16UguvmB5keLCAVTk
UNOFjKO13ggwECDAAAMNHZ7ErsJjAAAAAElFTkSuQmCC\"/>
        </a>
    ";
        $context["icon"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 12
        echo "    ";
        $context["text"] = ('' === $tmp = "Console") ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 13
        echo "
    ";
        // line 14
        $this->loadTemplate("WebProfilerBundle:Profiler:toolbar_item.html.twig", "CoreSphereConsoleBundle:Toolbar:toolbar.html.twig", 14)->display(array_merge($context, array("link" => false)));
        
        $__internal_a1c514afa73db4f13c00451bd4b65a3385df2b368a1145ee46951c9a3f6f1c7d->leave($__internal_a1c514afa73db4f13c00451bd4b65a3385df2b368a1145ee46951c9a3f6f1c7d_prof);

    }

    public function getTemplateName()
    {
        return "CoreSphereConsoleBundle:Toolbar:toolbar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 14,  57 => 13,  54 => 12,  43 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }
}
