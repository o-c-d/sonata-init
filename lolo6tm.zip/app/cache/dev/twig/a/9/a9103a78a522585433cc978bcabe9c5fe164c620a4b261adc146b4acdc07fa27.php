<?php

/* CoreSphereConsoleBundle:Console:console.html.twig */
class __TwigTemplate_a9103a78a522585433cc978bcabe9c5fe164c620a4b261adc146b4acdc07fa27 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("CoreSphereConsoleBundle::base.html.twig", "CoreSphereConsoleBundle:Console:console.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "CoreSphereConsoleBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7647b0643a921aea104115b3a914311026b44a2c784993657801b50ddc3d4bc5 = $this->env->getExtension("native_profiler");
        $__internal_7647b0643a921aea104115b3a914311026b44a2c784993657801b50ddc3d4bc5->enter($__internal_7647b0643a921aea104115b3a914311026b44a2c784993657801b50ddc3d4bc5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CoreSphereConsoleBundle:Console:console.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7647b0643a921aea104115b3a914311026b44a2c784993657801b50ddc3d4bc5->leave($__internal_7647b0643a921aea104115b3a914311026b44a2c784993657801b50ddc3d4bc5_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_77d13e3696d298d06a43640f25903b009aa92a8df462ef80a94e7b1080317276 = $this->env->getExtension("native_profiler");
        $__internal_77d13e3696d298d06a43640f25903b009aa92a8df462ef80a94e7b1080317276->enter($__internal_77d13e3696d298d06a43640f25903b009aa92a8df462ef80a94e7b1080317276_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("coresphere_console.headline.index"), "html", null, true);
        
        $__internal_77d13e3696d298d06a43640f25903b009aa92a8df462ef80a94e7b1080317276->leave($__internal_77d13e3696d298d06a43640f25903b009aa92a8df462ef80a94e7b1080317276_prof);

    }

    // line 5
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_bf582afd32e8562863e9d3cf4a4646ef497cba8045fae1ba25737b4a4b43e94f = $this->env->getExtension("native_profiler");
        $__internal_bf582afd32e8562863e9d3cf4a4646ef497cba8045fae1ba25737b4a4b43e94f->enter($__internal_bf582afd32e8562863e9d3cf4a4646ef497cba8045fae1ba25737b4a4b43e94f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 6
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/coresphereconsole/css/console.css"), "html", null, true);
        echo "\" type=\"text/css\" />
";
        
        $__internal_bf582afd32e8562863e9d3cf4a4646ef497cba8045fae1ba25737b4a4b43e94f->leave($__internal_bf582afd32e8562863e9d3cf4a4646ef497cba8045fae1ba25737b4a4b43e94f_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_e5ce4105020ce6447ee309a487adc11e11aa9290ab104fb3f850824835ab7c80 = $this->env->getExtension("native_profiler");
        $__internal_e5ce4105020ce6447ee309a487adc11e11aa9290ab104fb3f850824835ab7c80->enter($__internal_e5ce4105020ce6447ee309a487adc11e11aa9290ab104fb3f850824835ab7c80_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "    ";
        $this->loadTemplate("CoreSphereConsoleBundle:Console:terminal.html.twig", "CoreSphereConsoleBundle:Console:console.html.twig", 11)->display($context);
        // line 12
        echo "    ";
        $this->loadTemplate("CoreSphereConsoleBundle:Console:htmlTemplates.html.twig", "CoreSphereConsoleBundle:Console:console.html.twig", 12)->display($context);
        
        $__internal_e5ce4105020ce6447ee309a487adc11e11aa9290ab104fb3f850824835ab7c80->leave($__internal_e5ce4105020ce6447ee309a487adc11e11aa9290ab104fb3f850824835ab7c80_prof);

    }

    // line 15
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_565dfbb0cf21799c66d778283ca043e3a12b3617bdeb56bf1111efd0f689fab9 = $this->env->getExtension("native_profiler");
        $__internal_565dfbb0cf21799c66d778283ca043e3a12b3617bdeb56bf1111efd0f689fab9->enter($__internal_565dfbb0cf21799c66d778283ca043e3a12b3617bdeb56bf1111efd0f689fab9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 16
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script src=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/coresphereconsole/js/console.js"), "html", null, true);
        echo "\"></script>
    <script>
        jQuery(function () {
            ";
        // line 21
        echo "            var coresphere_console = new CoreSphereConsole(
                jQuery(\"#coresphere_consolebundle_console\"), {
                \"commands\" : ";
        // line 23
        echo twig_jsonencode_filter(twig_get_array_keys_filter((isset($context["commands"]) ? $context["commands"] : $this->getContext($context, "commands"))));
        echo ".sort(),
                \"post_path\" : \"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("console_exec"), "js", null, true);
        echo "\",
                \"environment\" : \"";
        // line 25
        echo twig_escape_filter($this->env, (isset($context["environment"]) ? $context["environment"] : $this->getContext($context, "environment")), "js", null, true);
        echo "\",
                \"lang\" : {
                    \"loading\" : \"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("coresphere_console.loading"), "js", null, true);
        echo "\",
                    \"suggestion_head\" : \"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("coresphere_console.suggestion_head"), "js", null, true);
        echo "\",
                    \"environment\" : \"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("coresphere_console.environment"), "js", null, true);
        echo "\",
                    \"empty_response\" : \"";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("coresphere_console.empty_response"), "js", null, true);
        echo "\",
                    \"welcome_message\" : \"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("coresphere_console.welcome_message", array("%command%" => "<code class=\"console_command\">list</code>")), "js", null, true);
        echo "\"
                },
                \"templates\" : {
                    \"error\" : \$(\"#template_console_error\").text(),
                    \"command\" : \$(\"#template_console_command\").text(),
                    \"environment\" : \$(\"#template_console_environment\").text(),
                    \"suggestion_list\" : \$('#template_suggestion_list').text(),
                    \"loading\" : \$('#template_console_loading').text(),
                    \"suggestion_item_active\" : \$('#suggestion_item_active').text(),
                    \"suggestion_item\" : \$('#suggestion_item').text(),
                    \"highlight\" : \$('#template_console_highlight').text().trim()
                }
            });
            ";
        // line 45
        echo "        });
    </script>
";
        
        $__internal_565dfbb0cf21799c66d778283ca043e3a12b3617bdeb56bf1111efd0f689fab9->leave($__internal_565dfbb0cf21799c66d778283ca043e3a12b3617bdeb56bf1111efd0f689fab9_prof);

    }

    public function getTemplateName()
    {
        return "CoreSphereConsoleBundle:Console:console.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  152 => 45,  136 => 31,  132 => 30,  128 => 29,  124 => 28,  120 => 27,  115 => 25,  111 => 24,  107 => 23,  103 => 21,  97 => 17,  92 => 16,  86 => 15,  78 => 12,  75 => 11,  69 => 10,  60 => 7,  55 => 6,  49 => 5,  37 => 3,  11 => 1,);
    }
}
