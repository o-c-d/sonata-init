<?php

/* SonataSeoBundle:Block:_pinterest_sdk.html.twig */
class __TwigTemplate_a5f7b9e0a70da9963b2e41bbe927b0cfb19c0c27f942f2a0c42f0a14d2eaad36 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'pinterest_sdk' => array($this, 'block_pinterest_sdk'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_073ce8d00ae2d1be2945f8b1c04839d4a624bb928b875fb3ee2d9415e73b63b3 = $this->env->getExtension("native_profiler");
        $__internal_073ce8d00ae2d1be2945f8b1c04839d4a624bb928b875fb3ee2d9415e73b63b3->enter($__internal_073ce8d00ae2d1be2945f8b1c04839d4a624bb928b875fb3ee2d9415e73b63b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataSeoBundle:Block:_pinterest_sdk.html.twig"));

        // line 11
        $this->displayBlock('pinterest_sdk', $context, $blocks);
        
        $__internal_073ce8d00ae2d1be2945f8b1c04839d4a624bb928b875fb3ee2d9415e73b63b3->leave($__internal_073ce8d00ae2d1be2945f8b1c04839d4a624bb928b875fb3ee2d9415e73b63b3_prof);

    }

    public function block_pinterest_sdk($context, array $blocks = array())
    {
        $__internal_425db8ac15612a1a01cedb236720a7927ee3d36f6fa23684cc3d000ac40193c5 = $this->env->getExtension("native_profiler");
        $__internal_425db8ac15612a1a01cedb236720a7927ee3d36f6fa23684cc3d000ac40193c5->enter($__internal_425db8ac15612a1a01cedb236720a7927ee3d36f6fa23684cc3d000ac40193c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "pinterest_sdk"));

        // line 12
        echo "    ";
        ob_start();
        // line 13
        echo "
        <script type=\"text/javascript\" async src=\"//assets.pinterest.com/js/pinit.js\"></script>

    ";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_425db8ac15612a1a01cedb236720a7927ee3d36f6fa23684cc3d000ac40193c5->leave($__internal_425db8ac15612a1a01cedb236720a7927ee3d36f6fa23684cc3d000ac40193c5_prof);

    }

    public function getTemplateName()
    {
        return "SonataSeoBundle:Block:_pinterest_sdk.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  38 => 13,  35 => 12,  23 => 11,);
    }
}
