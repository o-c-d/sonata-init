<?php

/* SonataSeoBundle:Block:_twitter_sdk.html.twig */
class __TwigTemplate_441757123abf5b79f4ea2e3fa0ad17394100b187ead9bfc9653b6561a21e9dc0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'twitter_sdk' => array($this, 'block_twitter_sdk'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1cf116ae9838ae918ee0a6c38938ec6faaf655e0f318f09ad402745c373904a4 = $this->env->getExtension("native_profiler");
        $__internal_1cf116ae9838ae918ee0a6c38938ec6faaf655e0f318f09ad402745c373904a4->enter($__internal_1cf116ae9838ae918ee0a6c38938ec6faaf655e0f318f09ad402745c373904a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataSeoBundle:Block:_twitter_sdk.html.twig"));

        // line 11
        $this->displayBlock('twitter_sdk', $context, $blocks);
        
        $__internal_1cf116ae9838ae918ee0a6c38938ec6faaf655e0f318f09ad402745c373904a4->leave($__internal_1cf116ae9838ae918ee0a6c38938ec6faaf655e0f318f09ad402745c373904a4_prof);

    }

    public function block_twitter_sdk($context, array $blocks = array())
    {
        $__internal_9ffe64e88fd8339d863ba017dfd7929cbe7134cf00d49b264070f5aba7b0e334 = $this->env->getExtension("native_profiler");
        $__internal_9ffe64e88fd8339d863ba017dfd7929cbe7134cf00d49b264070f5aba7b0e334->enter($__internal_9ffe64e88fd8339d863ba017dfd7929cbe7134cf00d49b264070f5aba7b0e334_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "twitter_sdk"));

        // line 12
        ob_start();
        // line 13
        echo "
    <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>

";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_9ffe64e88fd8339d863ba017dfd7929cbe7134cf00d49b264070f5aba7b0e334->leave($__internal_9ffe64e88fd8339d863ba017dfd7929cbe7134cf00d49b264070f5aba7b0e334_prof);

    }

    public function getTemplateName()
    {
        return "SonataSeoBundle:Block:_twitter_sdk.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 13,  35 => 12,  23 => 11,);
    }
}
