<?php

/* CoreSphereConsoleBundle::base.html.twig */
class __TwigTemplate_ce6ca2e89f96046818737f5aadba35da5c1bc98de6c59abfa1e632967cf599ef extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3b8ed9a5785b200ff5ba532da4611a03113e7b1510fd3ab98becfa527b18dbe0 = $this->env->getExtension("native_profiler");
        $__internal_3b8ed9a5785b200ff5ba532da4611a03113e7b1510fd3ab98becfa527b18dbe0->enter($__internal_3b8ed9a5785b200ff5ba532da4611a03113e7b1510fd3ab98becfa527b18dbe0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CoreSphereConsoleBundle::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 9
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 12
        $this->displayBlock('body', $context, $blocks);
        // line 13
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 22
        echo "    </body>
</html>
";
        
        $__internal_3b8ed9a5785b200ff5ba532da4611a03113e7b1510fd3ab98becfa527b18dbe0->leave($__internal_3b8ed9a5785b200ff5ba532da4611a03113e7b1510fd3ab98becfa527b18dbe0_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_16ce36446fee6e201d7ae8b59352663aa8926cfc5fa7b6609cc3ba794731d672 = $this->env->getExtension("native_profiler");
        $__internal_16ce36446fee6e201d7ae8b59352663aa8926cfc5fa7b6609cc3ba794731d672->enter($__internal_16ce36446fee6e201d7ae8b59352663aa8926cfc5fa7b6609cc3ba794731d672_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "CoreSphere Console";
        
        $__internal_16ce36446fee6e201d7ae8b59352663aa8926cfc5fa7b6609cc3ba794731d672->leave($__internal_16ce36446fee6e201d7ae8b59352663aa8926cfc5fa7b6609cc3ba794731d672_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_5e8bfdb178fb99d3686627b7a45121e6796ed8a58422b87a57042463ae5efda8 = $this->env->getExtension("native_profiler");
        $__internal_5e8bfdb178fb99d3686627b7a45121e6796ed8a58422b87a57042463ae5efda8->enter($__internal_5e8bfdb178fb99d3686627b7a45121e6796ed8a58422b87a57042463ae5efda8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "            <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/coresphereconsole/css/base.css"), "html", null, true);
        echo "\" type=\"text/css\" />
        ";
        
        $__internal_5e8bfdb178fb99d3686627b7a45121e6796ed8a58422b87a57042463ae5efda8->leave($__internal_5e8bfdb178fb99d3686627b7a45121e6796ed8a58422b87a57042463ae5efda8_prof);

    }

    // line 12
    public function block_body($context, array $blocks = array())
    {
        $__internal_ba016443cd5b1fe2386377f0b82dc58eacd8bc3a403fc0bca7dbeb99c244fcc5 = $this->env->getExtension("native_profiler");
        $__internal_ba016443cd5b1fe2386377f0b82dc58eacd8bc3a403fc0bca7dbeb99c244fcc5->enter($__internal_ba016443cd5b1fe2386377f0b82dc58eacd8bc3a403fc0bca7dbeb99c244fcc5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        echo "";
        
        $__internal_ba016443cd5b1fe2386377f0b82dc58eacd8bc3a403fc0bca7dbeb99c244fcc5->leave($__internal_ba016443cd5b1fe2386377f0b82dc58eacd8bc3a403fc0bca7dbeb99c244fcc5_prof);

    }

    // line 13
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_c23d145206299bd89fb34206b30b91a8fd53bc2a490d2fe0816c2619800ef17b = $this->env->getExtension("native_profiler");
        $__internal_c23d145206299bd89fb34206b30b91a8fd53bc2a490d2fe0816c2619800ef17b->enter($__internal_c23d145206299bd89fb34206b30b91a8fd53bc2a490d2fe0816c2619800ef17b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 14
        echo "            ";
        // line 15
        echo "            <script>
            window.jQuery || document.write('<script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.min.js\"><\\/script>')
            </script>
            <script>
            window.jQuery || document.write(\"<script src=\\\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/coresphereconsole/js/jquery-1.8.3.min.js"), "html", null, true);
        echo "\\\"><\\/script>\");
            </script>
        ";
        
        $__internal_c23d145206299bd89fb34206b30b91a8fd53bc2a490d2fe0816c2619800ef17b->leave($__internal_c23d145206299bd89fb34206b30b91a8fd53bc2a490d2fe0816c2619800ef17b_prof);

    }

    public function getTemplateName()
    {
        return "CoreSphereConsoleBundle::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  113 => 19,  107 => 15,  105 => 14,  99 => 13,  87 => 12,  77 => 7,  71 => 6,  59 => 5,  50 => 22,  47 => 13,  45 => 12,  38 => 9,  36 => 6,  32 => 5,  26 => 1,);
    }
}
