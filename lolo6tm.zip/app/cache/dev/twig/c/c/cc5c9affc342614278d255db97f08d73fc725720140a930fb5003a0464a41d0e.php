<?php

/* ApplicationSonataPageBundle::base_layout.html.twig */
class __TwigTemplate_cc5c9affc342614278d255db97f08d73fc725720140a930fb5003a0464a41d0e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'sonata_page_html_tag' => array($this, 'block_sonata_page_html_tag'),
            'sonata_page_head' => array($this, 'block_sonata_page_head'),
            'sonata_page_stylesheets' => array($this, 'block_sonata_page_stylesheets'),
            'page_stylesheets' => array($this, 'block_page_stylesheets'),
            'sonata_page_javascripts' => array($this, 'block_sonata_page_javascripts'),
            'page_javascripts' => array($this, 'block_page_javascripts'),
            'sonata_page_body_tag' => array($this, 'block_sonata_page_body_tag'),
            'sonata_page_top_bar' => array($this, 'block_sonata_page_top_bar'),
            'page_top_bar' => array($this, 'block_page_top_bar'),
            'sonata_page_container' => array($this, 'block_sonata_page_container'),
            'page_container' => array($this, 'block_page_container'),
            'sonata_page_asset_footer' => array($this, 'block_sonata_page_asset_footer'),
            'page_asset_footer' => array($this, 'block_page_asset_footer'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fd4aaac897c1f97a0ab74c9208d0cef742eb3eefac85976bfcbbc48b6392600f = $this->env->getExtension("native_profiler");
        $__internal_fd4aaac897c1f97a0ab74c9208d0cef742eb3eefac85976bfcbbc48b6392600f->enter($__internal_fd4aaac897c1f97a0ab74c9208d0cef742eb3eefac85976bfcbbc48b6392600f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ApplicationSonataPageBundle::base_layout.html.twig"));

        // line 11
        $this->displayBlock('sonata_page_html_tag', $context, $blocks);
        // line 15
        echo "    ";
        $this->displayBlock('sonata_page_head', $context, $blocks);
        // line 45
        echo "
    ";
        // line 46
        $this->displayBlock('sonata_page_body_tag', $context, $blocks);
        // line 49
        echo "
        ";
        // line 50
        $this->displayBlock('sonata_page_top_bar', $context, $blocks);
        // line 141
        echo "
        ";
        // line 142
        $this->displayBlock('sonata_page_container', $context, $blocks);
        // line 145
        echo "
        ";
        // line 146
        $this->displayBlock('sonata_page_asset_footer', $context, $blocks);
        // line 168
        echo "
        <!-- monitoring:3e9fda56df2cdd3b039f189693ab7844fbb2d4f6 -->
    </body>
</html>
";
        
        $__internal_fd4aaac897c1f97a0ab74c9208d0cef742eb3eefac85976bfcbbc48b6392600f->leave($__internal_fd4aaac897c1f97a0ab74c9208d0cef742eb3eefac85976bfcbbc48b6392600f_prof);

    }

    // line 11
    public function block_sonata_page_html_tag($context, array $blocks = array())
    {
        $__internal_eb7945c829e18bcec26cc6ece853f876b5928878aeec1c86b2022307681f57f9 = $this->env->getExtension("native_profiler");
        $__internal_eb7945c829e18bcec26cc6ece853f876b5928878aeec1c86b2022307681f57f9->enter($__internal_eb7945c829e18bcec26cc6ece853f876b5928878aeec1c86b2022307681f57f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_html_tag"));

        // line 12
        echo "<!DOCTYPE html>
<html ";
        // line 13
        echo $this->env->getExtension('sonata_seo')->getHtmlAttributes();
        echo ">
";
        
        $__internal_eb7945c829e18bcec26cc6ece853f876b5928878aeec1c86b2022307681f57f9->leave($__internal_eb7945c829e18bcec26cc6ece853f876b5928878aeec1c86b2022307681f57f9_prof);

    }

    // line 15
    public function block_sonata_page_head($context, array $blocks = array())
    {
        $__internal_adb9b74ccd882ceedc8580fe47b5d5007f567ddb24e3c2305f9bc80ff82f4e07 = $this->env->getExtension("native_profiler");
        $__internal_adb9b74ccd882ceedc8580fe47b5d5007f567ddb24e3c2305f9bc80ff82f4e07->enter($__internal_adb9b74ccd882ceedc8580fe47b5d5007f567ddb24e3c2305f9bc80ff82f4e07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_head"));

        // line 16
        echo "        <head ";
        echo $this->env->getExtension('sonata_seo')->getHeadAttributes();
        echo ">

            <!--[if IE]><meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\"><![endif]-->
            ";
        // line 19
        echo $this->env->getExtension('sonata_seo')->getTitle();
        echo "
            ";
        // line 20
        echo $this->env->getExtension('sonata_seo')->getMetadatas();
        echo "

            ";
        // line 22
        $this->displayBlock('sonata_page_stylesheets', $context, $blocks);
        // line 29
        echo "
            ";
        // line 30
        $this->displayBlock('sonata_page_javascripts', $context, $blocks);
        // line 43
        echo "        </head>
    ";
        
        $__internal_adb9b74ccd882ceedc8580fe47b5d5007f567ddb24e3c2305f9bc80ff82f4e07->leave($__internal_adb9b74ccd882ceedc8580fe47b5d5007f567ddb24e3c2305f9bc80ff82f4e07_prof);

    }

    // line 22
    public function block_sonata_page_stylesheets($context, array $blocks = array())
    {
        $__internal_f671a3bd0aca633e017f37d39f174dce071f432a09beb88c27883dabf58f7d6e = $this->env->getExtension("native_profiler");
        $__internal_f671a3bd0aca633e017f37d39f174dce071f432a09beb88c27883dabf58f7d6e->enter($__internal_f671a3bd0aca633e017f37d39f174dce071f432a09beb88c27883dabf58f7d6e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_stylesheets"));

        // line 23
        echo "                ";
        $this->displayBlock('page_stylesheets', $context, $blocks);
        // line 28
        echo "            ";
        
        $__internal_f671a3bd0aca633e017f37d39f174dce071f432a09beb88c27883dabf58f7d6e->leave($__internal_f671a3bd0aca633e017f37d39f174dce071f432a09beb88c27883dabf58f7d6e_prof);

    }

    // line 23
    public function block_page_stylesheets($context, array $blocks = array())
    {
        $__internal_44470f33b1f7ec968f616e52619fa0c59b70f83c6eb10dbf775d222c3b04d83c = $this->env->getExtension("native_profiler");
        $__internal_44470f33b1f7ec968f616e52619fa0c59b70f83c6eb10dbf775d222c3b04d83c->enter($__internal_44470f33b1f7ec968f616e52619fa0c59b70f83c6eb10dbf775d222c3b04d83c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_stylesheets"));

        echo " ";
        // line 24
        echo "                    ";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["sonata_page"]) ? $context["sonata_page"] : $this->getContext($context, "sonata_page")), "assets", array()), "stylesheets", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["stylesheet"]) {
            // line 25
            echo "                        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl($context["stylesheet"]), "html", null, true);
            echo "\" media=\"all\">
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['stylesheet'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        echo "                ";
        
        $__internal_44470f33b1f7ec968f616e52619fa0c59b70f83c6eb10dbf775d222c3b04d83c->leave($__internal_44470f33b1f7ec968f616e52619fa0c59b70f83c6eb10dbf775d222c3b04d83c_prof);

    }

    // line 30
    public function block_sonata_page_javascripts($context, array $blocks = array())
    {
        $__internal_0ffaa46a826222175593e90894c7eb8ac7a5baac9f8fd3c6acf97a4e8e2495f1 = $this->env->getExtension("native_profiler");
        $__internal_0ffaa46a826222175593e90894c7eb8ac7a5baac9f8fd3c6acf97a4e8e2495f1->enter($__internal_0ffaa46a826222175593e90894c7eb8ac7a5baac9f8fd3c6acf97a4e8e2495f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_javascripts"));

        // line 31
        echo "                ";
        $this->displayBlock('page_javascripts', $context, $blocks);
        // line 41
        echo "
            ";
        
        $__internal_0ffaa46a826222175593e90894c7eb8ac7a5baac9f8fd3c6acf97a4e8e2495f1->leave($__internal_0ffaa46a826222175593e90894c7eb8ac7a5baac9f8fd3c6acf97a4e8e2495f1_prof);

    }

    // line 31
    public function block_page_javascripts($context, array $blocks = array())
    {
        $__internal_79f205b4b0a7ddd7b580b4fa1bfce08d856756db8f170a2a8929f75d4e55aceb = $this->env->getExtension("native_profiler");
        $__internal_79f205b4b0a7ddd7b580b4fa1bfce08d856756db8f170a2a8929f75d4e55aceb->enter($__internal_79f205b4b0a7ddd7b580b4fa1bfce08d856756db8f170a2a8929f75d4e55aceb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_javascripts"));

        echo " ";
        // line 32
        echo "                    <!-- Le HTML5 shim, for IE6-8 support of HTML elements -->
                    <!--[if lt IE 9]>
                        <script src=\"http://html5shim.googlecode.com/svn/trunk/html5.js\"></script>
                    <![endif]-->

                    ";
        // line 37
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["sonata_page"]) ? $context["sonata_page"] : $this->getContext($context, "sonata_page")), "assets", array()), "javascripts", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["js"]) {
            // line 38
            echo "                        <script src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl($context["js"]), "html", null, true);
            echo "\"></script>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['js'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 40
        echo "                ";
        
        $__internal_79f205b4b0a7ddd7b580b4fa1bfce08d856756db8f170a2a8929f75d4e55aceb->leave($__internal_79f205b4b0a7ddd7b580b4fa1bfce08d856756db8f170a2a8929f75d4e55aceb_prof);

    }

    // line 46
    public function block_sonata_page_body_tag($context, array $blocks = array())
    {
        $__internal_1607f878eaf0a6d876c8b1b5eaf5555cd0aa873672d657611ad9479f012d97ac = $this->env->getExtension("native_profiler");
        $__internal_1607f878eaf0a6d876c8b1b5eaf5555cd0aa873672d657611ad9479f012d97ac->enter($__internal_1607f878eaf0a6d876c8b1b5eaf5555cd0aa873672d657611ad9479f012d97ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_body_tag"));

        // line 47
        echo "        <body class=\"sonata-bc\">
    ";
        
        $__internal_1607f878eaf0a6d876c8b1b5eaf5555cd0aa873672d657611ad9479f012d97ac->leave($__internal_1607f878eaf0a6d876c8b1b5eaf5555cd0aa873672d657611ad9479f012d97ac_prof);

    }

    // line 50
    public function block_sonata_page_top_bar($context, array $blocks = array())
    {
        $__internal_771e1618a605f21226f802333d8dd9ded21560fa7ec02afda4034f5b433e2750 = $this->env->getExtension("native_profiler");
        $__internal_771e1618a605f21226f802333d8dd9ded21560fa7ec02afda4034f5b433e2750->enter($__internal_771e1618a605f21226f802333d8dd9ded21560fa7ec02afda4034f5b433e2750_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_top_bar"));

        // line 51
        echo "            ";
        $this->displayBlock('page_top_bar', $context, $blocks);
        // line 140
        echo "        ";
        
        $__internal_771e1618a605f21226f802333d8dd9ded21560fa7ec02afda4034f5b433e2750->leave($__internal_771e1618a605f21226f802333d8dd9ded21560fa7ec02afda4034f5b433e2750_prof);

    }

    // line 51
    public function block_page_top_bar($context, array $blocks = array())
    {
        $__internal_1aabb3d3ea5686296a2ed772996d12538e90448114cffdad3ecb91016f2f583e = $this->env->getExtension("native_profiler");
        $__internal_1aabb3d3ea5686296a2ed772996d12538e90448114cffdad3ecb91016f2f583e->enter($__internal_1aabb3d3ea5686296a2ed772996d12538e90448114cffdad3ecb91016f2f583e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_top_bar"));

        echo " ";
        // line 52
        echo "                ";
        if (($this->getAttribute((isset($context["sonata_page"]) ? $context["sonata_page"] : $this->getContext($context, "sonata_page")), "isEditor", array()) || (($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "security", array()) && $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "security", array()), "token", array())) && $this->env->getExtension('security')->isGranted("ROLE_PREVIOUS_ADMIN")))) {
            // line 53
            echo "
                    ";
            // line 54
            if (($this->getAttribute((isset($context["sonata_page"]) ? $context["sonata_page"] : $this->getContext($context, "sonata_page")), "isEditor", array()) && $this->getAttribute((isset($context["sonata_page"]) ? $context["sonata_page"] : $this->getContext($context, "sonata_page")), "isInlineEditionOn", array()))) {
                // line 55
                echo "                        <!-- CMS specific variables -->
                        <script>
                            jQuery(document).ready(function() {
                                Sonata.Page.init({
                                    url: {
                                        block_save_position: '";
                // line 60
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["sonata_admin"]) ? $context["sonata_admin"] : $this->getContext($context, "sonata_admin")), "objectUrl", array(0 => "sonata.page.admin.page", 1 => "edit", 2 => (isset($context["page"]) ? $context["page"] : $this->getContext($context, "page"))), "method"), "html", null, true);
                echo "',
                                        block_edit:          '";
                // line 61
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["sonata_admin"]) ? $context["sonata_admin"] : $this->getContext($context, "sonata_admin")), "url", array(0 => "sonata.page.admin.page|sonata.page.admin.block", 1 => "edit", 2 => array("id" => $this->getAttribute((isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")), "id", array()), "childId" => "BLOCK_ID")), "method"), "html", null, true);
                echo "'
                                    }
                                });
                            });
                        </script>
                    ";
            }
            // line 67
            echo "
                    <header class=\"sonata-bc sonata-page-top-bar navbar navbar-inverse navbar-fixed-top\" role=\"banner\">
                        <div class=\"container\">
                            <ul class=\"nav navbar-nav\">
                                ";
            // line 71
            if ((($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "security", array()) && $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "security", array()), "token", array())) && $this->env->getExtension('security')->isGranted("ROLE_SONATA_ADMIN"))) {
                // line 72
                echo "                                    <li><a href=\"";
                echo $this->env->getExtension('routing')->getPath("sonata_admin_dashboard");
                echo "\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("header.sonata_admin_dashboard", array(), "SonataPageBundle"), "html", null, true);
                echo "</a></li>
                                ";
            }
            // line 74
            echo "
                                ";
            // line 75
            if ($this->getAttribute((isset($context["sonata_page"]) ? $context["sonata_page"] : $this->getContext($context, "sonata_page")), "isEditor", array())) {
                // line 76
                echo "                                    ";
                $context["sites"] = $this->getAttribute((isset($context["sonata_page"]) ? $context["sonata_page"] : $this->getContext($context, "sonata_page")), "siteavailables", array());
                // line 77
                echo "
                                    ";
                // line 78
                if (((twig_length_filter($this->env, (isset($context["sites"]) ? $context["sites"] : $this->getContext($context, "sites"))) > 1) && array_key_exists("site", $context))) {
                    // line 79
                    echo "                                        <li class=\"dropdown\">
                                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">";
                    // line 80
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["site"]) ? $context["site"] : $this->getContext($context, "site")), "name", array()), "html", null, true);
                    echo " <span class=\"caret\"></span></a>
                                            <ul class=\"dropdown-menu\">
                                                ";
                    // line 82
                    $context['_parent'] = (array) $context;
                    $context['_seq'] = twig_ensure_traversable((isset($context["sites"]) ? $context["sites"] : $this->getContext($context, "sites")));
                    foreach ($context['_seq'] as $context["_key"] => $context["site"]) {
                        // line 83
                        echo "                                                    <li><a href=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["site"], "url", array()), "html", null, true);
                        echo "\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["site"], "name", array()), "html", null, true);
                        echo "</a></li>
                                                ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['site'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 85
                    echo "                                            </ul>
                                        </li>
                                    ";
                }
                // line 88
                echo "
                                    <li class=\"dropdown\">
                                        <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">Page <span class=\"caret\"></span></a>
                                        <ul class=\"dropdown-menu\">
                                            ";
                // line 92
                if (array_key_exists("page", $context)) {
                    // line 93
                    echo "                                                <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["sonata_admin"]) ? $context["sonata_admin"] : $this->getContext($context, "sonata_admin")), "objectUrl", array(0 => "sonata.page.admin.page", 1 => "edit", 2 => (isset($context["page"]) ? $context["page"] : $this->getContext($context, "page"))), "method"), "html", null, true);
                    echo "\" target=\"_new\">";
                    echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("header.edit_page", array(), "SonataPageBundle"), "html", null, true);
                    echo "</a></li>
                                                <li><a href=\"";
                    // line 94
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["sonata_admin"]) ? $context["sonata_admin"] : $this->getContext($context, "sonata_admin")), "objectUrl", array(0 => "sonata.page.admin.page|sonata.page.admin.snapshot", 1 => "list", 2 => (isset($context["page"]) ? $context["page"] : $this->getContext($context, "page"))), "method"), "html", null, true);
                    echo "\" target=\"_new\">";
                    echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("header.create_snapshot", array(), "SonataPageBundle"), "html", null, true);
                    echo "</a></li>
                                                <li class=\"divider\"></li>
                                            ";
                }
                // line 97
                echo "
                                            <li><a href=\"";
                // line 98
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["sonata_admin"]) ? $context["sonata_admin"] : $this->getContext($context, "sonata_admin")), "url", array(0 => "sonata.page.admin.page", 1 => "list"), "method"), "html", null, true);
                echo "\" target=\"_new\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("header.view_all_pages", array(), "SonataPageBundle"), "html", null, true);
                echo "</a></li>

                                            ";
                // line 100
                if ((array_key_exists("error_codes", $context) && twig_length_filter($this->env, (isset($context["error_codes"]) ? $context["error_codes"] : $this->getContext($context, "error_codes"))))) {
                    // line 101
                    echo "                                                <li class=\"divider\"></li>
                                                <li><a href=\"";
                    // line 102
                    echo $this->env->getExtension('routing')->getPath("sonata_page_exceptions_list");
                    echo "\" target=\"_new\">";
                    echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("header.view_all_exceptions", array(), "SonataPageBundle"), "html", null, true);
                    echo "</a></li>
                                            ";
                }
                // line 104
                echo "                                        </ul>
                                    </li>

                                    ";
                // line 107
                if (array_key_exists("page", $context)) {
                    // line 108
                    echo "                                        <li>
                                            <a href=\"";
                    // line 109
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["sonata_admin"]) ? $context["sonata_admin"] : $this->getContext($context, "sonata_admin")), "url", array(0 => "sonata.page.admin.page", 1 => "compose", 2 => array("id" => $this->getAttribute((isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")), "id", array()))), "method"), "html", null, true);
                    echo "\">
                                                <i class=\"fa fa-magic\"></i>
                                                ";
                    // line 111
                    echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("header.compose_page", array(), "SonataPageBundle"), "html", null, true);
                    echo "
                                            </a>
                                        </li>
                                    ";
                }
                // line 115
                echo "
                                    ";
                // line 116
                if ((array_key_exists("page", $context) &&  !$this->getAttribute((isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")), "enabled", array()))) {
                    // line 117
                    echo "                                        <li><span style=\"padding-left: 20px; background: red;\"><strong><em>";
                    echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("header.page_is_disabled", array(), "SonataPageBundle"), "html", null, true);
                    echo "</em></strong></span></li>
                                    ";
                }
                // line 119
                echo "
                                    ";
                // line 120
                if (($this->getAttribute((isset($context["sonata_page"]) ? $context["sonata_page"] : $this->getContext($context, "sonata_page")), "isInlineEditionOn", array()) && array_key_exists("page", $context))) {
                    // line 121
                    echo "                                        <li>
                                            <form class=\"form-inline\" style=\"margin: 0px\">
                                                <label class=\"checkbox inline\" for=\"page-action-enabled-edit\"><input type=\"checkbox\" id=\"page-action-enabled-edit\">";
                    // line 123
                    echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("header.show_zone", array(), "SonataPageBundle"), "html", null, true);
                    echo "</label>
                                                <input type=\"submit\" class=\"btn\" value=\"";
                    // line 124
                    echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("btn_save_position", array(), "SonataPageBundle"), "html", null, true);
                    echo "\" id=\"page-action-save-position\">
                                            </form>
                                        </li>
                                    ";
                }
                // line 128
                echo "                                ";
            }
            // line 129
            echo "
                                ";
            // line 130
            if ((($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "security", array()) && $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "security", array()), "token", array())) && $this->env->getExtension('security')->isGranted("ROLE_PREVIOUS_ADMIN"))) {
                // line 131
                echo "                                    <li><a href=\"";
                echo $this->env->getExtension('routing')->getUrl("homepage", array("_switch_user" => "_exit"));
                echo "\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("header.switch_user_exit", array(), "SonataPageBundle"), "html", null, true);
                echo "</a></li>
                                ";
            }
            // line 133
            echo "
                            </ul>
                        </div>
                    </header>

                ";
        }
        // line 139
        echo "            ";
        
        $__internal_1aabb3d3ea5686296a2ed772996d12538e90448114cffdad3ecb91016f2f583e->leave($__internal_1aabb3d3ea5686296a2ed772996d12538e90448114cffdad3ecb91016f2f583e_prof);

    }

    // line 142
    public function block_sonata_page_container($context, array $blocks = array())
    {
        $__internal_f66b485fef8bdb5b295cf6f3eda0e2f34fe0a8e890a54eb41e11167ea550fe06 = $this->env->getExtension("native_profiler");
        $__internal_f66b485fef8bdb5b295cf6f3eda0e2f34fe0a8e890a54eb41e11167ea550fe06->enter($__internal_f66b485fef8bdb5b295cf6f3eda0e2f34fe0a8e890a54eb41e11167ea550fe06_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_container"));

        // line 143
        echo "            ";
        $this->displayBlock('page_container', $context, $blocks);
        echo " ";
        // line 144
        echo "        ";
        
        $__internal_f66b485fef8bdb5b295cf6f3eda0e2f34fe0a8e890a54eb41e11167ea550fe06->leave($__internal_f66b485fef8bdb5b295cf6f3eda0e2f34fe0a8e890a54eb41e11167ea550fe06_prof);

    }

    // line 143
    public function block_page_container($context, array $blocks = array())
    {
        $__internal_fa78242485ce06d8e64a892e7af282b6a2da9b743633caa6d6bc310f2593b50f = $this->env->getExtension("native_profiler");
        $__internal_fa78242485ce06d8e64a892e7af282b6a2da9b743633caa6d6bc310f2593b50f->enter($__internal_fa78242485ce06d8e64a892e7af282b6a2da9b743633caa6d6bc310f2593b50f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_container"));

        
        $__internal_fa78242485ce06d8e64a892e7af282b6a2da9b743633caa6d6bc310f2593b50f->leave($__internal_fa78242485ce06d8e64a892e7af282b6a2da9b743633caa6d6bc310f2593b50f_prof);

    }

    // line 146
    public function block_sonata_page_asset_footer($context, array $blocks = array())
    {
        $__internal_a90c2c49338b597b5af85bd43caf3bd86b8e40f70d15aba8065c8d6a7f0e42b6 = $this->env->getExtension("native_profiler");
        $__internal_a90c2c49338b597b5af85bd43caf3bd86b8e40f70d15aba8065c8d6a7f0e42b6->enter($__internal_a90c2c49338b597b5af85bd43caf3bd86b8e40f70d15aba8065c8d6a7f0e42b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_asset_footer"));

        // line 147
        echo "            ";
        $this->displayBlock('page_asset_footer', $context, $blocks);
        // line 167
        echo "        ";
        
        $__internal_a90c2c49338b597b5af85bd43caf3bd86b8e40f70d15aba8065c8d6a7f0e42b6->leave($__internal_a90c2c49338b597b5af85bd43caf3bd86b8e40f70d15aba8065c8d6a7f0e42b6_prof);

    }

    // line 147
    public function block_page_asset_footer($context, array $blocks = array())
    {
        $__internal_ae4034b55559d318d36affa340219a6e8a3f9dc27415937232222adf8a6e313e = $this->env->getExtension("native_profiler");
        $__internal_ae4034b55559d318d36affa340219a6e8a3f9dc27415937232222adf8a6e313e->enter($__internal_ae4034b55559d318d36affa340219a6e8a3f9dc27415937232222adf8a6e313e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_asset_footer"));

        echo " ";
        // line 148
        echo "                ";
        if (array_key_exists("page", $context)) {
            // line 149
            echo "                    ";
            if ( !twig_test_empty($this->getAttribute((isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")), "javascript", array()))) {
                // line 150
                echo "                        <script>
                            ";
                // line 151
                echo $this->getAttribute((isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")), "javascript", array());
                echo "
                        </script>
                    ";
            }
            // line 154
            echo "                    ";
            if ( !twig_test_empty($this->getAttribute((isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")), "stylesheet", array()))) {
                // line 155
                echo "                        <style>
                            ";
                // line 156
                echo $this->getAttribute((isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")), "stylesheet", array());
                echo "
                        </style>
                    ";
            }
            // line 159
            echo "                ";
        }
        // line 160
        echo "                ";
        // line 164
        echo "                ";
        echo call_user_func_array($this->env->getFunction('sonata_block_include_stylesheets')->getCallable(), array("screen", $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basePath", array())));
        echo "
                ";
        // line 165
        echo call_user_func_array($this->env->getFunction('sonata_block_include_javascripts')->getCallable(), array("screen", $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "basePath", array())));
        echo "
            ";
        
        $__internal_ae4034b55559d318d36affa340219a6e8a3f9dc27415937232222adf8a6e313e->leave($__internal_ae4034b55559d318d36affa340219a6e8a3f9dc27415937232222adf8a6e313e_prof);

    }

    public function getTemplateName()
    {
        return "ApplicationSonataPageBundle::base_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  560 => 165,  555 => 164,  553 => 160,  550 => 159,  544 => 156,  541 => 155,  538 => 154,  532 => 151,  529 => 150,  526 => 149,  523 => 148,  516 => 147,  509 => 167,  506 => 147,  500 => 146,  489 => 143,  482 => 144,  478 => 143,  472 => 142,  465 => 139,  457 => 133,  449 => 131,  447 => 130,  444 => 129,  441 => 128,  434 => 124,  430 => 123,  426 => 121,  424 => 120,  421 => 119,  415 => 117,  413 => 116,  410 => 115,  403 => 111,  398 => 109,  395 => 108,  393 => 107,  388 => 104,  381 => 102,  378 => 101,  376 => 100,  369 => 98,  366 => 97,  358 => 94,  351 => 93,  349 => 92,  343 => 88,  338 => 85,  327 => 83,  323 => 82,  318 => 80,  315 => 79,  313 => 78,  310 => 77,  307 => 76,  305 => 75,  302 => 74,  294 => 72,  292 => 71,  286 => 67,  277 => 61,  273 => 60,  266 => 55,  264 => 54,  261 => 53,  258 => 52,  251 => 51,  244 => 140,  241 => 51,  235 => 50,  227 => 47,  221 => 46,  214 => 40,  205 => 38,  201 => 37,  194 => 32,  187 => 31,  179 => 41,  176 => 31,  170 => 30,  163 => 27,  154 => 25,  149 => 24,  142 => 23,  135 => 28,  132 => 23,  126 => 22,  118 => 43,  116 => 30,  113 => 29,  111 => 22,  106 => 20,  102 => 19,  95 => 16,  89 => 15,  80 => 13,  77 => 12,  71 => 11,  60 => 168,  58 => 146,  55 => 145,  53 => 142,  50 => 141,  48 => 50,  45 => 49,  43 => 46,  40 => 45,  37 => 15,  35 => 11,);
    }
}
