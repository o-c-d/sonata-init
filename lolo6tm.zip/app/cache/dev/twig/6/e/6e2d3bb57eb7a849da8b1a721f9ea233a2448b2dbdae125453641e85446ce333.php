<?php

/* ApplicationSonataPageBundle::demo_2columns_layout.html.twig */
class __TwigTemplate_6e2d3bb57eb7a849da8b1a721f9ea233a2448b2dbdae125453641e85446ce333 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 11
        $this->parent = $this->loadTemplate("ApplicationSonataPageBundle::2columns_layout.html.twig", "ApplicationSonataPageBundle::demo_2columns_layout.html.twig", 11);
        $this->blocks = array(
            'sonata_page_body_tag' => array($this, 'block_sonata_page_body_tag'),
            'sonata_page_javascripts' => array($this, 'block_sonata_page_javascripts'),
            'sonata_page_container' => array($this, 'block_sonata_page_container'),
            'sonata_page_breadcrumb' => array($this, 'block_sonata_page_breadcrumb'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "ApplicationSonataPageBundle::2columns_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ece8091b8ba85c28ced3c31c0a777b8727c637b0ffd74cfc6f4cd20c0452ad45 = $this->env->getExtension("native_profiler");
        $__internal_ece8091b8ba85c28ced3c31c0a777b8727c637b0ffd74cfc6f4cd20c0452ad45->enter($__internal_ece8091b8ba85c28ced3c31c0a777b8727c637b0ffd74cfc6f4cd20c0452ad45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ApplicationSonataPageBundle::demo_2columns_layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ece8091b8ba85c28ced3c31c0a777b8727c637b0ffd74cfc6f4cd20c0452ad45->leave($__internal_ece8091b8ba85c28ced3c31c0a777b8727c637b0ffd74cfc6f4cd20c0452ad45_prof);

    }

    // line 13
    public function block_sonata_page_body_tag($context, array $blocks = array())
    {
        $__internal_2d85a516736eefd83d49b1be326dc833dd4f101fc0fba920cbfb12930f1018c8 = $this->env->getExtension("native_profiler");
        $__internal_2d85a516736eefd83d49b1be326dc833dd4f101fc0fba920cbfb12930f1018c8->enter($__internal_2d85a516736eefd83d49b1be326dc833dd4f101fc0fba920cbfb12930f1018c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_body_tag"));

        // line 14
        echo "    ";
        $this->displayParentBlock("sonata_page_body_tag", $context, $blocks);
        echo "

    ";
        // line 16
        $this->loadTemplate("SonataSeoBundle:Block:_facebook_sdk.html.twig", "ApplicationSonataPageBundle::demo_2columns_layout.html.twig", 16)->display($context);
        // line 17
        echo "    ";
        $this->loadTemplate("SonataSeoBundle:Block:_twitter_sdk.html.twig", "ApplicationSonataPageBundle::demo_2columns_layout.html.twig", 17)->display($context);
        // line 18
        echo "    ";
        $this->loadTemplate("SonataSeoBundle:Block:_pinterest_sdk.html.twig", "ApplicationSonataPageBundle::demo_2columns_layout.html.twig", 18)->display($context);
        // line 19
        echo "
";
        
        $__internal_2d85a516736eefd83d49b1be326dc833dd4f101fc0fba920cbfb12930f1018c8->leave($__internal_2d85a516736eefd83d49b1be326dc833dd4f101fc0fba920cbfb12930f1018c8_prof);

    }

    // line 22
    public function block_sonata_page_javascripts($context, array $blocks = array())
    {
        $__internal_a7bd4ce5f63fafacac580e049de3272523545ae63ff14001fa2ca0d2581edef5 = $this->env->getExtension("native_profiler");
        $__internal_a7bd4ce5f63fafacac580e049de3272523545ae63ff14001fa2ca0d2581edef5->enter($__internal_a7bd4ce5f63fafacac580e049de3272523545ae63ff14001fa2ca0d2581edef5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_javascripts"));

        // line 23
        echo "    <script type=\"text/javascript\">
        var basket_update_confirmation_message = '";
        // line 24
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("sonata_basket_update_confirmation", array(), "SonataDemoBundle"), "js"), "html", null, true);
        echo "';
    </script>

    <script src=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assetic/sonata_front_js.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
";
        
        $__internal_a7bd4ce5f63fafacac580e049de3272523545ae63ff14001fa2ca0d2581edef5->leave($__internal_a7bd4ce5f63fafacac580e049de3272523545ae63ff14001fa2ca0d2581edef5_prof);

    }

    // line 30
    public function block_sonata_page_container($context, array $blocks = array())
    {
        $__internal_617a16610776d359a516e1d09562df737e3f062085b3f4b2ad0d575e6f5d4ba2 = $this->env->getExtension("native_profiler");
        $__internal_617a16610776d359a516e1d09562df737e3f062085b3f4b2ad0d575e6f5d4ba2->enter($__internal_617a16610776d359a516e1d09562df737e3f062085b3f4b2ad0d575e6f5d4ba2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_container"));

        // line 31
        echo "<!--
    <div class=\"cookies-bar\">";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("sonata.application.cookies.message", array(), "ApplicationSonataPageBundle"), "html", null, true);
        echo "</div>
    <a href=\"https://github.com/sonata-project\"><img style=\"position: absolute; top: 0; right: 0; border: 0;\" src=\"https://s3.amazonaws.com/github/ribbons/forkme_right_green_007200.png\" alt=\"Fork me on GitHub\"></a>
-->
    ";
        // line 35
        $this->displayParentBlock("sonata_page_container", $context, $blocks);
        echo "
";
        
        $__internal_617a16610776d359a516e1d09562df737e3f062085b3f4b2ad0d575e6f5d4ba2->leave($__internal_617a16610776d359a516e1d09562df737e3f062085b3f4b2ad0d575e6f5d4ba2_prof);

    }

    // line 38
    public function block_sonata_page_breadcrumb($context, array $blocks = array())
    {
        $__internal_43acf66ee172ca95b15c67f9acb7775f8dab23b801765b8cc835793ec3257252 = $this->env->getExtension("native_profiler");
        $__internal_43acf66ee172ca95b15c67f9acb7775f8dab23b801765b8cc835793ec3257252->enter($__internal_43acf66ee172ca95b15c67f9acb7775f8dab23b801765b8cc835793ec3257252_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_breadcrumb"));

        
        $__internal_43acf66ee172ca95b15c67f9acb7775f8dab23b801765b8cc835793ec3257252->leave($__internal_43acf66ee172ca95b15c67f9acb7775f8dab23b801765b8cc835793ec3257252_prof);

    }

    public function getTemplateName()
    {
        return "ApplicationSonataPageBundle::demo_2columns_layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  113 => 38,  104 => 35,  98 => 32,  95 => 31,  89 => 30,  80 => 27,  74 => 24,  71 => 23,  65 => 22,  57 => 19,  54 => 18,  51 => 17,  49 => 16,  43 => 14,  37 => 13,  11 => 11,);
    }
}
