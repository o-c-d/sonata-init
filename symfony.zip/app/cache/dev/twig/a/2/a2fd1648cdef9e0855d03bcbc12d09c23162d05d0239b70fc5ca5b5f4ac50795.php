<?php

/* CoreSphereConsoleBundle:Toolbar:toolbar.html.twig */
class __TwigTemplate_a2fd1648cdef9e0855d03bcbc12d09c23162d05d0239b70fc5ca5b5f4ac50795 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("WebProfilerBundle:Profiler:layout.html.twig", "CoreSphereConsoleBundle:Toolbar:toolbar.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "WebProfilerBundle:Profiler:layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_67f4be750f0a10f4137702e33d1fde00aa5d0d9b48f19cbfd47c39cf2e0c0b5c = $this->env->getExtension("native_profiler");
        $__internal_67f4be750f0a10f4137702e33d1fde00aa5d0d9b48f19cbfd47c39cf2e0c0b5c->enter($__internal_67f4be750f0a10f4137702e33d1fde00aa5d0d9b48f19cbfd47c39cf2e0c0b5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CoreSphereConsoleBundle:Toolbar:toolbar.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_67f4be750f0a10f4137702e33d1fde00aa5d0d9b48f19cbfd47c39cf2e0c0b5c->leave($__internal_67f4be750f0a10f4137702e33d1fde00aa5d0d9b48f19cbfd47c39cf2e0c0b5c_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_c65e967ba889ad9ab3a4480aef8e68245ecc15967d697d0f7f32adb7917a5852 = $this->env->getExtension("native_profiler");
        $__internal_c65e967ba889ad9ab3a4480aef8e68245ecc15967d697d0f7f32adb7917a5852->enter($__internal_c65e967ba889ad9ab3a4480aef8e68245ecc15967d697d0f7f32adb7917a5852_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        // line 4
        echo "    ";
        ob_start();
        // line 5
        echo "        <a href=\"";
        echo $this->env->getExtension('routing')->getPath("console");
        echo "\" class=\"coresphere_console_popover\">
            <img width=\"13\" height=\"28\" alt=\"Console\" src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAcCAYAAABh2p9gAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJ
bWFnZVJlYWR5ccllPAAAAG5JREFUeNpi/P//PwM1ARMDlcGogZQDlhMnTlAtmi0sLBip70IkNiOF
rsMwkKGiouL/CE42Bw4cAGOqGejg4AA3mGouRDaYnGSD1YXoFhCyhIVYm4l16UguvmB5keLCAVTk
UNOFjKO13ggwECDAAAMNHZ7ErsJjAAAAAElFTkSuQmCC\"/>
        </a>
    ";
        $context["icon"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 12
        echo "    ";
        $context["text"] = ('' === $tmp = "Console") ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 13
        echo "
    ";
        // line 14
        $this->loadTemplate("WebProfilerBundle:Profiler:toolbar_item.html.twig", "CoreSphereConsoleBundle:Toolbar:toolbar.html.twig", 14)->display(array_merge($context, array("link" => false)));
        
        $__internal_c65e967ba889ad9ab3a4480aef8e68245ecc15967d697d0f7f32adb7917a5852->leave($__internal_c65e967ba889ad9ab3a4480aef8e68245ecc15967d697d0f7f32adb7917a5852_prof);

    }

    public function getTemplateName()
    {
        return "CoreSphereConsoleBundle:Toolbar:toolbar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 14,  57 => 13,  54 => 12,  43 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }
}
