<?php

/* knp_menu_base.html.twig */
class __TwigTemplate_a23af45cf9e9fa71eb69856e04ba94779f65189eff0027e84685c5d2340e15bc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e708f5a88b71292b9c76a93a0343fd8b8527c4b58465a55158b5b72ea3a62ab2 = $this->env->getExtension("native_profiler");
        $__internal_e708f5a88b71292b9c76a93a0343fd8b8527c4b58465a55158b5b72ea3a62ab2->enter($__internal_e708f5a88b71292b9c76a93a0343fd8b8527c4b58465a55158b5b72ea3a62ab2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "knp_menu_base.html.twig"));

        // line 1
        if ($this->getAttribute((isset($context["options"]) ? $context["options"] : $this->getContext($context, "options")), "compressed", array())) {
            $this->displayBlock("compressed_root", $context, $blocks);
        } else {
            $this->displayBlock("root", $context, $blocks);
        }
        
        $__internal_e708f5a88b71292b9c76a93a0343fd8b8527c4b58465a55158b5b72ea3a62ab2->leave($__internal_e708f5a88b71292b9c76a93a0343fd8b8527c4b58465a55158b5b72ea3a62ab2_prof);

    }

    public function getTemplateName()
    {
        return "knp_menu_base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
