<?php

/* SonataAdminBundle:Menu:sonata_menu.html.twig */
class __TwigTemplate_a0d6f2408f0267e0bfbd4ee4292658020aab0ab36149b15ae83691e6941e21d8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("knp_menu.html.twig", "SonataAdminBundle:Menu:sonata_menu.html.twig", 1);
        $this->blocks = array(
            'root' => array($this, 'block_root'),
            'item' => array($this, 'block_item'),
            'linkElement' => array($this, 'block_linkElement'),
            'spanElement' => array($this, 'block_spanElement'),
            'label' => array($this, 'block_label'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "knp_menu.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2131d514f82ae9dbd8590abcc352f722c349a99ce68e2904ba088c02c04b3a5a = $this->env->getExtension("native_profiler");
        $__internal_2131d514f82ae9dbd8590abcc352f722c349a99ce68e2904ba088c02c04b3a5a->enter($__internal_2131d514f82ae9dbd8590abcc352f722c349a99ce68e2904ba088c02c04b3a5a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:Menu:sonata_menu.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2131d514f82ae9dbd8590abcc352f722c349a99ce68e2904ba088c02c04b3a5a->leave($__internal_2131d514f82ae9dbd8590abcc352f722c349a99ce68e2904ba088c02c04b3a5a_prof);

    }

    // line 3
    public function block_root($context, array $blocks = array())
    {
        $__internal_2bbbe2f3b5a9b81832094ac8b2805f546dc4d0dd7d1f2bb7031d0be1b7a33671 = $this->env->getExtension("native_profiler");
        $__internal_2bbbe2f3b5a9b81832094ac8b2805f546dc4d0dd7d1f2bb7031d0be1b7a33671->enter($__internal_2bbbe2f3b5a9b81832094ac8b2805f546dc4d0dd7d1f2bb7031d0be1b7a33671_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "root"));

        // line 4
        $context["listAttributes"] = twig_array_merge($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "childrenAttributes", array()), array("class" => "sidebar-menu"));
        // line 5
        $context["request"] = $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "extra", array(0 => "request"), "method");
        // line 6
        echo "    ";
        $this->displayBlock("list", $context, $blocks);
        
        $__internal_2bbbe2f3b5a9b81832094ac8b2805f546dc4d0dd7d1f2bb7031d0be1b7a33671->leave($__internal_2bbbe2f3b5a9b81832094ac8b2805f546dc4d0dd7d1f2bb7031d0be1b7a33671_prof);

    }

    // line 9
    public function block_item($context, array $blocks = array())
    {
        $__internal_a3fae6937ac845c422d8d728b21b94eed38c5eb7614a5bf27b1f626237511beb = $this->env->getExtension("native_profiler");
        $__internal_a3fae6937ac845c422d8d728b21b94eed38c5eb7614a5bf27b1f626237511beb->enter($__internal_a3fae6937ac845c422d8d728b21b94eed38c5eb7614a5bf27b1f626237511beb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "item"));

        // line 10
        if ($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "displayed", array())) {
            // line 12
            $context["display"] = (twig_test_empty($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "extra", array(0 => "roles"), "method")) || $this->env->getExtension('security')->isGranted("ROLE_SUPER_ADMIN"));
            // line 13
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "extra", array(0 => "roles"), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["role"]) {
                if ( !(isset($context["display"]) ? $context["display"] : $this->getContext($context, "display"))) {
                    // line 14
                    $context["display"] = $this->env->getExtension('security')->isGranted($context["role"]);
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['role'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        // line 18
        if (($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "displayed", array()) && ((array_key_exists("display", $context)) ? (_twig_default_filter((isset($context["display"]) ? $context["display"] : $this->getContext($context, "display")))) : ("")))) {
            // line 19
            $context["active"] = false;
            // line 20
            if (( !twig_test_empty($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "extra", array(0 => "active"), "method")) && $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "extra", array(0 => "active"), "method"))) {
                // line 21
                $context["active"] = true;
            } elseif (((( !twig_test_empty($this->getAttribute(            // line 22
(isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "extra", array(0 => "admin"), "method")) && $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "extra", array(0 => "admin"), "method"), "hasroute", array(0 => "list"), "method")) && $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "extra", array(0 => "admin"), "method"), "isGranted", array(0 => "LIST"), "method")) && ($this->getAttribute((isset($context["request"]) ? $context["request"] : $this->getContext($context, "request")), "get", array(0 => "_sonata_admin"), "method") == $this->getAttribute($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "extra", array(0 => "admin"), "method"), "code", array())))) {
                // line 23
                $context["active"] = true;
            } elseif (($this->getAttribute(            // line 24
(isset($context["item"]) ? $context["item"] : null), "route", array(), "any", true, true) && ($this->getAttribute((isset($context["request"]) ? $context["request"] : $this->getContext($context, "request")), "get", array(0 => "_route"), "method") == $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "route", array())))) {
                // line 25
                $context["active"] = true;
            } else {
                // line 27
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "children", array()));
                foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                    if ( !(isset($context["active"]) ? $context["active"] : $this->getContext($context, "active"))) {
                        // line 28
                        if (((( !twig_test_empty($this->getAttribute($context["child"], "extra", array(0 => "admin"), "method")) && $this->getAttribute($this->getAttribute($context["child"], "extra", array(0 => "admin"), "method"), "hasroute", array(0 => "list"), "method")) && $this->getAttribute($this->getAttribute($context["child"], "extra", array(0 => "admin"), "method"), "isGranted", array(0 => "LIST"), "method")) && ($this->getAttribute((isset($context["request"]) ? $context["request"] : $this->getContext($context, "request")), "get", array(0 => "_sonata_admin"), "method") == $this->getAttribute($this->getAttribute($context["child"], "extra", array(0 => "admin"), "method"), "code", array())))) {
                            // line 29
                            $context["active"] = true;
                        } elseif (($this->getAttribute(                        // line 30
$context["child"], "route", array(), "any", true, true) && ($this->getAttribute((isset($context["request"]) ? $context["request"] : $this->getContext($context, "request")), "get", array(0 => "_route"), "method") == $this->getAttribute($context["child"], "route", array())))) {
                            // line 31
                            $context["active"] = true;
                        }
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
            }
            // line 36
            if ($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "hasChildren", array())) {
                // line 37
                $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "setAttribute", array(0 => "class", 1 => trim(($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "attribute", array(0 => "class"), "method") . " treeview"))), "method");
            }
            // line 39
            if ((isset($context["active"]) ? $context["active"] : $this->getContext($context, "active"))) {
                // line 40
                $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "setAttribute", array(0 => "class", 1 => trim(($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "attribute", array(0 => "class"), "method") . " active"))), "method");
                // line 41
                $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "setChildrenAttribute", array(0 => "class", 1 => trim(($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "childrenAttribute", array(0 => "class"), "method") . " active"))), "method");
            }
            // line 44
            $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "setChildrenAttribute", array(0 => "class", 1 => trim(($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "childrenAttribute", array(0 => "class"), "method") . " treeview-menu"))), "method");
            // line 45
            echo "        ";
            $this->displayParentBlock("item", $context, $blocks);
            echo "
    ";
        }
        
        $__internal_a3fae6937ac845c422d8d728b21b94eed38c5eb7614a5bf27b1f626237511beb->leave($__internal_a3fae6937ac845c422d8d728b21b94eed38c5eb7614a5bf27b1f626237511beb_prof);

    }

    // line 49
    public function block_linkElement($context, array $blocks = array())
    {
        $__internal_edb705f6883ad0b96a560d73359578657749bcfd1511f1ce247e3a66d80b88d9 = $this->env->getExtension("native_profiler");
        $__internal_edb705f6883ad0b96a560d73359578657749bcfd1511f1ce247e3a66d80b88d9->enter($__internal_edb705f6883ad0b96a560d73359578657749bcfd1511f1ce247e3a66d80b88d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "linkElement"));

        // line 50
        echo "    ";
        ob_start();
        // line 51
        echo "        ";
        $context["translation_domain"] = $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "extra", array(0 => "translation_domain", 1 => "messages"), "method");
        // line 52
        echo "        ";
        $context["icon"] = (($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "attribute", array(0 => "icon"), "method", true, true)) ? (_twig_default_filter($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "attribute", array(0 => "icon"), "method"), ((($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "level", array()) > 1)) ? ("<i class=\"fa fa-angle-double-right\"></i>") : ("")))) : (((($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "level", array()) > 1)) ? ("<i class=\"fa fa-angle-double-right\"></i>") : (""))));
        // line 53
        echo "        ";
        $context["is_link"] = true;
        // line 54
        echo "        ";
        $this->displayParentBlock("linkElement", $context, $blocks);
        echo "
    ";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_edb705f6883ad0b96a560d73359578657749bcfd1511f1ce247e3a66d80b88d9->leave($__internal_edb705f6883ad0b96a560d73359578657749bcfd1511f1ce247e3a66d80b88d9_prof);

    }

    // line 58
    public function block_spanElement($context, array $blocks = array())
    {
        $__internal_c046170edd96219ab2dd143cdc82cf59a3f8d6ed4e7d77e3ff29385268cddbea = $this->env->getExtension("native_profiler");
        $__internal_c046170edd96219ab2dd143cdc82cf59a3f8d6ed4e7d77e3ff29385268cddbea->enter($__internal_c046170edd96219ab2dd143cdc82cf59a3f8d6ed4e7d77e3ff29385268cddbea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "spanElement"));

        // line 59
        echo "    ";
        ob_start();
        // line 60
        echo "        <a href=\"#\">
            ";
        // line 61
        $context["translation_domain"] = $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "extra", array(0 => "label_catalogue"), "method");
        // line 62
        echo "            ";
        $context["icon"] = (($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "extra", array(0 => "icon"), "method", true, true)) ? (_twig_default_filter($this->getAttribute((isset($context["item"]) ? $context["item"] : null), "extra", array(0 => "icon"), "method"), "")) : (""));
        // line 63
        echo "            ";
        echo (isset($context["icon"]) ? $context["icon"] : $this->getContext($context, "icon"));
        echo "
            ";
        // line 64
        $this->displayParentBlock("spanElement", $context, $blocks);
        echo "
            <i class=\"fa pull-right fa-angle-left\"></i>
        </a>
    ";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_c046170edd96219ab2dd143cdc82cf59a3f8d6ed4e7d77e3ff29385268cddbea->leave($__internal_c046170edd96219ab2dd143cdc82cf59a3f8d6ed4e7d77e3ff29385268cddbea_prof);

    }

    // line 70
    public function block_label($context, array $blocks = array())
    {
        $__internal_35c353b676fb6c51fa3b98608c1856b2b83879e014e6a7cb0301adec948f796a = $this->env->getExtension("native_profiler");
        $__internal_35c353b676fb6c51fa3b98608c1856b2b83879e014e6a7cb0301adec948f796a->enter($__internal_35c353b676fb6c51fa3b98608c1856b2b83879e014e6a7cb0301adec948f796a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "label"));

        if ((array_key_exists("is_link", $context) && (isset($context["is_link"]) ? $context["is_link"] : $this->getContext($context, "is_link")))) {
            echo ((array_key_exists("icon", $context)) ? (_twig_default_filter((isset($context["icon"]) ? $context["icon"] : $this->getContext($context, "icon")))) : (""));
        }
        if (($this->getAttribute((isset($context["options"]) ? $context["options"] : $this->getContext($context, "options")), "allow_safe_labels", array()) && $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "extra", array(0 => "safe_label", 1 => false), "method"))) {
            echo $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "label", array());
        } else {
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "label", array()), array(), ((array_key_exists("translation_domain", $context)) ? (_twig_default_filter((isset($context["translation_domain"]) ? $context["translation_domain"] : $this->getContext($context, "translation_domain")), "messages")) : ("messages"))), "html", null, true);
        }
        
        $__internal_35c353b676fb6c51fa3b98608c1856b2b83879e014e6a7cb0301adec948f796a->leave($__internal_35c353b676fb6c51fa3b98608c1856b2b83879e014e6a7cb0301adec948f796a_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:Menu:sonata_menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  204 => 70,  192 => 64,  187 => 63,  184 => 62,  182 => 61,  179 => 60,  176 => 59,  170 => 58,  159 => 54,  156 => 53,  153 => 52,  150 => 51,  147 => 50,  141 => 49,  130 => 45,  128 => 44,  125 => 41,  123 => 40,  121 => 39,  118 => 37,  116 => 36,  107 => 31,  105 => 30,  103 => 29,  101 => 28,  96 => 27,  93 => 25,  91 => 24,  89 => 23,  87 => 22,  85 => 21,  83 => 20,  81 => 19,  79 => 18,  71 => 14,  66 => 13,  64 => 12,  62 => 10,  56 => 9,  48 => 6,  46 => 5,  44 => 4,  38 => 3,  11 => 1,);
    }
}
