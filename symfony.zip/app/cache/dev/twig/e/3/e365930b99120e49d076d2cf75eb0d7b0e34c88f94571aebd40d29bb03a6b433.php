<?php

/* OcdCorporateBundle::html5.html.twig */
class __TwigTemplate_e365930b99120e49d076d2cf75eb0d7b0e34c88f94571aebd40d29bb03a6b433 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'all' => array($this, 'block_all'),
            'head_outer' => array($this, 'block_head_outer'),
            'head' => array($this, 'block_head'),
            'head_meta' => array($this, 'block_head_meta'),
            'head_meta_viewport_tag' => array($this, 'block_head_meta_viewport_tag'),
            'head_meta_viewport_tag_content' => array($this, 'block_head_meta_viewport_tag_content'),
            'head_meta_description' => array($this, 'block_head_meta_description'),
            'head_meta_keywords' => array($this, 'block_head_meta_keywords'),
            'head_title' => array($this, 'block_head_title'),
            'head_css' => array($this, 'block_head_css'),
            'head_js' => array($this, 'block_head_js'),
            'body_outer' => array($this, 'block_body_outer'),
            'body' => array($this, 'block_body'),
            'body_chromeframe' => array($this, 'block_body_chromeframe'),
            'body_container' => array($this, 'block_body_container'),
            'body_container_header' => array($this, 'block_body_container_header'),
            'body_container_main' => array($this, 'block_body_container_main'),
            'body_container_footer' => array($this, 'block_body_container_footer'),
            'body_js' => array($this, 'block_body_js'),
            'body_js_analytics' => array($this, 'block_body_js_analytics'),
            'body_js_analytics_extra' => array($this, 'block_body_js_analytics_extra'),
            'body_js_analytics_track' => array($this, 'block_body_js_analytics_track'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0d1cbc9f30049e5c91c1c8b0e8bda24a5c503202080f7287cae35ee790f98a51 = $this->env->getExtension("native_profiler");
        $__internal_0d1cbc9f30049e5c91c1c8b0e8bda24a5c503202080f7287cae35ee790f98a51->enter($__internal_0d1cbc9f30049e5c91c1c8b0e8bda24a5c503202080f7287cae35ee790f98a51_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OcdCorporateBundle::html5.html.twig"));

        // line 1
        $this->displayBlock('all', $context, $blocks);
        
        $__internal_0d1cbc9f30049e5c91c1c8b0e8bda24a5c503202080f7287cae35ee790f98a51->leave($__internal_0d1cbc9f30049e5c91c1c8b0e8bda24a5c503202080f7287cae35ee790f98a51_prof);

    }

    public function block_all($context, array $blocks = array())
    {
        $__internal_4ab5c0d2afff32eeebe7677c7949dd7a64d3325b1b0681266336edbe75219876 = $this->env->getExtension("native_profiler");
        $__internal_4ab5c0d2afff32eeebe7677c7949dd7a64d3325b1b0681266336edbe75219876->enter($__internal_4ab5c0d2afff32eeebe7677c7949dd7a64d3325b1b0681266336edbe75219876_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "all"));

        echo "<!doctype html>
<!--[if lt IE 7]><html class=\"no-js lt-ie9 lt-ie8 lt-ie7 ";
        // line 2
        echo twig_escape_filter($this->env, ((array_key_exists("bp_html_classes", $context)) ? (_twig_default_filter((isset($context["bp_html_classes"]) ? $context["bp_html_classes"] : $this->getContext($context, "bp_html_classes")), "")) : ("")), "html", null, true);
        echo "\" lang=\"";
        echo twig_escape_filter($this->env, ((array_key_exists("bp_language", $context)) ? (_twig_default_filter((isset($context["bp_language"]) ? $context["bp_language"] : $this->getContext($context, "bp_language")), "en")) : ("en")), "html", null, true);
        echo "\" ";
        echo ((array_key_exists("bp_html_attributes", $context)) ? (_twig_default_filter((isset($context["bp_html_attributes"]) ? $context["bp_html_attributes"] : $this->getContext($context, "bp_html_attributes")), "")) : (""));
        echo "><![endif]-->
<!--[if IE 7]><html class=\"no-js lt-ie9 lt-ie8 ";
        // line 3
        echo twig_escape_filter($this->env, ((array_key_exists("bp_html_classes", $context)) ? (_twig_default_filter((isset($context["bp_html_classes"]) ? $context["bp_html_classes"] : $this->getContext($context, "bp_html_classes")), "")) : ("")), "html", null, true);
        echo "\" lang=\"";
        echo twig_escape_filter($this->env, ((array_key_exists("bp_language", $context)) ? (_twig_default_filter((isset($context["bp_language"]) ? $context["bp_language"] : $this->getContext($context, "bp_language")), "en")) : ("en")), "html", null, true);
        echo "\" ";
        echo ((array_key_exists("bp_html_attributes", $context)) ? (_twig_default_filter((isset($context["bp_html_attributes"]) ? $context["bp_html_attributes"] : $this->getContext($context, "bp_html_attributes")), "")) : (""));
        echo "><![endif]-->
<!--[if IE 8]><html class=\"no-js lt-ie9 ";
        // line 4
        echo twig_escape_filter($this->env, ((array_key_exists("bp_html_classes", $context)) ? (_twig_default_filter((isset($context["bp_html_classes"]) ? $context["bp_html_classes"] : $this->getContext($context, "bp_html_classes")), "")) : ("")), "html", null, true);
        echo "\" lang=\"";
        echo twig_escape_filter($this->env, ((array_key_exists("bp_language", $context)) ? (_twig_default_filter((isset($context["bp_language"]) ? $context["bp_language"] : $this->getContext($context, "bp_language")), "en")) : ("en")), "html", null, true);
        echo "\" ";
        echo ((array_key_exists("bp_html_attributes", $context)) ? (_twig_default_filter((isset($context["bp_html_attributes"]) ? $context["bp_html_attributes"] : $this->getContext($context, "bp_html_attributes")), "")) : (""));
        echo "><![endif]-->
<!--[if gt IE 8]><!--><html class=\"no-js ";
        // line 5
        echo twig_escape_filter($this->env, ((array_key_exists("bp_html_classes", $context)) ? (_twig_default_filter((isset($context["bp_html_classes"]) ? $context["bp_html_classes"] : $this->getContext($context, "bp_html_classes")), "")) : ("")), "html", null, true);
        echo "\" lang=\"";
        echo twig_escape_filter($this->env, ((array_key_exists("bp_language", $context)) ? (_twig_default_filter((isset($context["bp_language"]) ? $context["bp_language"] : $this->getContext($context, "bp_language")), "en")) : ("en")), "html", null, true);
        echo "\" ";
        echo ((array_key_exists("bp_html_attributes", $context)) ? (_twig_default_filter((isset($context["bp_html_attributes"]) ? $context["bp_html_attributes"] : $this->getContext($context, "bp_html_attributes")), "")) : (""));
        echo "><!--<![endif]-->
";
        // line 6
        $this->displayBlock('head_outer', $context, $blocks);
        // line 36
        $this->displayBlock('body_outer', $context, $blocks);
        // line 121
        echo "</html>";
        
        $__internal_4ab5c0d2afff32eeebe7677c7949dd7a64d3325b1b0681266336edbe75219876->leave($__internal_4ab5c0d2afff32eeebe7677c7949dd7a64d3325b1b0681266336edbe75219876_prof);

    }

    // line 6
    public function block_head_outer($context, array $blocks = array())
    {
        $__internal_1259dda2ccd8ca6740a2fcb44d5f929e92d21e574e6751feca1b453cf254e45a = $this->env->getExtension("native_profiler");
        $__internal_1259dda2ccd8ca6740a2fcb44d5f929e92d21e574e6751feca1b453cf254e45a->enter($__internal_1259dda2ccd8ca6740a2fcb44d5f929e92d21e574e6751feca1b453cf254e45a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_outer"));

        // line 7
        echo "    <head ";
        echo ((array_key_exists("bp_head_attributes", $context)) ? (_twig_default_filter((isset($context["bp_head_attributes"]) ? $context["bp_head_attributes"] : $this->getContext($context, "bp_head_attributes")), "")) : (""));
        echo ">
        ";
        // line 8
        $this->displayBlock('head', $context, $blocks);
        // line 34
        echo "    </head>
";
        
        $__internal_1259dda2ccd8ca6740a2fcb44d5f929e92d21e574e6751feca1b453cf254e45a->leave($__internal_1259dda2ccd8ca6740a2fcb44d5f929e92d21e574e6751feca1b453cf254e45a_prof);

    }

    // line 8
    public function block_head($context, array $blocks = array())
    {
        $__internal_e3ac5fa296f04ad72353a6a24112998fa7cec751f8cb3802bde31bc2419f8f95 = $this->env->getExtension("native_profiler");
        $__internal_e3ac5fa296f04ad72353a6a24112998fa7cec751f8cb3802bde31bc2419f8f95->enter($__internal_e3ac5fa296f04ad72353a6a24112998fa7cec751f8cb3802bde31bc2419f8f95_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 9
        echo "            ";
        $this->displayBlock('head_meta', $context, $blocks);
        // line 16
        echo "
            <title>";
        // line 17
        $this->displayBlock('head_title', $context, $blocks);
        echo "</title>

            ";
        // line 19
        $this->displayBlock('head_css', $context, $blocks);
        // line 30
        echo "            ";
        $this->displayBlock('head_js', $context, $blocks);
        // line 33
        echo "        ";
        
        $__internal_e3ac5fa296f04ad72353a6a24112998fa7cec751f8cb3802bde31bc2419f8f95->leave($__internal_e3ac5fa296f04ad72353a6a24112998fa7cec751f8cb3802bde31bc2419f8f95_prof);

    }

    // line 9
    public function block_head_meta($context, array $blocks = array())
    {
        $__internal_3c290fc4830e59cf15872c9ff05fc0d6e816dcdccab7faf62f28f3fa4e69004e = $this->env->getExtension("native_profiler");
        $__internal_3c290fc4830e59cf15872c9ff05fc0d6e816dcdccab7faf62f28f3fa4e69004e->enter($__internal_3c290fc4830e59cf15872c9ff05fc0d6e816dcdccab7faf62f28f3fa4e69004e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_meta"));

        // line 10
        echo "                <meta charset=\"utf-8\">
                <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
                ";
        // line 12
        $this->displayBlock('head_meta_viewport_tag', $context, $blocks);
        // line 13
        echo "                <meta name=\"description\" content=\"";
        $this->displayBlock('head_meta_description', $context, $blocks);
        echo "\">
                <meta name=\"keywords\" content=\"";
        // line 14
        $this->displayBlock('head_meta_keywords', $context, $blocks);
        echo "\">
            ";
        
        $__internal_3c290fc4830e59cf15872c9ff05fc0d6e816dcdccab7faf62f28f3fa4e69004e->leave($__internal_3c290fc4830e59cf15872c9ff05fc0d6e816dcdccab7faf62f28f3fa4e69004e_prof);

    }

    // line 12
    public function block_head_meta_viewport_tag($context, array $blocks = array())
    {
        $__internal_69b0dc85dce502cbaf55f7073ffa72cf7bbcf9fc00d9f195d240bf82f7f9b9b4 = $this->env->getExtension("native_profiler");
        $__internal_69b0dc85dce502cbaf55f7073ffa72cf7bbcf9fc00d9f195d240bf82f7f9b9b4->enter($__internal_69b0dc85dce502cbaf55f7073ffa72cf7bbcf9fc00d9f195d240bf82f7f9b9b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_meta_viewport_tag"));

        echo "<meta name=\"viewport\" content=\"";
        $this->displayBlock('head_meta_viewport_tag_content', $context, $blocks);
        echo "\">";
        
        $__internal_69b0dc85dce502cbaf55f7073ffa72cf7bbcf9fc00d9f195d240bf82f7f9b9b4->leave($__internal_69b0dc85dce502cbaf55f7073ffa72cf7bbcf9fc00d9f195d240bf82f7f9b9b4_prof);

    }

    public function block_head_meta_viewport_tag_content($context, array $blocks = array())
    {
        $__internal_be21a29154a49e8c029ba8758769a54fa0720a02caeb497c1ed56bf14012c4ad = $this->env->getExtension("native_profiler");
        $__internal_be21a29154a49e8c029ba8758769a54fa0720a02caeb497c1ed56bf14012c4ad->enter($__internal_be21a29154a49e8c029ba8758769a54fa0720a02caeb497c1ed56bf14012c4ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_meta_viewport_tag_content"));

        echo "width=device-width, initial-scale=1";
        
        $__internal_be21a29154a49e8c029ba8758769a54fa0720a02caeb497c1ed56bf14012c4ad->leave($__internal_be21a29154a49e8c029ba8758769a54fa0720a02caeb497c1ed56bf14012c4ad_prof);

    }

    // line 13
    public function block_head_meta_description($context, array $blocks = array())
    {
        $__internal_622816e6bd551e4516080f2dc7d46f9157fda4a0f89a6f854ae9f72198ea918d = $this->env->getExtension("native_profiler");
        $__internal_622816e6bd551e4516080f2dc7d46f9157fda4a0f89a6f854ae9f72198ea918d->enter($__internal_622816e6bd551e4516080f2dc7d46f9157fda4a0f89a6f854ae9f72198ea918d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_meta_description"));

        
        $__internal_622816e6bd551e4516080f2dc7d46f9157fda4a0f89a6f854ae9f72198ea918d->leave($__internal_622816e6bd551e4516080f2dc7d46f9157fda4a0f89a6f854ae9f72198ea918d_prof);

    }

    // line 14
    public function block_head_meta_keywords($context, array $blocks = array())
    {
        $__internal_bfdadfd56cb258b1a8c9f83e55b2788298c80943e7daba4ee5ab0b8bf14034f3 = $this->env->getExtension("native_profiler");
        $__internal_bfdadfd56cb258b1a8c9f83e55b2788298c80943e7daba4ee5ab0b8bf14034f3->enter($__internal_bfdadfd56cb258b1a8c9f83e55b2788298c80943e7daba4ee5ab0b8bf14034f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_meta_keywords"));

        
        $__internal_bfdadfd56cb258b1a8c9f83e55b2788298c80943e7daba4ee5ab0b8bf14034f3->leave($__internal_bfdadfd56cb258b1a8c9f83e55b2788298c80943e7daba4ee5ab0b8bf14034f3_prof);

    }

    // line 17
    public function block_head_title($context, array $blocks = array())
    {
        $__internal_668ee78698d23828fd2c85c0a4d23110ba6395f68bec42bc2a6ed18f5ebbe363 = $this->env->getExtension("native_profiler");
        $__internal_668ee78698d23828fd2c85c0a4d23110ba6395f68bec42bc2a6ed18f5ebbe363->enter($__internal_668ee78698d23828fd2c85c0a4d23110ba6395f68bec42bc2a6ed18f5ebbe363_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_title"));

        
        $__internal_668ee78698d23828fd2c85c0a4d23110ba6395f68bec42bc2a6ed18f5ebbe363->leave($__internal_668ee78698d23828fd2c85c0a4d23110ba6395f68bec42bc2a6ed18f5ebbe363_prof);

    }

    // line 19
    public function block_head_css($context, array $blocks = array())
    {
        $__internal_07a532454c109aeec63dd54d4e8139a6c856d6b188c3a68a50d78b6073a782e2 = $this->env->getExtension("native_profiler");
        $__internal_07a532454c109aeec63dd54d4e8139a6c856d6b188c3a68a50d78b6073a782e2->enter($__internal_07a532454c109aeec63dd54d4e8139a6c856d6b188c3a68a50d78b6073a782e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_css"));

        // line 20
        echo "\t\t\t\t";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "7fdef9b_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_7fdef9b_0") : $this->env->getExtension('asset')->getAssetUrl("_controller/css/7fdef9b_html5_boilerplate_1.css");
            // line 27
            echo "\t\t\t\t\t<link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" type=\"text/css\" />
\t\t\t\t";
            // asset "7fdef9b_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_7fdef9b_1") : $this->env->getExtension('asset')->getAssetUrl("_controller/css/7fdef9b_bootstrap.min_2.css");
            echo "\t\t\t\t\t<link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" type=\"text/css\" />
\t\t\t\t";
            // asset "7fdef9b_2"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_7fdef9b_2") : $this->env->getExtension('asset')->getAssetUrl("_controller/css/7fdef9b_bootstrap-responsive.min_3.css");
            echo "\t\t\t\t\t<link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" type=\"text/css\" />
\t\t\t\t";
            // asset "7fdef9b_3"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_7fdef9b_3") : $this->env->getExtension('asset')->getAssetUrl("_controller/css/7fdef9b_font-awesome.min_4.css");
            echo "\t\t\t\t\t<link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" type=\"text/css\" />
\t\t\t\t";
            // asset "7fdef9b_4"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_7fdef9b_4") : $this->env->getExtension('asset')->getAssetUrl("_controller/css/7fdef9b_main_layout_5.css");
            echo "\t\t\t\t\t<link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" type=\"text/css\" />
\t\t\t\t";
        } else {
            // asset "7fdef9b"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_7fdef9b") : $this->env->getExtension('asset')->getAssetUrl("_controller/css/7fdef9b.css");
            echo "\t\t\t\t\t<link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" type=\"text/css\" />
\t\t\t\t";
        }
        unset($context["asset_url"]);
        // line 29
        echo "            ";
        
        $__internal_07a532454c109aeec63dd54d4e8139a6c856d6b188c3a68a50d78b6073a782e2->leave($__internal_07a532454c109aeec63dd54d4e8139a6c856d6b188c3a68a50d78b6073a782e2_prof);

    }

    // line 30
    public function block_head_js($context, array $blocks = array())
    {
        $__internal_7242cdadc86ced56c42745d6568b11a8381eec18b51e4a1edbacc4bb0cd13fa4 = $this->env->getExtension("native_profiler");
        $__internal_7242cdadc86ced56c42745d6568b11a8381eec18b51e4a1edbacc4bb0cd13fa4->enter($__internal_7242cdadc86ced56c42745d6568b11a8381eec18b51e4a1edbacc4bb0cd13fa4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_js"));

        // line 31
        echo "\t\t\t\t\t<script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/ocdcorporate/js/modernizr.js"), "html", null, true);
        echo "\"></script>
            ";
        
        $__internal_7242cdadc86ced56c42745d6568b11a8381eec18b51e4a1edbacc4bb0cd13fa4->leave($__internal_7242cdadc86ced56c42745d6568b11a8381eec18b51e4a1edbacc4bb0cd13fa4_prof);

    }

    // line 36
    public function block_body_outer($context, array $blocks = array())
    {
        $__internal_89db3cdb6efbff9f430043b82bd48212c7a2609486e8b817ddfdb6cc9b67afb8 = $this->env->getExtension("native_profiler");
        $__internal_89db3cdb6efbff9f430043b82bd48212c7a2609486e8b817ddfdb6cc9b67afb8->enter($__internal_89db3cdb6efbff9f430043b82bd48212c7a2609486e8b817ddfdb6cc9b67afb8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_outer"));

        // line 37
        echo "    <body ";
        echo ((array_key_exists("bp_body_attributes", $context)) ? (_twig_default_filter((isset($context["bp_body_attributes"]) ? $context["bp_body_attributes"] : $this->getContext($context, "bp_body_attributes")), "")) : (""));
        echo ">
    ";
        // line 38
        $this->displayBlock('body', $context, $blocks);
        // line 119
        echo "    </body>
";
        
        $__internal_89db3cdb6efbff9f430043b82bd48212c7a2609486e8b817ddfdb6cc9b67afb8->leave($__internal_89db3cdb6efbff9f430043b82bd48212c7a2609486e8b817ddfdb6cc9b67afb8_prof);

    }

    // line 38
    public function block_body($context, array $blocks = array())
    {
        $__internal_b9108075b524f818a8938023c93d97d9b322de04f9f51cbc6a5893aa44ee8ba5 = $this->env->getExtension("native_profiler");
        $__internal_b9108075b524f818a8938023c93d97d9b322de04f9f51cbc6a5893aa44ee8ba5->enter($__internal_b9108075b524f818a8938023c93d97d9b322de04f9f51cbc6a5893aa44ee8ba5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 39
        echo "        ";
        $this->displayBlock('body_chromeframe', $context, $blocks);
        // line 44
        echo "        ";
        $this->displayBlock('body_container', $context, $blocks);
        // line 93
        echo "        ";
        $this->displayBlock('body_js', $context, $blocks);
        // line 118
        echo "    ";
        
        $__internal_b9108075b524f818a8938023c93d97d9b322de04f9f51cbc6a5893aa44ee8ba5->leave($__internal_b9108075b524f818a8938023c93d97d9b322de04f9f51cbc6a5893aa44ee8ba5_prof);

    }

    // line 39
    public function block_body_chromeframe($context, array $blocks = array())
    {
        $__internal_b2c65e10426bcc5016c676724439775a8a0118699f3090f59d7cecfe047cf63a = $this->env->getExtension("native_profiler");
        $__internal_b2c65e10426bcc5016c676724439775a8a0118699f3090f59d7cecfe047cf63a->enter($__internal_b2c65e10426bcc5016c676724439775a8a0118699f3090f59d7cecfe047cf63a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_chromeframe"));

        // line 40
        echo "            <!--[if lt IE 7]>
                <p class=\"chromeframe\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> or <a href=\"http://www.google.com/chromeframe/?redirect=true\">activate Google Chrome Frame</a> to improve your experience.</p>
            <![endif]-->
        ";
        
        $__internal_b2c65e10426bcc5016c676724439775a8a0118699f3090f59d7cecfe047cf63a->leave($__internal_b2c65e10426bcc5016c676724439775a8a0118699f3090f59d7cecfe047cf63a_prof);

    }

    // line 44
    public function block_body_container($context, array $blocks = array())
    {
        $__internal_2deb0ef8055c60dca36961ac462913db63f6912a73c344ea5da6158206d9a4a7 = $this->env->getExtension("native_profiler");
        $__internal_2deb0ef8055c60dca36961ac462913db63f6912a73c344ea5da6158206d9a4a7->enter($__internal_2deb0ef8055c60dca36961ac462913db63f6912a73c344ea5da6158206d9a4a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_container"));

        // line 45
        echo "            <div id=\"container\">
                <header id=\"header\">
\t\t\t\t\t<section class=\"logo_container\">
\t\t\t\t\t\t<div class=\"cube\">
\t\t\t\t\t\t\t<figure class=\"front\"><p>O</p></figure>
\t\t\t\t\t\t\t<figure class=\"left\"><p><i class=\"fa fa-qrcode\"></i></p></figure>
\t\t\t\t\t\t\t<figure class=\"right\"><p>C</p></figure>
\t\t\t\t\t\t\t<figure class=\"top\"><p><i class=\"fa fa-cloud\"></i></p></figure>
\t\t\t\t\t\t\t<figure class=\"bottom\"><p><i class=\"fa fa-search\"></i></p></figure>
\t\t\t\t\t\t\t<figure class=\"back\"><p>D</p></figure>
\t\t\t\t\t\t</div>
\t\t\t\t\t</section>
\t\t\t\t\t<section class=\"title_container\">
                        <h1><a href=\"";
        // line 58
        echo $this->env->getExtension('routing')->getUrl("homepage");
        echo "\" title=\"homepage\">Open Code Development</a></h1>
\t\t\t\t\t\t";
        // line 59
        $this->displayBlock('body_container_header', $context, $blocks);
        // line 60
        echo "\t\t\t\t\t</section>
\t\t\t\t\t<div id=\"block_login\">
\t\t\t\t\t\t";
        // line 62
        if ($this->env->getExtension('security')->isGranted("IS_AUTHENTICATED_REMEMBERED")) {
            // line 63
            echo "\t\t\t\t\t\t\t<div id=\"block_login\" class=\"dropdown\">
\t\t\t\t\t\t\t\t<a href=\"";
            // line 64
            echo $this->env->getExtension('routing')->getPath("fos_user_profile_show");
            echo "\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\"><i class=\"fa fa-user\"></i></a>
\t\t\t\t\t\t\t\t<div class=\"dropdown-menu\">
\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t";
            // line 67
            if ($this->env->getExtension('security')->isGranted("ROLE_ADMIN")) {
                // line 68
                echo "\t\t\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t\t\t\t\t<li><a href=\"";
                // line 70
                echo $this->env->getExtension('routing')->getPath("sonata_admin_dashboard");
                echo "\" title=\"Admin\">Admin</i></a></li>
\t\t\t\t\t\t\t\t\t\t\t\t<li><a href=\"";
                // line 71
                echo $this->env->getExtension('routing')->getPath("sonata_user_profile_show");
                echo "\" title=\"Profil\">Profil</a></li>
\t\t\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t\t\t";
            } else {
                // line 75
                echo "\t\t\t\t\t\t\t\t\t\t<p>coucou</p>
\t\t\t\t\t\t\t\t\t";
            }
            // line 77
            echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<a href=\"";
            // line 79
            echo $this->env->getExtension('routing')->getPath("fos_user_security_logout");
            echo "\" title=\"Logout from ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
            echo "\"><i class=\"fa fa-sign-out\"></i></a>
\t\t\t\t\t\t";
        } else {
            // line 81
            echo "\t\t\t\t\t\t\t<a href=\"";
            echo $this->env->getExtension('routing')->getPath("fos_user_security_login");
            echo "\"><i class=\"fa fa-sign-in\"></i></a>
\t\t\t\t\t\t";
        }
        // line 83
        echo "\t\t\t\t\t</div>
                </header>
                <div role=\"main\" class=\"container\">
                    ";
        // line 86
        $this->displayBlock('body_container_main', $context, $blocks);
        // line 87
        echo "                </div>
                <footer>
                    ";
        // line 89
        $this->displayBlock('body_container_footer', $context, $blocks);
        // line 90
        echo "                </footer>
            </div>
        ";
        
        $__internal_2deb0ef8055c60dca36961ac462913db63f6912a73c344ea5da6158206d9a4a7->leave($__internal_2deb0ef8055c60dca36961ac462913db63f6912a73c344ea5da6158206d9a4a7_prof);

    }

    // line 59
    public function block_body_container_header($context, array $blocks = array())
    {
        $__internal_043f9f27b0212a132c1db879d1f8943685ab4a2a569b8848887671ba643d9337 = $this->env->getExtension("native_profiler");
        $__internal_043f9f27b0212a132c1db879d1f8943685ab4a2a569b8848887671ba643d9337->enter($__internal_043f9f27b0212a132c1db879d1f8943685ab4a2a569b8848887671ba643d9337_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_container_header"));

        
        $__internal_043f9f27b0212a132c1db879d1f8943685ab4a2a569b8848887671ba643d9337->leave($__internal_043f9f27b0212a132c1db879d1f8943685ab4a2a569b8848887671ba643d9337_prof);

    }

    // line 86
    public function block_body_container_main($context, array $blocks = array())
    {
        $__internal_6680bf9ed698bf625d2135be33a3535eb4bad3611a7a3f035fc33631ebcc3fd4 = $this->env->getExtension("native_profiler");
        $__internal_6680bf9ed698bf625d2135be33a3535eb4bad3611a7a3f035fc33631ebcc3fd4->enter($__internal_6680bf9ed698bf625d2135be33a3535eb4bad3611a7a3f035fc33631ebcc3fd4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_container_main"));

        
        $__internal_6680bf9ed698bf625d2135be33a3535eb4bad3611a7a3f035fc33631ebcc3fd4->leave($__internal_6680bf9ed698bf625d2135be33a3535eb4bad3611a7a3f035fc33631ebcc3fd4_prof);

    }

    // line 89
    public function block_body_container_footer($context, array $blocks = array())
    {
        $__internal_db1e3ddeb97b6188e71d6b81d252df71875dbd65a104cd5e364afd0435894498 = $this->env->getExtension("native_profiler");
        $__internal_db1e3ddeb97b6188e71d6b81d252df71875dbd65a104cd5e364afd0435894498->enter($__internal_db1e3ddeb97b6188e71d6b81d252df71875dbd65a104cd5e364afd0435894498_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_container_footer"));

        
        $__internal_db1e3ddeb97b6188e71d6b81d252df71875dbd65a104cd5e364afd0435894498->leave($__internal_db1e3ddeb97b6188e71d6b81d252df71875dbd65a104cd5e364afd0435894498_prof);

    }

    // line 93
    public function block_body_js($context, array $blocks = array())
    {
        $__internal_94c6edd9a2c6357a31c35ec055d6a50c3dd17226c5d278160a983feefecc48e2 = $this->env->getExtension("native_profiler");
        $__internal_94c6edd9a2c6357a31c35ec055d6a50c3dd17226c5d278160a983feefecc48e2->enter($__internal_94c6edd9a2c6357a31c35ec055d6a50c3dd17226c5d278160a983feefecc48e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_js"));

        // line 94
        echo "\t\t\t";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "b24e3bf_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_b24e3bf_0") : $this->env->getExtension('asset')->getAssetUrl("_controller/js/b24e3bf_jquery-2.1.4.min_1.js");
            // line 95
            echo "\t\t\t\t<script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
\t\t\t";
        } else {
            // asset "b24e3bf"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_b24e3bf") : $this->env->getExtension('asset')->getAssetUrl("_controller/js/b24e3bf.js");
            echo "\t\t\t\t<script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
\t\t\t";
        }
        unset($context["asset_url"]);
        // line 97
        echo "\t\t\t";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "2f80f34_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_2f80f34_0") : $this->env->getExtension('asset')->getAssetUrl("_controller/js/2f80f34_bootstrap_1.js");
            // line 100
            echo "\t\t\t\t<script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
\t\t\t";
            // asset "2f80f34_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_2f80f34_1") : $this->env->getExtension('asset')->getAssetUrl("_controller/js/2f80f34_corporate_2.js");
            echo "\t\t\t\t<script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
\t\t\t";
        } else {
            // asset "2f80f34"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_2f80f34") : $this->env->getExtension('asset')->getAssetUrl("_controller/js/2f80f34.js");
            echo "\t\t\t\t<script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
\t\t\t";
        }
        unset($context["asset_url"]);
        // line 102
        echo "            ";
        $this->displayBlock('body_js_analytics', $context, $blocks);
        // line 117
        echo "        ";
        
        $__internal_94c6edd9a2c6357a31c35ec055d6a50c3dd17226c5d278160a983feefecc48e2->leave($__internal_94c6edd9a2c6357a31c35ec055d6a50c3dd17226c5d278160a983feefecc48e2_prof);

    }

    // line 102
    public function block_body_js_analytics($context, array $blocks = array())
    {
        $__internal_a267ba8a2c87331c22be31e5d92305ed8b518e9e1dbacf16846c0f4d48208051 = $this->env->getExtension("native_profiler");
        $__internal_a267ba8a2c87331c22be31e5d92305ed8b518e9e1dbacf16846c0f4d48208051->enter($__internal_a267ba8a2c87331c22be31e5d92305ed8b518e9e1dbacf16846c0f4d48208051_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_js_analytics"));

        // line 103
        echo "                ";
        if (((array_key_exists("bp_analytics_id", $context)) ? (_twig_default_filter((isset($context["bp_analytics_id"]) ? $context["bp_analytics_id"] : $this->getContext($context, "bp_analytics_id")), null)) : (null))) {
            // line 104
            echo "                    <script>
                        (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
                        function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
                        e=o.createElement(i);r=o.getElementsByTagName(i)[0];
                        e.src='//www.google-analytics.com/analytics.js';
                        r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
                        var gao=gao||{};
                        ";
            // line 111
            if (((array_key_exists("bp_analytics_domain", $context)) ? (_twig_default_filter((isset($context["bp_analytics_domain"]) ? $context["bp_analytics_domain"] : $this->getContext($context, "bp_analytics_domain")), null)) : (null))) {
                echo "gao.cookieDomain='";
                echo twig_escape_filter($this->env, (isset($context["bp_analytics_domain"]) ? $context["bp_analytics_domain"] : $this->getContext($context, "bp_analytics_domain")), "html", null, true);
                echo "';";
            }
            // line 112
            echo "                        ";
            $this->displayBlock('body_js_analytics_extra', $context, $blocks);
            // line 113
            echo "                        ga('create','";
            echo twig_escape_filter($this->env, (isset($context["bp_analytics_id"]) ? $context["bp_analytics_id"] : $this->getContext($context, "bp_analytics_id")), "html", null, true);
            echo "',gao);";
            $this->displayBlock('body_js_analytics_track', $context, $blocks);
            // line 114
            echo "                    </script>
                ";
        }
        // line 116
        echo "            ";
        
        $__internal_a267ba8a2c87331c22be31e5d92305ed8b518e9e1dbacf16846c0f4d48208051->leave($__internal_a267ba8a2c87331c22be31e5d92305ed8b518e9e1dbacf16846c0f4d48208051_prof);

    }

    // line 112
    public function block_body_js_analytics_extra($context, array $blocks = array())
    {
        $__internal_ac68b7553eadaad05211f56f10c4d6a94e862bf2b1d76351d5f3744db6ac7d91 = $this->env->getExtension("native_profiler");
        $__internal_ac68b7553eadaad05211f56f10c4d6a94e862bf2b1d76351d5f3744db6ac7d91->enter($__internal_ac68b7553eadaad05211f56f10c4d6a94e862bf2b1d76351d5f3744db6ac7d91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_js_analytics_extra"));

        
        $__internal_ac68b7553eadaad05211f56f10c4d6a94e862bf2b1d76351d5f3744db6ac7d91->leave($__internal_ac68b7553eadaad05211f56f10c4d6a94e862bf2b1d76351d5f3744db6ac7d91_prof);

    }

    // line 113
    public function block_body_js_analytics_track($context, array $blocks = array())
    {
        $__internal_faeea91cd735e1ccd4b8709cbe1371b95ca7f1d4ad7065e7210b93fee976c928 = $this->env->getExtension("native_profiler");
        $__internal_faeea91cd735e1ccd4b8709cbe1371b95ca7f1d4ad7065e7210b93fee976c928->enter($__internal_faeea91cd735e1ccd4b8709cbe1371b95ca7f1d4ad7065e7210b93fee976c928_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_js_analytics_track"));

        echo "ga('send','pageview');";
        
        $__internal_faeea91cd735e1ccd4b8709cbe1371b95ca7f1d4ad7065e7210b93fee976c928->leave($__internal_faeea91cd735e1ccd4b8709cbe1371b95ca7f1d4ad7065e7210b93fee976c928_prof);

    }

    public function getTemplateName()
    {
        return "OcdCorporateBundle::html5.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  615 => 113,  604 => 112,  597 => 116,  593 => 114,  588 => 113,  585 => 112,  579 => 111,  570 => 104,  567 => 103,  561 => 102,  554 => 117,  551 => 102,  531 => 100,  526 => 97,  512 => 95,  507 => 94,  501 => 93,  490 => 89,  479 => 86,  468 => 59,  459 => 90,  457 => 89,  453 => 87,  451 => 86,  446 => 83,  440 => 81,  433 => 79,  429 => 77,  425 => 75,  418 => 71,  414 => 70,  410 => 68,  408 => 67,  402 => 64,  399 => 63,  397 => 62,  393 => 60,  391 => 59,  387 => 58,  372 => 45,  366 => 44,  356 => 40,  350 => 39,  343 => 118,  340 => 93,  337 => 44,  334 => 39,  328 => 38,  320 => 119,  318 => 38,  313 => 37,  307 => 36,  297 => 31,  291 => 30,  284 => 29,  246 => 27,  241 => 20,  235 => 19,  224 => 17,  213 => 14,  202 => 13,  177 => 12,  168 => 14,  163 => 13,  161 => 12,  157 => 10,  151 => 9,  144 => 33,  141 => 30,  139 => 19,  134 => 17,  131 => 16,  128 => 9,  122 => 8,  114 => 34,  112 => 8,  107 => 7,  101 => 6,  94 => 121,  92 => 36,  90 => 6,  82 => 5,  74 => 4,  66 => 3,  58 => 2,  44 => 1,);
    }
}
