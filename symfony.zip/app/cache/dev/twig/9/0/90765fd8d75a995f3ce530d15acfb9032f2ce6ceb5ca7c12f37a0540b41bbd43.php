<?php

/* SonataBlockBundle:Block:block_base.html.twig */
class __TwigTemplate_90765fd8d75a995f3ce530d15acfb9032f2ce6ceb5ca7c12f37a0540b41bbd43 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'block' => array($this, 'block_block'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3d802cc755dec2b743be0d6857e6ca5fdef5ec749581ba53886a392a9812bae1 = $this->env->getExtension("native_profiler");
        $__internal_3d802cc755dec2b743be0d6857e6ca5fdef5ec749581ba53886a392a9812bae1->enter($__internal_3d802cc755dec2b743be0d6857e6ca5fdef5ec749581ba53886a392a9812bae1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataBlockBundle:Block:block_base.html.twig"));

        // line 11
        echo "<div id=\"cms-block-";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["block"]) ? $context["block"] : $this->getContext($context, "block")), "id", array()), "html", null, true);
        echo "\" class=\"cms-block cms-block-element\">
    ";
        // line 12
        $this->displayBlock('block', $context, $blocks);
        // line 13
        echo "</div>
";
        
        $__internal_3d802cc755dec2b743be0d6857e6ca5fdef5ec749581ba53886a392a9812bae1->leave($__internal_3d802cc755dec2b743be0d6857e6ca5fdef5ec749581ba53886a392a9812bae1_prof);

    }

    // line 12
    public function block_block($context, array $blocks = array())
    {
        $__internal_31d47ea4cc0d5e1d8b9559336153f19d1a647036ef6d32c27755fc62c5b9ab05 = $this->env->getExtension("native_profiler");
        $__internal_31d47ea4cc0d5e1d8b9559336153f19d1a647036ef6d32c27755fc62c5b9ab05->enter($__internal_31d47ea4cc0d5e1d8b9559336153f19d1a647036ef6d32c27755fc62c5b9ab05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "block"));

        echo "EMPTY CONTENT";
        
        $__internal_31d47ea4cc0d5e1d8b9559336153f19d1a647036ef6d32c27755fc62c5b9ab05->leave($__internal_31d47ea4cc0d5e1d8b9559336153f19d1a647036ef6d32c27755fc62c5b9ab05_prof);

    }

    public function getTemplateName()
    {
        return "SonataBlockBundle:Block:block_base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 12,  30 => 13,  28 => 12,  23 => 11,);
    }
}
