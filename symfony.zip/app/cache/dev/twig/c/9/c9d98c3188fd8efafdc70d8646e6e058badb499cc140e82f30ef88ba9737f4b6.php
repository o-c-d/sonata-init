<?php

/* SonataAdminBundle::standard_layout.html.twig */
class __TwigTemplate_c9d98c3188fd8efafdc70d8646e6e058badb499cc140e82f30ef88ba9737f4b6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'html_attributes' => array($this, 'block_html_attributes'),
            'meta_tags' => array($this, 'block_meta_tags'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
            'sonata_head_title' => array($this, 'block_sonata_head_title'),
            'body_attributes' => array($this, 'block_body_attributes'),
            'sonata_header' => array($this, 'block_sonata_header'),
            'sonata_header_noscript_warning' => array($this, 'block_sonata_header_noscript_warning'),
            'logo' => array($this, 'block_logo'),
            'sonata_nav' => array($this, 'block_sonata_nav'),
            'sonata_breadcrumb' => array($this, 'block_sonata_breadcrumb'),
            'sonata_top_nav_menu' => array($this, 'block_sonata_top_nav_menu'),
            'sonata_wrapper' => array($this, 'block_sonata_wrapper'),
            'sonata_left_side' => array($this, 'block_sonata_left_side'),
            'sonata_side_nav' => array($this, 'block_sonata_side_nav'),
            'sonata_sidebar_search' => array($this, 'block_sonata_sidebar_search'),
            'side_bar_before_nav' => array($this, 'block_side_bar_before_nav'),
            'side_bar_nav' => array($this, 'block_side_bar_nav'),
            'side_bar_after_nav' => array($this, 'block_side_bar_after_nav'),
            'sonata_page_content' => array($this, 'block_sonata_page_content'),
            'sonata_page_content_header' => array($this, 'block_sonata_page_content_header'),
            'sonata_page_content_nav' => array($this, 'block_sonata_page_content_nav'),
            'tab_menu_navbar_header' => array($this, 'block_tab_menu_navbar_header'),
            'sonata_admin_content_actions_wrappers' => array($this, 'block_sonata_admin_content_actions_wrappers'),
            'sonata_admin_content' => array($this, 'block_sonata_admin_content'),
            'notice' => array($this, 'block_notice'),
            'bootlint' => array($this, 'block_bootlint'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_49f6a7038e047f13405ae21ac37aa7895458fba6d31fd1be38afc2beecc9d82d = $this->env->getExtension("native_profiler");
        $__internal_49f6a7038e047f13405ae21ac37aa7895458fba6d31fd1be38afc2beecc9d82d->enter($__internal_49f6a7038e047f13405ae21ac37aa7895458fba6d31fd1be38afc2beecc9d82d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle::standard_layout.html.twig"));

        // line 11
        $context["_preview"] = $this->renderBlock("preview", $context, $blocks);
        // line 12
        $context["_form"] = $this->renderBlock("form", $context, $blocks);
        // line 13
        $context["_show"] = $this->renderBlock("show", $context, $blocks);
        // line 14
        $context["_list_table"] = $this->renderBlock("list_table", $context, $blocks);
        // line 15
        $context["_list_filters"] = $this->renderBlock("list_filters", $context, $blocks);
        // line 16
        $context["_tab_menu"] = $this->renderBlock("tab_menu", $context, $blocks);
        // line 17
        $context["_content"] = $this->renderBlock("content", $context, $blocks);
        // line 18
        $context["_title"] = $this->renderBlock("title", $context, $blocks);
        // line 19
        $context["_breadcrumb"] = $this->renderBlock("breadcrumb", $context, $blocks);
        // line 20
        $context["_actions"] = $this->renderBlock("actions", $context, $blocks);
        // line 21
        $context["_navbar_title"] = $this->renderBlock("navbar_title", $context, $blocks);
        // line 22
        $context["_list_filters_actions"] = $this->renderBlock("list_filters_actions", $context, $blocks);
        // line 23
        echo "
<!DOCTYPE html>
<html ";
        // line 25
        $this->displayBlock('html_attributes', $context, $blocks);
        echo ">
    <head>
        ";
        // line 27
        $this->displayBlock('meta_tags', $context, $blocks);
        // line 32
        echo "
        ";
        // line 33
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 40
        echo "
        ";
        // line 41
        $this->displayBlock('javascripts', $context, $blocks);
        // line 83
        echo "
        <title>
        ";
        // line 85
        $this->displayBlock('sonata_head_title', $context, $blocks);
        // line 105
        echo "        </title>
    </head>
    <body ";
        // line 107
        $this->displayBlock('body_attributes', $context, $blocks);
        echo ">

    <div class=\"wrapper\">

        ";
        // line 111
        $this->displayBlock('sonata_header', $context, $blocks);
        // line 196
        echo "
        ";
        // line 197
        $this->displayBlock('sonata_wrapper', $context, $blocks);
        // line 331
        echo "    </div>

    ";
        // line 333
        if ((array_key_exists("admin_pool", $context) && $this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "getOption", array(0 => "use_bootlint"), "method"))) {
            // line 334
            echo "        ";
            $this->displayBlock('bootlint', $context, $blocks);
            // line 340
            echo "    ";
        }
        // line 341
        echo "
    </body>
</html>
";
        
        $__internal_49f6a7038e047f13405ae21ac37aa7895458fba6d31fd1be38afc2beecc9d82d->leave($__internal_49f6a7038e047f13405ae21ac37aa7895458fba6d31fd1be38afc2beecc9d82d_prof);

    }

    // line 25
    public function block_html_attributes($context, array $blocks = array())
    {
        $__internal_1b493437b3b75cfed7a0d433e2fda7bd01a0f650679208696342b156b6eac082 = $this->env->getExtension("native_profiler");
        $__internal_1b493437b3b75cfed7a0d433e2fda7bd01a0f650679208696342b156b6eac082->enter($__internal_1b493437b3b75cfed7a0d433e2fda7bd01a0f650679208696342b156b6eac082_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "html_attributes"));

        echo "class=\"no-js\"";
        
        $__internal_1b493437b3b75cfed7a0d433e2fda7bd01a0f650679208696342b156b6eac082->leave($__internal_1b493437b3b75cfed7a0d433e2fda7bd01a0f650679208696342b156b6eac082_prof);

    }

    // line 27
    public function block_meta_tags($context, array $blocks = array())
    {
        $__internal_cf37cc487e66fb2bbaa46f328a77c4c859eeed70c5ee631cb8115f2c66386576 = $this->env->getExtension("native_profiler");
        $__internal_cf37cc487e66fb2bbaa46f328a77c4c859eeed70c5ee631cb8115f2c66386576->enter($__internal_cf37cc487e66fb2bbaa46f328a77c4c859eeed70c5ee631cb8115f2c66386576_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "meta_tags"));

        // line 28
        echo "            <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
            <meta charset=\"UTF-8\">
            <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        ";
        
        $__internal_cf37cc487e66fb2bbaa46f328a77c4c859eeed70c5ee631cb8115f2c66386576->leave($__internal_cf37cc487e66fb2bbaa46f328a77c4c859eeed70c5ee631cb8115f2c66386576_prof);

    }

    // line 33
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_055d18c326a3c1155821eaa6f3a3bed350821b89ba46e46c9983845b3c01f2d0 = $this->env->getExtension("native_profiler");
        $__internal_055d18c326a3c1155821eaa6f3a3bed350821b89ba46e46c9983845b3c01f2d0->enter($__internal_055d18c326a3c1155821eaa6f3a3bed350821b89ba46e46c9983845b3c01f2d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 34
        echo "            ";
        if (array_key_exists("admin_pool", $context)) {
            // line 35
            echo "                ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "getOption", array(0 => "stylesheets", 1 => array()), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["stylesheet"]) {
                // line 36
                echo "                        <link rel=\"stylesheet\" href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl($context["stylesheet"]), "html", null, true);
                echo "\">
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['stylesheet'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 38
            echo "            ";
        }
        // line 39
        echo "        ";
        
        $__internal_055d18c326a3c1155821eaa6f3a3bed350821b89ba46e46c9983845b3c01f2d0->leave($__internal_055d18c326a3c1155821eaa6f3a3bed350821b89ba46e46c9983845b3c01f2d0_prof);

    }

    // line 41
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_c1af0213bf916f7d6ca4e31f26c7d437c222d31da9464515a259be6170348804 = $this->env->getExtension("native_profiler");
        $__internal_c1af0213bf916f7d6ca4e31f26c7d437c222d31da9464515a259be6170348804->enter($__internal_c1af0213bf916f7d6ca4e31f26c7d437c222d31da9464515a259be6170348804_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 42
        echo "            <script>
                window.SONATA_CONFIG = {
                    CONFIRM_EXIT: ";
        // line 44
        if ((array_key_exists("admin_pool", $context) && $this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "getOption", array(0 => "confirm_exit"), "method"))) {
            echo "true";
        } else {
            echo "false";
        }
        echo ",
                    USE_SELECT2: ";
        // line 45
        if ((array_key_exists("admin_pool", $context) && $this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "getOption", array(0 => "use_select2"), "method"))) {
            echo "true";
        } else {
            echo "false";
        }
        echo ",
                    USE_ICHECK: ";
        // line 46
        if ((array_key_exists("admin_pool", $context) && $this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "getOption", array(0 => "use_icheck"), "method"))) {
            echo "true";
        } else {
            echo "false";
        }
        echo ",
                    USE_STICKYFORMS: ";
        // line 47
        if ((array_key_exists("admin_pool", $context) && $this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "getOption", array(0 => "use_stickyforms"), "method"))) {
            echo "true";
        } else {
            echo "false";
        }
        // line 48
        echo "                };
                window.SONATA_TRANSLATIONS = {
                    CONFIRM_EXIT:  '";
        // line 50
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("confirm_exit", array(), "SonataAdminBundle"), "js"), "html", null, true);
        echo "'
                };

                // http://getbootstrap.com/getting-started/#support-ie10-width
                if (navigator.userAgent.match(/IEMobile\\/10\\.0/)) {
                    var msViewportStyle = document.createElement('style');
                    msViewportStyle.appendChild(document.createTextNode('@-ms-viewport{width:auto!important}'));
                    document.querySelector('head').appendChild(msViewportStyle);
                }
            </script>

            ";
        // line 61
        if (array_key_exists("admin_pool", $context)) {
            // line 62
            echo "                ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "getOption", array(0 => "javascripts", 1 => array()), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["javascript"]) {
                // line 63
                echo "                    <script src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl($context["javascript"]), "html", null, true);
                echo "\"></script>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['javascript'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 65
            echo "            ";
        }
        // line 66
        echo "
            ";
        // line 67
        $context["locale"] = $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "locale", array());
        // line 68
        echo "            ";
        // line 69
        echo "            ";
        if ((twig_slice($this->env, (isset($context["locale"]) ? $context["locale"] : $this->getContext($context, "locale")), 0, 2) != "en")) {
            // line 70
            echo "                <script src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl((("bundles/sonatacore/vendor/moment/locale/" . strtr((isset($context["locale"]) ? $context["locale"] : $this->getContext($context, "locale")), array("_" => "-"))) . ".js")), "html", null, true);
            echo "\"></script>
            ";
        }
        // line 72
        echo "
            ";
        // line 74
        echo "            ";
        if ((array_key_exists("admin_pool", $context) && $this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "getOption", array(0 => "use_select2"), "method"))) {
            // line 75
            echo "                ";
            if (((isset($context["locale"]) ? $context["locale"] : $this->getContext($context, "locale")) == "pt")) {
                $context["locale"] = "pt_PT";
            }
            // line 76
            echo "
                ";
            // line 78
            echo "                ";
            if ((twig_slice($this->env, (isset($context["locale"]) ? $context["locale"] : $this->getContext($context, "locale")), 0, 2) != "en")) {
                // line 79
                echo "                    <script src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl((("bundles/sonatacore/vendor/select2/select2_locale_" . strtr((isset($context["locale"]) ? $context["locale"] : $this->getContext($context, "locale")), array("_" => "-"))) . ".js")), "html", null, true);
                echo "\"></script>
                ";
            }
            // line 81
            echo "            ";
        }
        // line 82
        echo "        ";
        
        $__internal_c1af0213bf916f7d6ca4e31f26c7d437c222d31da9464515a259be6170348804->leave($__internal_c1af0213bf916f7d6ca4e31f26c7d437c222d31da9464515a259be6170348804_prof);

    }

    // line 85
    public function block_sonata_head_title($context, array $blocks = array())
    {
        $__internal_69fe3fb410e7575be62c0cbcb2add9346bf2cf8dd55afdbd9dd7a8d28a480803 = $this->env->getExtension("native_profiler");
        $__internal_69fe3fb410e7575be62c0cbcb2add9346bf2cf8dd55afdbd9dd7a8d28a480803->enter($__internal_69fe3fb410e7575be62c0cbcb2add9346bf2cf8dd55afdbd9dd7a8d28a480803_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_head_title"));

        // line 86
        echo "            ";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Admin", array(), "SonataAdminBundle"), "html", null, true);
        echo "

            ";
        // line 88
        if ( !twig_test_empty((isset($context["_title"]) ? $context["_title"] : $this->getContext($context, "_title")))) {
            // line 89
            echo "                ";
            echo (isset($context["_title"]) ? $context["_title"] : $this->getContext($context, "_title"));
            echo "
            ";
        } else {
            // line 91
            echo "                ";
            if (array_key_exists("action", $context)) {
                // line 92
                echo "                    -
                    ";
                // line 93
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "breadcrumbs", array(0 => (isset($context["action"]) ? $context["action"] : $this->getContext($context, "action"))), "method"));
                $context['loop'] = array(
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                );
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["menu"]) {
                    // line 94
                    echo "                        ";
                    if ( !$this->getAttribute($context["loop"], "first", array())) {
                        // line 95
                        echo "                            ";
                        if (($this->getAttribute($context["loop"], "index", array()) != 2)) {
                            // line 96
                            echo "                                &gt;
                            ";
                        }
                        // line 98
                        echo "
                            ";
                        // line 99
                        echo twig_escape_filter($this->env, $this->getAttribute($context["menu"], "label", array()), "html", null, true);
                        echo "
                        ";
                    }
                    // line 101
                    echo "                    ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['menu'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 102
                echo "                ";
            }
            // line 103
            echo "            ";
        }
        // line 104
        echo "        ";
        
        $__internal_69fe3fb410e7575be62c0cbcb2add9346bf2cf8dd55afdbd9dd7a8d28a480803->leave($__internal_69fe3fb410e7575be62c0cbcb2add9346bf2cf8dd55afdbd9dd7a8d28a480803_prof);

    }

    // line 107
    public function block_body_attributes($context, array $blocks = array())
    {
        $__internal_42008db4035b50707c27e89f7bb7b75f1e60725ceb5c6588e3f3ca3bb71e7c49 = $this->env->getExtension("native_profiler");
        $__internal_42008db4035b50707c27e89f7bb7b75f1e60725ceb5c6588e3f3ca3bb71e7c49->enter($__internal_42008db4035b50707c27e89f7bb7b75f1e60725ceb5c6588e3f3ca3bb71e7c49_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_attributes"));

        echo "class=\"sonata-bc skin-black fixed\"";
        
        $__internal_42008db4035b50707c27e89f7bb7b75f1e60725ceb5c6588e3f3ca3bb71e7c49->leave($__internal_42008db4035b50707c27e89f7bb7b75f1e60725ceb5c6588e3f3ca3bb71e7c49_prof);

    }

    // line 111
    public function block_sonata_header($context, array $blocks = array())
    {
        $__internal_0d0614c3f28fbea1bb89bb31c16361d477676aba7247434759b88c643827d793 = $this->env->getExtension("native_profiler");
        $__internal_0d0614c3f28fbea1bb89bb31c16361d477676aba7247434759b88c643827d793->enter($__internal_0d0614c3f28fbea1bb89bb31c16361d477676aba7247434759b88c643827d793_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_header"));

        // line 112
        echo "            <header class=\"main-header\">
                ";
        // line 113
        $this->displayBlock('sonata_header_noscript_warning', $context, $blocks);
        // line 120
        echo "                ";
        $this->displayBlock('logo', $context, $blocks);
        // line 134
        echo "                ";
        $this->displayBlock('sonata_nav', $context, $blocks);
        // line 194
        echo "            </header>
        ";
        
        $__internal_0d0614c3f28fbea1bb89bb31c16361d477676aba7247434759b88c643827d793->leave($__internal_0d0614c3f28fbea1bb89bb31c16361d477676aba7247434759b88c643827d793_prof);

    }

    // line 113
    public function block_sonata_header_noscript_warning($context, array $blocks = array())
    {
        $__internal_34cf92458ed69bba777bf5ee8e55eaf2ce2aaaf72bc02cad4fb0a8befc1c2b2d = $this->env->getExtension("native_profiler");
        $__internal_34cf92458ed69bba777bf5ee8e55eaf2ce2aaaf72bc02cad4fb0a8befc1c2b2d->enter($__internal_34cf92458ed69bba777bf5ee8e55eaf2ce2aaaf72bc02cad4fb0a8befc1c2b2d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_header_noscript_warning"));

        // line 114
        echo "                    <noscript>
                        <div class=\"noscript-warning\">
                            ";
        // line 116
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("noscript_warning", array(), "SonataAdminBundle"), "html", null, true);
        echo "
                        </div>
                    </noscript>
                ";
        
        $__internal_34cf92458ed69bba777bf5ee8e55eaf2ce2aaaf72bc02cad4fb0a8befc1c2b2d->leave($__internal_34cf92458ed69bba777bf5ee8e55eaf2ce2aaaf72bc02cad4fb0a8befc1c2b2d_prof);

    }

    // line 120
    public function block_logo($context, array $blocks = array())
    {
        $__internal_8535955cd4a42c6892b96592e7339db458aa028b5081adc0721d0292a039a341 = $this->env->getExtension("native_profiler");
        $__internal_8535955cd4a42c6892b96592e7339db458aa028b5081adc0721d0292a039a341->enter($__internal_8535955cd4a42c6892b96592e7339db458aa028b5081adc0721d0292a039a341_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "logo"));

        // line 121
        echo "                    ";
        if (array_key_exists("admin_pool", $context)) {
            // line 122
            echo "                        ";
            ob_start();
            // line 123
            echo "                            <a class=\"logo\" href=\"";
            echo $this->env->getExtension('routing')->getPath("sonata_admin_dashboard");
            echo "\">
                                ";
            // line 124
            if ((("single_image" == $this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "getOption", array(0 => "title_mode"), "method")) || ("both" == $this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "getOption", array(0 => "title_mode"), "method")))) {
                // line 125
                echo "                                    <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl($this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "titlelogo", array())), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "title", array()), "html", null, true);
                echo "\">
                                ";
            }
            // line 127
            echo "                                ";
            if ((("single_text" == $this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "getOption", array(0 => "title_mode"), "method")) || ("both" == $this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "getOption", array(0 => "title_mode"), "method")))) {
                // line 128
                echo "                                    <span>";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "title", array()), "html", null, true);
                echo "</span>
                                ";
            }
            // line 130
            echo "                            </a>
                        ";
            echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
            // line 132
            echo "                    ";
        }
        // line 133
        echo "                ";
        
        $__internal_8535955cd4a42c6892b96592e7339db458aa028b5081adc0721d0292a039a341->leave($__internal_8535955cd4a42c6892b96592e7339db458aa028b5081adc0721d0292a039a341_prof);

    }

    // line 134
    public function block_sonata_nav($context, array $blocks = array())
    {
        $__internal_bd5446cfa5373362d5f680dd1d352810802bce55ca38230086db9af1b457bdd4 = $this->env->getExtension("native_profiler");
        $__internal_bd5446cfa5373362d5f680dd1d352810802bce55ca38230086db9af1b457bdd4->enter($__internal_bd5446cfa5373362d5f680dd1d352810802bce55ca38230086db9af1b457bdd4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_nav"));

        // line 135
        echo "                    ";
        if (array_key_exists("admin_pool", $context)) {
            // line 136
            echo "                        <nav class=\"navbar navbar-static-top\" role=\"navigation\">
                            <a href=\"#\" class=\"sidebar-toggle\" data-toggle=\"offcanvas\" role=\"button\">
                                <span class=\"sr-only\">Toggle navigation</span>
                            </a>

                            <div class=\"navbar-left\">
                                ";
            // line 142
            $this->displayBlock('sonata_breadcrumb', $context, $blocks);
            // line 169
            echo "                            </div>

                            ";
            // line 171
            $this->displayBlock('sonata_top_nav_menu', $context, $blocks);
            // line 191
            echo "                        </nav>
                    ";
        }
        // line 193
        echo "                ";
        
        $__internal_bd5446cfa5373362d5f680dd1d352810802bce55ca38230086db9af1b457bdd4->leave($__internal_bd5446cfa5373362d5f680dd1d352810802bce55ca38230086db9af1b457bdd4_prof);

    }

    // line 142
    public function block_sonata_breadcrumb($context, array $blocks = array())
    {
        $__internal_84e7724a4bd27bd683f32ae3c3961746c224c29146fde10e70438b7512a21a5d = $this->env->getExtension("native_profiler");
        $__internal_84e7724a4bd27bd683f32ae3c3961746c224c29146fde10e70438b7512a21a5d->enter($__internal_84e7724a4bd27bd683f32ae3c3961746c224c29146fde10e70438b7512a21a5d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_breadcrumb"));

        // line 143
        echo "                                    <div class=\"hidden-xs\">
                                        ";
        // line 144
        if (( !twig_test_empty((isset($context["_breadcrumb"]) ? $context["_breadcrumb"] : $this->getContext($context, "_breadcrumb"))) || array_key_exists("action", $context))) {
            // line 145
            echo "                                            <ol class=\"nav navbar-top-links breadcrumb\">
                                                ";
            // line 146
            if (twig_test_empty((isset($context["_breadcrumb"]) ? $context["_breadcrumb"] : $this->getContext($context, "_breadcrumb")))) {
                // line 147
                echo "                                                    ";
                if (array_key_exists("action", $context)) {
                    // line 148
                    echo "                                                        ";
                    $context['_parent'] = (array) $context;
                    $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "breadcrumbs", array(0 => (isset($context["action"]) ? $context["action"] : $this->getContext($context, "action"))), "method"));
                    $context['loop'] = array(
                      'parent' => $context['_parent'],
                      'index0' => 0,
                      'index'  => 1,
                      'first'  => true,
                    );
                    if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                        $length = count($context['_seq']);
                        $context['loop']['revindex0'] = $length - 1;
                        $context['loop']['revindex'] = $length;
                        $context['loop']['length'] = $length;
                        $context['loop']['last'] = 1 === $length;
                    }
                    foreach ($context['_seq'] as $context["_key"] => $context["menu"]) {
                        // line 149
                        echo "                                                            ";
                        if ( !$this->getAttribute($context["loop"], "last", array())) {
                            // line 150
                            echo "                                                                <li>
                                                                    ";
                            // line 151
                            if ( !twig_test_empty($this->getAttribute($context["menu"], "uri", array()))) {
                                // line 152
                                echo "                                                                        <a href=\"";
                                echo twig_escape_filter($this->env, $this->getAttribute($context["menu"], "uri", array()), "html", null, true);
                                echo "\">";
                                echo $this->getAttribute($context["menu"], "label", array());
                                echo "</a>
                                                                    ";
                            } else {
                                // line 154
                                echo "                                                                        ";
                                echo twig_escape_filter($this->env, $this->getAttribute($context["menu"], "label", array()), "html", null, true);
                                echo "
                                                                    ";
                            }
                            // line 156
                            echo "                                                                </li>
                                                            ";
                        } else {
                            // line 158
                            echo "                                                                <li class=\"active\"><span>";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["menu"], "label", array()), "html", null, true);
                            echo "</span></li>
                                                            ";
                        }
                        // line 160
                        echo "                                                        ";
                        ++$context['loop']['index0'];
                        ++$context['loop']['index'];
                        $context['loop']['first'] = false;
                        if (isset($context['loop']['length'])) {
                            --$context['loop']['revindex0'];
                            --$context['loop']['revindex'];
                            $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                        }
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['menu'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 161
                    echo "                                                    ";
                }
                // line 162
                echo "                                                ";
            } else {
                // line 163
                echo "                                                    ";
                echo (isset($context["_breadcrumb"]) ? $context["_breadcrumb"] : $this->getContext($context, "_breadcrumb"));
                echo "
                                                ";
            }
            // line 165
            echo "                                            </ol>
                                        ";
        }
        // line 167
        echo "                                    </div>
                                ";
        
        $__internal_84e7724a4bd27bd683f32ae3c3961746c224c29146fde10e70438b7512a21a5d->leave($__internal_84e7724a4bd27bd683f32ae3c3961746c224c29146fde10e70438b7512a21a5d_prof);

    }

    // line 171
    public function block_sonata_top_nav_menu($context, array $blocks = array())
    {
        $__internal_337eb41485f555c8dfbe4229b2221836e3d193c873b8ff93039f3071ccf4943c = $this->env->getExtension("native_profiler");
        $__internal_337eb41485f555c8dfbe4229b2221836e3d193c873b8ff93039f3071ccf4943c->enter($__internal_337eb41485f555c8dfbe4229b2221836e3d193c873b8ff93039f3071ccf4943c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_top_nav_menu"));

        // line 172
        echo "                                <div class=\"navbar-custom-menu\">
                                    <ul class=\"nav navbar-nav\">
                                        <li class=\"dropdown\">
                                            <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">
                                                <i class=\"fa fa-plus-square fa-fw\"></i> <i class=\"fa fa-caret-down\"></i>
                                            </a>
                                            ";
        // line 178
        $this->loadTemplate($this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "getTemplate", array(0 => "add_block"), "method"), "SonataAdminBundle::standard_layout.html.twig", 178)->display($context);
        // line 179
        echo "                                        </li>
                                        <li class=\"dropdown user-menu\">
                                            <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">
                                                <i class=\"fa fa-user fa-fw\"></i> <i class=\"fa fa-caret-down\"></i>
                                            </a>
                                            <ul class=\"dropdown-menu dropdown-user\">
                                                ";
        // line 185
        $this->loadTemplate($this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "getTemplate", array(0 => "user_block"), "method"), "SonataAdminBundle::standard_layout.html.twig", 185)->display($context);
        // line 186
        echo "                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            ";
        
        $__internal_337eb41485f555c8dfbe4229b2221836e3d193c873b8ff93039f3071ccf4943c->leave($__internal_337eb41485f555c8dfbe4229b2221836e3d193c873b8ff93039f3071ccf4943c_prof);

    }

    // line 197
    public function block_sonata_wrapper($context, array $blocks = array())
    {
        $__internal_54edc2f576e26a4c59a8fe21e0fc98e3091934d8436f69751e5c2f7485e79d21 = $this->env->getExtension("native_profiler");
        $__internal_54edc2f576e26a4c59a8fe21e0fc98e3091934d8436f69751e5c2f7485e79d21->enter($__internal_54edc2f576e26a4c59a8fe21e0fc98e3091934d8436f69751e5c2f7485e79d21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_wrapper"));

        // line 198
        echo "            ";
        $this->displayBlock('sonata_left_side', $context, $blocks);
        // line 230
        echo "
            <div class=\"content-wrapper\">
                ";
        // line 232
        $this->displayBlock('sonata_page_content', $context, $blocks);
        // line 329
        echo "            </div>
        ";
        
        $__internal_54edc2f576e26a4c59a8fe21e0fc98e3091934d8436f69751e5c2f7485e79d21->leave($__internal_54edc2f576e26a4c59a8fe21e0fc98e3091934d8436f69751e5c2f7485e79d21_prof);

    }

    // line 198
    public function block_sonata_left_side($context, array $blocks = array())
    {
        $__internal_f659c2c4c0713c738f2620d0228c487693a85deaa6b7a0d89a03975d00155133 = $this->env->getExtension("native_profiler");
        $__internal_f659c2c4c0713c738f2620d0228c487693a85deaa6b7a0d89a03975d00155133->enter($__internal_f659c2c4c0713c738f2620d0228c487693a85deaa6b7a0d89a03975d00155133_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_left_side"));

        // line 199
        echo "                <aside class=\"main-sidebar\">
                    <section class=\"sidebar\">
                        ";
        // line 201
        $this->displayBlock('sonata_side_nav', $context, $blocks);
        // line 227
        echo "                    </section>
                </aside>
            ";
        
        $__internal_f659c2c4c0713c738f2620d0228c487693a85deaa6b7a0d89a03975d00155133->leave($__internal_f659c2c4c0713c738f2620d0228c487693a85deaa6b7a0d89a03975d00155133_prof);

    }

    // line 201
    public function block_sonata_side_nav($context, array $blocks = array())
    {
        $__internal_244be7661448eddb7f07517282698c32533fc6638008f54edb4ed961cbcdfc55 = $this->env->getExtension("native_profiler");
        $__internal_244be7661448eddb7f07517282698c32533fc6638008f54edb4ed961cbcdfc55->enter($__internal_244be7661448eddb7f07517282698c32533fc6638008f54edb4ed961cbcdfc55_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_side_nav"));

        // line 202
        echo "                            ";
        $this->displayBlock('sonata_sidebar_search', $context, $blocks);
        // line 216
        echo "
                            ";
        // line 217
        $this->displayBlock('side_bar_before_nav', $context, $blocks);
        // line 218
        echo "                            ";
        $this->displayBlock('side_bar_nav', $context, $blocks);
        // line 223
        echo "                            ";
        $this->displayBlock('side_bar_after_nav', $context, $blocks);
        // line 226
        echo "                        ";
        
        $__internal_244be7661448eddb7f07517282698c32533fc6638008f54edb4ed961cbcdfc55->leave($__internal_244be7661448eddb7f07517282698c32533fc6638008f54edb4ed961cbcdfc55_prof);

    }

    // line 202
    public function block_sonata_sidebar_search($context, array $blocks = array())
    {
        $__internal_6fbf7feecb6acc638aa6193b2c23606c5fffd25679abbeb97dd8ea71f1f14902 = $this->env->getExtension("native_profiler");
        $__internal_6fbf7feecb6acc638aa6193b2c23606c5fffd25679abbeb97dd8ea71f1f14902->enter($__internal_6fbf7feecb6acc638aa6193b2c23606c5fffd25679abbeb97dd8ea71f1f14902_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_sidebar_search"));

        // line 203
        echo "                                ";
        if (($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()) && $this->env->getExtension('security')->isGranted("ROLE_SONATA_ADMIN"))) {
            // line 204
            echo "                                    <form action=\"";
            echo $this->env->getExtension('routing')->getPath("sonata_admin_search");
            echo "\" method=\"GET\" class=\"sidebar-form\" role=\"search\">
                                        <div class=\"input-group custom-search-form\">
                                            <input type=\"text\" name=\"q\" value=\"";
            // line 206
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "get", array(0 => "q"), "method"), "html", null, true);
            echo "\" class=\"form-control\" placeholder=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("search_placeholder", array(), "SonataAdminBundle"), "html", null, true);
            echo "\">
                                                <span class=\"input-group-btn\">
                                                    <button class=\"btn btn-flat\" type=\"submit\">
                                                        <i class=\"fa fa-search\"></i>
                                                    </button>
                                                </span>
                                        </div>
                                    </form>
                                ";
        }
        // line 215
        echo "                            ";
        
        $__internal_6fbf7feecb6acc638aa6193b2c23606c5fffd25679abbeb97dd8ea71f1f14902->leave($__internal_6fbf7feecb6acc638aa6193b2c23606c5fffd25679abbeb97dd8ea71f1f14902_prof);

    }

    // line 217
    public function block_side_bar_before_nav($context, array $blocks = array())
    {
        $__internal_63a76f121f1fd9600d5c9ad911ad1d4bfff8243995b52af08d85a653d2977335 = $this->env->getExtension("native_profiler");
        $__internal_63a76f121f1fd9600d5c9ad911ad1d4bfff8243995b52af08d85a653d2977335->enter($__internal_63a76f121f1fd9600d5c9ad911ad1d4bfff8243995b52af08d85a653d2977335_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "side_bar_before_nav"));

        echo " ";
        
        $__internal_63a76f121f1fd9600d5c9ad911ad1d4bfff8243995b52af08d85a653d2977335->leave($__internal_63a76f121f1fd9600d5c9ad911ad1d4bfff8243995b52af08d85a653d2977335_prof);

    }

    // line 218
    public function block_side_bar_nav($context, array $blocks = array())
    {
        $__internal_5b99ebb71c1cea392e071baf31f011b7553e8f81e40435d1a674007c084b7215 = $this->env->getExtension("native_profiler");
        $__internal_5b99ebb71c1cea392e071baf31f011b7553e8f81e40435d1a674007c084b7215->enter($__internal_5b99ebb71c1cea392e071baf31f011b7553e8f81e40435d1a674007c084b7215_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "side_bar_nav"));

        // line 219
        echo "                                ";
        if (($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()) && $this->env->getExtension('security')->isGranted("ROLE_SONATA_ADMIN"))) {
            // line 220
            echo "                                    ";
            echo $this->env->getExtension('knp_menu')->render("sonata_admin_sidebar", array("template" => $this->getAttribute((isset($context["admin_pool"]) ? $context["admin_pool"] : $this->getContext($context, "admin_pool")), "getTemplate", array(0 => "knp_menu_template"), "method")));
            echo "
                                ";
        }
        // line 222
        echo "                            ";
        
        $__internal_5b99ebb71c1cea392e071baf31f011b7553e8f81e40435d1a674007c084b7215->leave($__internal_5b99ebb71c1cea392e071baf31f011b7553e8f81e40435d1a674007c084b7215_prof);

    }

    // line 223
    public function block_side_bar_after_nav($context, array $blocks = array())
    {
        $__internal_e69716d7aa3a8b41a9e512a5a1802e4662ecb502c1e05d513d6557f5abf202ac = $this->env->getExtension("native_profiler");
        $__internal_e69716d7aa3a8b41a9e512a5a1802e4662ecb502c1e05d513d6557f5abf202ac->enter($__internal_e69716d7aa3a8b41a9e512a5a1802e4662ecb502c1e05d513d6557f5abf202ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "side_bar_after_nav"));

        // line 224
        echo "                                <p class=\"text-center small\" style=\"border-top: 1px solid #444444; padding-top: 10px\"><a href=\"https://sonata-project.org\" rel=\"noreferrer\" target=\"_blank\">sonata project</a></p>
                            ";
        
        $__internal_e69716d7aa3a8b41a9e512a5a1802e4662ecb502c1e05d513d6557f5abf202ac->leave($__internal_e69716d7aa3a8b41a9e512a5a1802e4662ecb502c1e05d513d6557f5abf202ac_prof);

    }

    // line 232
    public function block_sonata_page_content($context, array $blocks = array())
    {
        $__internal_ba0833767d1fa28baa98dcbe34327303c3c28a0ff5cb3d2aea3c653e75c4ecf9 = $this->env->getExtension("native_profiler");
        $__internal_ba0833767d1fa28baa98dcbe34327303c3c28a0ff5cb3d2aea3c653e75c4ecf9->enter($__internal_ba0833767d1fa28baa98dcbe34327303c3c28a0ff5cb3d2aea3c653e75c4ecf9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_content"));

        // line 233
        echo "                    <section class=\"content-header\">

                        ";
        // line 235
        $this->displayBlock('sonata_page_content_header', $context, $blocks);
        // line 289
        echo "                    </section>

                    <section class=\"content\">
                        ";
        // line 292
        $this->displayBlock('sonata_admin_content', $context, $blocks);
        // line 327
        echo "                    </section>
                ";
        
        $__internal_ba0833767d1fa28baa98dcbe34327303c3c28a0ff5cb3d2aea3c653e75c4ecf9->leave($__internal_ba0833767d1fa28baa98dcbe34327303c3c28a0ff5cb3d2aea3c653e75c4ecf9_prof);

    }

    // line 235
    public function block_sonata_page_content_header($context, array $blocks = array())
    {
        $__internal_1378db5b1ca3e285157c6fc6434d654deb9d0d2db9cd71c93c004c30d88f42e6 = $this->env->getExtension("native_profiler");
        $__internal_1378db5b1ca3e285157c6fc6434d654deb9d0d2db9cd71c93c004c30d88f42e6->enter($__internal_1378db5b1ca3e285157c6fc6434d654deb9d0d2db9cd71c93c004c30d88f42e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_content_header"));

        // line 236
        echo "                            ";
        $this->displayBlock('sonata_page_content_nav', $context, $blocks);
        // line 288
        echo "                        ";
        
        $__internal_1378db5b1ca3e285157c6fc6434d654deb9d0d2db9cd71c93c004c30d88f42e6->leave($__internal_1378db5b1ca3e285157c6fc6434d654deb9d0d2db9cd71c93c004c30d88f42e6_prof);

    }

    // line 236
    public function block_sonata_page_content_nav($context, array $blocks = array())
    {
        $__internal_7346f362814414a1e8fa746645360b9afd5bc13069e09d1c41a134a49f74323a = $this->env->getExtension("native_profiler");
        $__internal_7346f362814414a1e8fa746645360b9afd5bc13069e09d1c41a134a49f74323a->enter($__internal_7346f362814414a1e8fa746645360b9afd5bc13069e09d1c41a134a49f74323a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_content_nav"));

        // line 237
        echo "                                ";
        if ((( !twig_test_empty((isset($context["_tab_menu"]) ? $context["_tab_menu"] : $this->getContext($context, "_tab_menu"))) ||  !twig_test_empty((isset($context["_actions"]) ? $context["_actions"] : $this->getContext($context, "_actions")))) ||  !twig_test_empty((isset($context["_list_filters_actions"]) ? $context["_list_filters_actions"] : $this->getContext($context, "_list_filters_actions"))))) {
            // line 238
            echo "                                    <nav class=\"navbar navbar-default\" role=\"navigation\">
                                        <div class=\"container-fluid\">
                                            ";
            // line 240
            $this->displayBlock('tab_menu_navbar_header', $context, $blocks);
            // line 247
            echo "
                                            <div class=\"navbar-collapse\">
                                                <div class=\"navbar-left\">
                                                    ";
            // line 250
            if ( !twig_test_empty((isset($context["_tab_menu"]) ? $context["_tab_menu"] : $this->getContext($context, "_tab_menu")))) {
                // line 251
                echo "                                                        ";
                echo (isset($context["_tab_menu"]) ? $context["_tab_menu"] : $this->getContext($context, "_tab_menu"));
                echo "
                                                    ";
            }
            // line 253
            echo "                                                </div>

                                                ";
            // line 255
            if ((((array_key_exists("admin", $context) && array_key_exists("action", $context)) && ((isset($context["action"]) ? $context["action"] : $this->getContext($context, "action")) == "list")) && (twig_length_filter($this->env, $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "listModes", array())) > 1))) {
                // line 256
                echo "                                                    <div class=\"nav navbar-right btn-group\">
                                                        ";
                // line 257
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "listModes", array()));
                foreach ($context['_seq'] as $context["mode"] => $context["settings"]) {
                    // line 258
                    echo "                                                            <a href=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "generateUrl", array(0 => "list", 1 => twig_array_merge($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "query", array()), "all", array()), array("_list_mode" => $context["mode"]))), "method"), "html", null, true);
                    echo "\" class=\"btn btn-default navbar-btn btn-sm";
                    if (($this->getAttribute((isset($context["admin"]) ? $context["admin"] : $this->getContext($context, "admin")), "getListMode", array(), "method") == $context["mode"])) {
                        echo " active";
                    }
                    echo "\"><i class=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["settings"], "class", array()), "html", null, true);
                    echo "\"></i></a>
                                                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['mode'], $context['settings'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 260
                echo "                                                    </div>
                                                ";
            }
            // line 262
            echo "                                                
                                                ";
            // line 263
            $this->displayBlock('sonata_admin_content_actions_wrappers', $context, $blocks);
            // line 279
            echo "
                                                ";
            // line 280
            if ( !twig_test_empty((isset($context["_list_filters_actions"]) ? $context["_list_filters_actions"] : $this->getContext($context, "_list_filters_actions")))) {
                // line 281
                echo "                                                    ";
                echo (isset($context["_list_filters_actions"]) ? $context["_list_filters_actions"] : $this->getContext($context, "_list_filters_actions"));
                echo "
                                                ";
            }
            // line 283
            echo "                                            </div>
                                        </div>
                                    </nav>
                                ";
        }
        // line 287
        echo "                            ";
        
        $__internal_7346f362814414a1e8fa746645360b9afd5bc13069e09d1c41a134a49f74323a->leave($__internal_7346f362814414a1e8fa746645360b9afd5bc13069e09d1c41a134a49f74323a_prof);

    }

    // line 240
    public function block_tab_menu_navbar_header($context, array $blocks = array())
    {
        $__internal_976aefec0bd87d51f43cb96a27a6c1544dccfc3630460565584f8fdf78c93d50 = $this->env->getExtension("native_profiler");
        $__internal_976aefec0bd87d51f43cb96a27a6c1544dccfc3630460565584f8fdf78c93d50->enter($__internal_976aefec0bd87d51f43cb96a27a6c1544dccfc3630460565584f8fdf78c93d50_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "tab_menu_navbar_header"));

        // line 241
        echo "                                                ";
        if ( !twig_test_empty((isset($context["_navbar_title"]) ? $context["_navbar_title"] : $this->getContext($context, "_navbar_title")))) {
            // line 242
            echo "                                                    <div class=\"navbar-header\">
                                                        <a class=\"navbar-brand\" href=\"#\">";
            // line 243
            echo (isset($context["_navbar_title"]) ? $context["_navbar_title"] : $this->getContext($context, "_navbar_title"));
            echo "</a>
                                                    </div>
                                                ";
        }
        // line 246
        echo "                                            ";
        
        $__internal_976aefec0bd87d51f43cb96a27a6c1544dccfc3630460565584f8fdf78c93d50->leave($__internal_976aefec0bd87d51f43cb96a27a6c1544dccfc3630460565584f8fdf78c93d50_prof);

    }

    // line 263
    public function block_sonata_admin_content_actions_wrappers($context, array $blocks = array())
    {
        $__internal_16b0b154fada79525afab29c5136e9b257a873c18d4fd101a6939f4ed7d70aef = $this->env->getExtension("native_profiler");
        $__internal_16b0b154fada79525afab29c5136e9b257a873c18d4fd101a6939f4ed7d70aef->enter($__internal_16b0b154fada79525afab29c5136e9b257a873c18d4fd101a6939f4ed7d70aef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_admin_content_actions_wrappers"));

        // line 264
        echo "                                                    ";
        if ( !twig_test_empty(trim(strtr((isset($context["_actions"]) ? $context["_actions"] : $this->getContext($context, "_actions")), array("<li>" => "", "</li>" => ""))))) {
            // line 265
            echo "                                                        <ul class=\"nav navbar-nav navbar-right\">
                                                        ";
            // line 266
            if ((twig_length_filter($this->env, twig_split_filter($this->env, (isset($context["_actions"]) ? $context["_actions"] : $this->getContext($context, "_actions")), "</a>")) > 2)) {
                // line 267
                echo "                                                            <li class=\"dropdown sonata-actions\">
                                                                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">";
                // line 268
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("link_actions", array(), "SonataAdminBundle"), "html", null, true);
                echo " <b class=\"caret\"></b></a>
                                                                <ul class=\"dropdown-menu\" role=\"menu\">
                                                                    ";
                // line 270
                echo (isset($context["_actions"]) ? $context["_actions"] : $this->getContext($context, "_actions"));
                echo "
                                                                </ul>
                                                            </li>
                                                        ";
            } else {
                // line 274
                echo "                                                            ";
                echo (isset($context["_actions"]) ? $context["_actions"] : $this->getContext($context, "_actions"));
                echo "
                                                        ";
            }
            // line 276
            echo "                                                        </ul>
                                                    ";
        }
        // line 278
        echo "                                                ";
        
        $__internal_16b0b154fada79525afab29c5136e9b257a873c18d4fd101a6939f4ed7d70aef->leave($__internal_16b0b154fada79525afab29c5136e9b257a873c18d4fd101a6939f4ed7d70aef_prof);

    }

    // line 292
    public function block_sonata_admin_content($context, array $blocks = array())
    {
        $__internal_4cb531a7036b8df96743fe0e32ce30e3e8f3ecfe8749bd33f4a7ea781d2a8b30 = $this->env->getExtension("native_profiler");
        $__internal_4cb531a7036b8df96743fe0e32ce30e3e8f3ecfe8749bd33f4a7ea781d2a8b30->enter($__internal_4cb531a7036b8df96743fe0e32ce30e3e8f3ecfe8749bd33f4a7ea781d2a8b30_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_admin_content"));

        // line 293
        echo "
                            ";
        // line 294
        $this->displayBlock('notice', $context, $blocks);
        // line 297
        echo "
                            ";
        // line 298
        if ( !twig_test_empty((isset($context["_preview"]) ? $context["_preview"] : $this->getContext($context, "_preview")))) {
            // line 299
            echo "                                <div class=\"sonata-ba-preview\">";
            echo (isset($context["_preview"]) ? $context["_preview"] : $this->getContext($context, "_preview"));
            echo "</div>
                            ";
        }
        // line 301
        echo "
                            ";
        // line 302
        if ( !twig_test_empty((isset($context["_content"]) ? $context["_content"] : $this->getContext($context, "_content")))) {
            // line 303
            echo "                                <div class=\"sonata-ba-content\">";
            echo (isset($context["_content"]) ? $context["_content"] : $this->getContext($context, "_content"));
            echo "</div>
                            ";
        }
        // line 305
        echo "
                            ";
        // line 306
        if ( !twig_test_empty((isset($context["_show"]) ? $context["_show"] : $this->getContext($context, "_show")))) {
            // line 307
            echo "                                <div class=\"sonata-ba-show\">";
            echo (isset($context["_show"]) ? $context["_show"] : $this->getContext($context, "_show"));
            echo "</div>
                            ";
        }
        // line 309
        echo "
                            ";
        // line 310
        if ( !twig_test_empty((isset($context["_form"]) ? $context["_form"] : $this->getContext($context, "_form")))) {
            // line 311
            echo "                                <div class=\"sonata-ba-form\">";
            echo (isset($context["_form"]) ? $context["_form"] : $this->getContext($context, "_form"));
            echo "</div>
                            ";
        }
        // line 313
        echo "
                            ";
        // line 314
        if (( !twig_test_empty((isset($context["_list_table"]) ? $context["_list_table"] : $this->getContext($context, "_list_table"))) ||  !twig_test_empty((isset($context["_list_filters"]) ? $context["_list_filters"] : $this->getContext($context, "_list_filters"))))) {
            // line 315
            echo "                                ";
            if (trim((isset($context["_list_filters"]) ? $context["_list_filters"] : $this->getContext($context, "_list_filters")))) {
                // line 316
                echo "                                    <div class=\"row\">
                                        ";
                // line 317
                echo (isset($context["_list_filters"]) ? $context["_list_filters"] : $this->getContext($context, "_list_filters"));
                echo "
                                    </div>
                                ";
            }
            // line 320
            echo "
                                <div class=\"row\">
                                    ";
            // line 322
            echo (isset($context["_list_table"]) ? $context["_list_table"] : $this->getContext($context, "_list_table"));
            echo "
                                </div>

                            ";
        }
        // line 326
        echo "                        ";
        
        $__internal_4cb531a7036b8df96743fe0e32ce30e3e8f3ecfe8749bd33f4a7ea781d2a8b30->leave($__internal_4cb531a7036b8df96743fe0e32ce30e3e8f3ecfe8749bd33f4a7ea781d2a8b30_prof);

    }

    // line 294
    public function block_notice($context, array $blocks = array())
    {
        $__internal_93cefadb16356813c96109b3a878d614eac32088d1d31fc15a53fea9ce2d0467 = $this->env->getExtension("native_profiler");
        $__internal_93cefadb16356813c96109b3a878d614eac32088d1d31fc15a53fea9ce2d0467->enter($__internal_93cefadb16356813c96109b3a878d614eac32088d1d31fc15a53fea9ce2d0467_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "notice"));

        // line 295
        echo "                                ";
        $this->loadTemplate("SonataCoreBundle:FlashMessage:render.html.twig", "SonataAdminBundle::standard_layout.html.twig", 295)->display($context);
        // line 296
        echo "                            ";
        
        $__internal_93cefadb16356813c96109b3a878d614eac32088d1d31fc15a53fea9ce2d0467->leave($__internal_93cefadb16356813c96109b3a878d614eac32088d1d31fc15a53fea9ce2d0467_prof);

    }

    // line 334
    public function block_bootlint($context, array $blocks = array())
    {
        $__internal_262b9a6c9b5e435585515b0174507924e1bc7ef67d220ea5b0ef3a535b267304 = $this->env->getExtension("native_profiler");
        $__internal_262b9a6c9b5e435585515b0174507924e1bc7ef67d220ea5b0ef3a535b267304->enter($__internal_262b9a6c9b5e435585515b0174507924e1bc7ef67d220ea5b0ef3a535b267304_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "bootlint"));

        // line 335
        echo "            ";
        // line 336
        echo "            <script type=\"text/javascript\">
                javascript:(function(){var s=document.createElement(\"script\");s.onload=function(){bootlint.showLintReportForCurrentDocument([], {hasProblems: false, problemFree: false});};s.src=\"https://maxcdn.bootstrapcdn.com/bootlint/latest/bootlint.min.js\";document.body.appendChild(s)})();
            </script>
        ";
        
        $__internal_262b9a6c9b5e435585515b0174507924e1bc7ef67d220ea5b0ef3a535b267304->leave($__internal_262b9a6c9b5e435585515b0174507924e1bc7ef67d220ea5b0ef3a535b267304_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle::standard_layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1175 => 336,  1173 => 335,  1167 => 334,  1160 => 296,  1157 => 295,  1151 => 294,  1144 => 326,  1137 => 322,  1133 => 320,  1127 => 317,  1124 => 316,  1121 => 315,  1119 => 314,  1116 => 313,  1110 => 311,  1108 => 310,  1105 => 309,  1099 => 307,  1097 => 306,  1094 => 305,  1088 => 303,  1086 => 302,  1083 => 301,  1077 => 299,  1075 => 298,  1072 => 297,  1070 => 294,  1067 => 293,  1061 => 292,  1054 => 278,  1050 => 276,  1044 => 274,  1037 => 270,  1032 => 268,  1029 => 267,  1027 => 266,  1024 => 265,  1021 => 264,  1015 => 263,  1008 => 246,  1002 => 243,  999 => 242,  996 => 241,  990 => 240,  983 => 287,  977 => 283,  971 => 281,  969 => 280,  966 => 279,  964 => 263,  961 => 262,  957 => 260,  942 => 258,  938 => 257,  935 => 256,  933 => 255,  929 => 253,  923 => 251,  921 => 250,  916 => 247,  914 => 240,  910 => 238,  907 => 237,  901 => 236,  894 => 288,  891 => 236,  885 => 235,  877 => 327,  875 => 292,  870 => 289,  868 => 235,  864 => 233,  858 => 232,  850 => 224,  844 => 223,  837 => 222,  831 => 220,  828 => 219,  822 => 218,  810 => 217,  803 => 215,  789 => 206,  783 => 204,  780 => 203,  774 => 202,  767 => 226,  764 => 223,  761 => 218,  759 => 217,  756 => 216,  753 => 202,  747 => 201,  738 => 227,  736 => 201,  732 => 199,  726 => 198,  718 => 329,  716 => 232,  712 => 230,  709 => 198,  703 => 197,  692 => 186,  690 => 185,  682 => 179,  680 => 178,  672 => 172,  666 => 171,  658 => 167,  654 => 165,  648 => 163,  645 => 162,  642 => 161,  628 => 160,  622 => 158,  618 => 156,  612 => 154,  604 => 152,  602 => 151,  599 => 150,  596 => 149,  578 => 148,  575 => 147,  573 => 146,  570 => 145,  568 => 144,  565 => 143,  559 => 142,  552 => 193,  548 => 191,  546 => 171,  542 => 169,  540 => 142,  532 => 136,  529 => 135,  523 => 134,  516 => 133,  513 => 132,  509 => 130,  503 => 128,  500 => 127,  492 => 125,  490 => 124,  485 => 123,  482 => 122,  479 => 121,  473 => 120,  462 => 116,  458 => 114,  452 => 113,  444 => 194,  441 => 134,  438 => 120,  436 => 113,  433 => 112,  427 => 111,  415 => 107,  408 => 104,  405 => 103,  402 => 102,  388 => 101,  383 => 99,  380 => 98,  376 => 96,  373 => 95,  370 => 94,  353 => 93,  350 => 92,  347 => 91,  341 => 89,  339 => 88,  333 => 86,  327 => 85,  320 => 82,  317 => 81,  311 => 79,  308 => 78,  305 => 76,  300 => 75,  297 => 74,  294 => 72,  288 => 70,  285 => 69,  283 => 68,  281 => 67,  278 => 66,  275 => 65,  266 => 63,  261 => 62,  259 => 61,  245 => 50,  241 => 48,  235 => 47,  227 => 46,  219 => 45,  211 => 44,  207 => 42,  201 => 41,  194 => 39,  191 => 38,  182 => 36,  177 => 35,  174 => 34,  168 => 33,  158 => 28,  152 => 27,  140 => 25,  130 => 341,  127 => 340,  124 => 334,  122 => 333,  118 => 331,  116 => 197,  113 => 196,  111 => 111,  104 => 107,  100 => 105,  98 => 85,  94 => 83,  92 => 41,  89 => 40,  87 => 33,  84 => 32,  82 => 27,  77 => 25,  73 => 23,  71 => 22,  69 => 21,  67 => 20,  65 => 19,  63 => 18,  61 => 17,  59 => 16,  57 => 15,  55 => 14,  53 => 13,  51 => 12,  49 => 11,);
    }
}
