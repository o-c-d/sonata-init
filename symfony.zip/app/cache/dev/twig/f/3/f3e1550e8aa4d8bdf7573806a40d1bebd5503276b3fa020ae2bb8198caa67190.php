<?php

/* OcdCorporateBundle:Home:index.html.twig */
class __TwigTemplate_f3e1550e8aa4d8bdf7573806a40d1bebd5503276b3fa020ae2bb8198caa67190 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("OcdCorporateBundle::html5.html.twig", "OcdCorporateBundle:Home:index.html.twig", 3);
        $this->blocks = array(
            'head_title' => array($this, 'block_head_title'),
            'body_container_header' => array($this, 'block_body_container_header'),
            'body_container_main' => array($this, 'block_body_container_main'),
            'body_container_footer' => array($this, 'block_body_container_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OcdCorporateBundle::html5.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_46a8c97ab680bbaf3f1082f625efebe7ef767d3d18ddf852867efb72c4e96de5 = $this->env->getExtension("native_profiler");
        $__internal_46a8c97ab680bbaf3f1082f625efebe7ef767d3d18ddf852867efb72c4e96de5->enter($__internal_46a8c97ab680bbaf3f1082f625efebe7ef767d3d18ddf852867efb72c4e96de5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OcdCorporateBundle:Home:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_46a8c97ab680bbaf3f1082f625efebe7ef767d3d18ddf852867efb72c4e96de5->leave($__internal_46a8c97ab680bbaf3f1082f625efebe7ef767d3d18ddf852867efb72c4e96de5_prof);

    }

    // line 5
    public function block_head_title($context, array $blocks = array())
    {
        $__internal_479f11fccac70315b0fef8429fe39c574d3ebe3ffebbe20011f28891472dc53d = $this->env->getExtension("native_profiler");
        $__internal_479f11fccac70315b0fef8429fe39c574d3ebe3ffebbe20011f28891472dc53d->enter($__internal_479f11fccac70315b0fef8429fe39c574d3ebe3ffebbe20011f28891472dc53d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_title"));

        echo "Open Code Development";
        
        $__internal_479f11fccac70315b0fef8429fe39c574d3ebe3ffebbe20011f28891472dc53d->leave($__internal_479f11fccac70315b0fef8429fe39c574d3ebe3ffebbe20011f28891472dc53d_prof);

    }

    // line 7
    public function block_body_container_header($context, array $blocks = array())
    {
        $__internal_e6c1a963a2a7968256fa8794ee9ff7b3f91533d13729d24751817be148546ecb = $this->env->getExtension("native_profiler");
        $__internal_e6c1a963a2a7968256fa8794ee9ff7b3f91533d13729d24751817be148546ecb->enter($__internal_e6c1a963a2a7968256fa8794ee9ff7b3f91533d13729d24751817be148546ecb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_container_header"));

        // line 8
        echo "\t<h2>Conseil, Stratégie, Dévelopment en communication Web</h2>
";
        
        $__internal_e6c1a963a2a7968256fa8794ee9ff7b3f91533d13729d24751817be148546ecb->leave($__internal_e6c1a963a2a7968256fa8794ee9ff7b3f91533d13729d24751817be148546ecb_prof);

    }

    // line 11
    public function block_body_container_main($context, array $blocks = array())
    {
        $__internal_41e29fa63402edda81d30d250efa066d294c1d61562b4323609cec2d66e5ddc0 = $this->env->getExtension("native_profiler");
        $__internal_41e29fa63402edda81d30d250efa066d294c1d61562b4323609cec2d66e5ddc0->enter($__internal_41e29fa63402edda81d30d250efa066d294c1d61562b4323609cec2d66e5ddc0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_container_main"));

        // line 12
        echo "\t<h1>Agence de communication pour TPE</h1>
    <p>Bientôt disponible !</p>

";
        
        $__internal_41e29fa63402edda81d30d250efa066d294c1d61562b4323609cec2d66e5ddc0->leave($__internal_41e29fa63402edda81d30d250efa066d294c1d61562b4323609cec2d66e5ddc0_prof);

    }

    // line 18
    public function block_body_container_footer($context, array $blocks = array())
    {
        $__internal_b9b1e0070259665704d40377eade300525e35b21df9b7ae0ba5e88935cddaa1f = $this->env->getExtension("native_profiler");
        $__internal_b9b1e0070259665704d40377eade300525e35b21df9b7ae0ba5e88935cddaa1f->enter($__internal_b9b1e0070259665704d40377eade300525e35b21df9b7ae0ba5e88935cddaa1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_container_footer"));

        // line 19
        echo "    o-c-d copyright 2015
";
        
        $__internal_b9b1e0070259665704d40377eade300525e35b21df9b7ae0ba5e88935cddaa1f->leave($__internal_b9b1e0070259665704d40377eade300525e35b21df9b7ae0ba5e88935cddaa1f_prof);

    }

    public function getTemplateName()
    {
        return "OcdCorporateBundle:Home:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  85 => 19,  79 => 18,  69 => 12,  63 => 11,  55 => 8,  49 => 7,  37 => 5,  11 => 3,);
    }
}
