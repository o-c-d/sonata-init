<?php

/* SonataUserBundle:Profile:action.html.twig */
class __TwigTemplate_b5298ad8d0e7d385777c78a46037133f42fd3d4fc30cc6126af0fcd59ed28f5e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'sonata_page_breadcrumb' => array($this, 'block_sonata_page_breadcrumb'),
            'sonata_profile_title' => array($this, 'block_sonata_profile_title'),
            'sonata_profile_menu' => array($this, 'block_sonata_profile_menu'),
            'sonata_profile_content' => array($this, 'block_sonata_profile_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_04538be06fd0b710fbbd6bf27f3a288b364e7857096df271efc7b7a15c7fb9fa = $this->env->getExtension("native_profiler");
        $__internal_04538be06fd0b710fbbd6bf27f3a288b364e7857096df271efc7b7a15c7fb9fa->enter($__internal_04538be06fd0b710fbbd6bf27f3a288b364e7857096df271efc7b7a15c7fb9fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataUserBundle:Profile:action.html.twig"));

        // line 11
        echo "
";
        // line 12
        $this->displayBlock('sonata_page_breadcrumb', $context, $blocks);
        // line 20
        echo "
<h2>";
        // line 21
        $this->displayBlock('sonata_profile_title', $context, $blocks);
        echo "</h2>

<div class=\"sonata-user-show row row-fluid\">

    <div class=\"span2 col-lg-2\" style=\"padding: 8px 0;\">
        ";
        // line 26
        $this->displayBlock('sonata_profile_menu', $context, $blocks);
        // line 29
        echo "    </div>

    <div class=\"span10 col-lg-10\">
        ";
        // line 32
        $this->loadTemplate("SonataCoreBundle:FlashMessage:render.html.twig", "SonataUserBundle:Profile:action.html.twig", 32)->display($context);
        // line 33
        echo "
        ";
        // line 34
        $this->displayBlock('sonata_profile_content', $context, $blocks);
        // line 35
        echo "    </div>

</div>
";
        
        $__internal_04538be06fd0b710fbbd6bf27f3a288b364e7857096df271efc7b7a15c7fb9fa->leave($__internal_04538be06fd0b710fbbd6bf27f3a288b364e7857096df271efc7b7a15c7fb9fa_prof);

    }

    // line 12
    public function block_sonata_page_breadcrumb($context, array $blocks = array())
    {
        $__internal_3b0152523706858db52c90d1935ea531cb197f2a6fc2646ab2c99476001f6279 = $this->env->getExtension("native_profiler");
        $__internal_3b0152523706858db52c90d1935ea531cb197f2a6fc2646ab2c99476001f6279->enter($__internal_3b0152523706858db52c90d1935ea531cb197f2a6fc2646ab2c99476001f6279_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_breadcrumb"));

        // line 13
        echo "    ";
        if ( !array_key_exists("breadcrumb_context", $context)) {
            // line 14
            echo "        ";
            $context["breadcrumb_context"] = "user_index";
            // line 15
            echo "    ";
        }
        // line 16
        echo "    <div class=\"row-fluid clearfix\">
        ";
        // line 17
        echo call_user_func_array($this->env->getFunction('sonata_block_render_event')->getCallable(), array("breadcrumb", array("context" => (isset($context["breadcrumb_context"]) ? $context["breadcrumb_context"] : $this->getContext($context, "breadcrumb_context")), "current_uri" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "requestUri", array()))));
        echo "
    </div>
";
        
        $__internal_3b0152523706858db52c90d1935ea531cb197f2a6fc2646ab2c99476001f6279->leave($__internal_3b0152523706858db52c90d1935ea531cb197f2a6fc2646ab2c99476001f6279_prof);

    }

    // line 21
    public function block_sonata_profile_title($context, array $blocks = array())
    {
        $__internal_c556ea855db6838dc378046425cf52e2a430253d1f7903a4c00f51fac28d5bb1 = $this->env->getExtension("native_profiler");
        $__internal_c556ea855db6838dc378046425cf52e2a430253d1f7903a4c00f51fac28d5bb1->enter($__internal_c556ea855db6838dc378046425cf52e2a430253d1f7903a4c00f51fac28d5bb1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_profile_title"));

        echo $this->env->getExtension('translator')->getTranslator()->trans("sonata_profile_title", array(), "SonataUserBundle");
        
        $__internal_c556ea855db6838dc378046425cf52e2a430253d1f7903a4c00f51fac28d5bb1->leave($__internal_c556ea855db6838dc378046425cf52e2a430253d1f7903a4c00f51fac28d5bb1_prof);

    }

    // line 26
    public function block_sonata_profile_menu($context, array $blocks = array())
    {
        $__internal_31ece552949aeee25d4edd353295b4965fdbaa528d5a5daaff3140dee7246d25 = $this->env->getExtension("native_profiler");
        $__internal_31ece552949aeee25d4edd353295b4965fdbaa528d5a5daaff3140dee7246d25->enter($__internal_31ece552949aeee25d4edd353295b4965fdbaa528d5a5daaff3140dee7246d25_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_profile_menu"));

        // line 27
        echo "            ";
        echo call_user_func_array($this->env->getFunction('sonata_block_render')->getCallable(), array(array("type" => "sonata.user.block.menu"), array("current_uri" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "requestUri", array()))));
        echo "
        ";
        
        $__internal_31ece552949aeee25d4edd353295b4965fdbaa528d5a5daaff3140dee7246d25->leave($__internal_31ece552949aeee25d4edd353295b4965fdbaa528d5a5daaff3140dee7246d25_prof);

    }

    // line 34
    public function block_sonata_profile_content($context, array $blocks = array())
    {
        $__internal_38ecc36d8326028076ea5484ad249ee41957f8d0d548e85ef4e47cb13ed786f0 = $this->env->getExtension("native_profiler");
        $__internal_38ecc36d8326028076ea5484ad249ee41957f8d0d548e85ef4e47cb13ed786f0->enter($__internal_38ecc36d8326028076ea5484ad249ee41957f8d0d548e85ef4e47cb13ed786f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_profile_content"));

        echo "";
        
        $__internal_38ecc36d8326028076ea5484ad249ee41957f8d0d548e85ef4e47cb13ed786f0->leave($__internal_38ecc36d8326028076ea5484ad249ee41957f8d0d548e85ef4e47cb13ed786f0_prof);

    }

    public function getTemplateName()
    {
        return "SonataUserBundle:Profile:action.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  122 => 34,  112 => 27,  106 => 26,  94 => 21,  84 => 17,  81 => 16,  78 => 15,  75 => 14,  72 => 13,  66 => 12,  56 => 35,  54 => 34,  51 => 33,  49 => 32,  44 => 29,  42 => 26,  34 => 21,  31 => 20,  29 => 12,  26 => 11,);
    }
}
