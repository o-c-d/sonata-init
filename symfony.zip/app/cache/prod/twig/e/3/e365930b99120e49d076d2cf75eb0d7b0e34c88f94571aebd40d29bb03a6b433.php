<?php

/* OcdCorporateBundle::html5.html.twig */
class __TwigTemplate_e365930b99120e49d076d2cf75eb0d7b0e34c88f94571aebd40d29bb03a6b433 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'all' => array($this, 'block_all'),
            'head_outer' => array($this, 'block_head_outer'),
            'head' => array($this, 'block_head'),
            'head_meta' => array($this, 'block_head_meta'),
            'head_meta_viewport_tag' => array($this, 'block_head_meta_viewport_tag'),
            'head_meta_viewport_tag_content' => array($this, 'block_head_meta_viewport_tag_content'),
            'head_meta_description' => array($this, 'block_head_meta_description'),
            'head_meta_keywords' => array($this, 'block_head_meta_keywords'),
            'head_title' => array($this, 'block_head_title'),
            'head_css' => array($this, 'block_head_css'),
            'head_js' => array($this, 'block_head_js'),
            'body_outer' => array($this, 'block_body_outer'),
            'body' => array($this, 'block_body'),
            'body_chromeframe' => array($this, 'block_body_chromeframe'),
            'body_container' => array($this, 'block_body_container'),
            'body_container_header' => array($this, 'block_body_container_header'),
            'body_container_main' => array($this, 'block_body_container_main'),
            'body_container_footer' => array($this, 'block_body_container_footer'),
            'body_js' => array($this, 'block_body_js'),
            'body_js_analytics' => array($this, 'block_body_js_analytics'),
            'body_js_analytics_extra' => array($this, 'block_body_js_analytics_extra'),
            'body_js_analytics_track' => array($this, 'block_body_js_analytics_track'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $this->displayBlock('all', $context, $blocks);
    }

    public function block_all($context, array $blocks = array())
    {
        echo "<!doctype html>
<!--[if lt IE 7]><html class=\"no-js lt-ie9 lt-ie8 lt-ie7 ";
        // line 2
        echo twig_escape_filter($this->env, ((array_key_exists("bp_html_classes", $context)) ? (_twig_default_filter((isset($context["bp_html_classes"]) ? $context["bp_html_classes"] : null), "")) : ("")), "html", null, true);
        echo "\" lang=\"";
        echo twig_escape_filter($this->env, ((array_key_exists("bp_language", $context)) ? (_twig_default_filter((isset($context["bp_language"]) ? $context["bp_language"] : null), "en")) : ("en")), "html", null, true);
        echo "\" ";
        echo ((array_key_exists("bp_html_attributes", $context)) ? (_twig_default_filter((isset($context["bp_html_attributes"]) ? $context["bp_html_attributes"] : null), "")) : (""));
        echo "><![endif]-->
<!--[if IE 7]><html class=\"no-js lt-ie9 lt-ie8 ";
        // line 3
        echo twig_escape_filter($this->env, ((array_key_exists("bp_html_classes", $context)) ? (_twig_default_filter((isset($context["bp_html_classes"]) ? $context["bp_html_classes"] : null), "")) : ("")), "html", null, true);
        echo "\" lang=\"";
        echo twig_escape_filter($this->env, ((array_key_exists("bp_language", $context)) ? (_twig_default_filter((isset($context["bp_language"]) ? $context["bp_language"] : null), "en")) : ("en")), "html", null, true);
        echo "\" ";
        echo ((array_key_exists("bp_html_attributes", $context)) ? (_twig_default_filter((isset($context["bp_html_attributes"]) ? $context["bp_html_attributes"] : null), "")) : (""));
        echo "><![endif]-->
<!--[if IE 8]><html class=\"no-js lt-ie9 ";
        // line 4
        echo twig_escape_filter($this->env, ((array_key_exists("bp_html_classes", $context)) ? (_twig_default_filter((isset($context["bp_html_classes"]) ? $context["bp_html_classes"] : null), "")) : ("")), "html", null, true);
        echo "\" lang=\"";
        echo twig_escape_filter($this->env, ((array_key_exists("bp_language", $context)) ? (_twig_default_filter((isset($context["bp_language"]) ? $context["bp_language"] : null), "en")) : ("en")), "html", null, true);
        echo "\" ";
        echo ((array_key_exists("bp_html_attributes", $context)) ? (_twig_default_filter((isset($context["bp_html_attributes"]) ? $context["bp_html_attributes"] : null), "")) : (""));
        echo "><![endif]-->
<!--[if gt IE 8]><!--><html class=\"no-js ";
        // line 5
        echo twig_escape_filter($this->env, ((array_key_exists("bp_html_classes", $context)) ? (_twig_default_filter((isset($context["bp_html_classes"]) ? $context["bp_html_classes"] : null), "")) : ("")), "html", null, true);
        echo "\" lang=\"";
        echo twig_escape_filter($this->env, ((array_key_exists("bp_language", $context)) ? (_twig_default_filter((isset($context["bp_language"]) ? $context["bp_language"] : null), "en")) : ("en")), "html", null, true);
        echo "\" ";
        echo ((array_key_exists("bp_html_attributes", $context)) ? (_twig_default_filter((isset($context["bp_html_attributes"]) ? $context["bp_html_attributes"] : null), "")) : (""));
        echo "><!--<![endif]-->
";
        // line 6
        $this->displayBlock('head_outer', $context, $blocks);
        // line 36
        $this->displayBlock('body_outer', $context, $blocks);
        // line 107
        echo "</html>";
    }

    // line 6
    public function block_head_outer($context, array $blocks = array())
    {
        // line 7
        echo "    <head ";
        echo ((array_key_exists("bp_head_attributes", $context)) ? (_twig_default_filter((isset($context["bp_head_attributes"]) ? $context["bp_head_attributes"] : null), "")) : (""));
        echo ">
        ";
        // line 8
        $this->displayBlock('head', $context, $blocks);
        // line 34
        echo "    </head>
";
    }

    // line 8
    public function block_head($context, array $blocks = array())
    {
        // line 9
        echo "            ";
        $this->displayBlock('head_meta', $context, $blocks);
        // line 16
        echo "
            <title>";
        // line 17
        $this->displayBlock('head_title', $context, $blocks);
        echo "</title>

            ";
        // line 19
        $this->displayBlock('head_css', $context, $blocks);
        // line 30
        echo "            ";
        $this->displayBlock('head_js', $context, $blocks);
        // line 33
        echo "        ";
    }

    // line 9
    public function block_head_meta($context, array $blocks = array())
    {
        // line 10
        echo "                <meta charset=\"utf-8\">
                <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
                ";
        // line 12
        $this->displayBlock('head_meta_viewport_tag', $context, $blocks);
        // line 13
        echo "                <meta name=\"description\" content=\"";
        $this->displayBlock('head_meta_description', $context, $blocks);
        echo "\">
                <meta name=\"keywords\" content=\"";
        // line 14
        $this->displayBlock('head_meta_keywords', $context, $blocks);
        echo "\">
            ";
    }

    // line 12
    public function block_head_meta_viewport_tag($context, array $blocks = array())
    {
        echo "<meta name=\"viewport\" content=\"";
        $this->displayBlock('head_meta_viewport_tag_content', $context, $blocks);
        echo "\">";
    }

    public function block_head_meta_viewport_tag_content($context, array $blocks = array())
    {
        echo "width=device-width, initial-scale=1";
    }

    // line 13
    public function block_head_meta_description($context, array $blocks = array())
    {
    }

    // line 14
    public function block_head_meta_keywords($context, array $blocks = array())
    {
    }

    // line 17
    public function block_head_title($context, array $blocks = array())
    {
    }

    // line 19
    public function block_head_css($context, array $blocks = array())
    {
        // line 20
        echo "\t\t\t\t";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "52759dd_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_52759dd_0") : $this->env->getExtension('asset')->getAssetUrl("css/52759dd_html5_boilerplate_1.css");
            // line 27
            echo "\t\t\t\t\t<link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" type=\"text/css\" />
\t\t\t\t";
            // asset "52759dd_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_52759dd_1") : $this->env->getExtension('asset')->getAssetUrl("css/52759dd_bootstrap.min_2.css");
            echo "\t\t\t\t\t<link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" type=\"text/css\" />
\t\t\t\t";
            // asset "52759dd_2"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_52759dd_2") : $this->env->getExtension('asset')->getAssetUrl("css/52759dd_bootstrap-responsive.min_3.css");
            echo "\t\t\t\t\t<link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" type=\"text/css\" />
\t\t\t\t";
            // asset "52759dd_3"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_52759dd_3") : $this->env->getExtension('asset')->getAssetUrl("css/52759dd_font-awesome.min_4.css");
            echo "\t\t\t\t\t<link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" type=\"text/css\" />
\t\t\t\t";
            // asset "52759dd_4"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_52759dd_4") : $this->env->getExtension('asset')->getAssetUrl("css/52759dd_main_layout_5.css");
            echo "\t\t\t\t\t<link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" type=\"text/css\" />
\t\t\t\t";
        } else {
            // asset "52759dd"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_52759dd") : $this->env->getExtension('asset')->getAssetUrl("css/52759dd.css");
            echo "\t\t\t\t\t<link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\" type=\"text/css\" />
\t\t\t\t";
        }
        unset($context["asset_url"]);
        // line 29
        echo "            ";
    }

    // line 30
    public function block_head_js($context, array $blocks = array())
    {
        // line 31
        echo "\t\t\t\t\t<script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/OcdCorporate/js/modernizr.js"), "html", null, true);
        echo "\"></script>
            ";
    }

    // line 36
    public function block_body_outer($context, array $blocks = array())
    {
        // line 37
        echo "    <body ";
        echo ((array_key_exists("bp_body_attributes", $context)) ? (_twig_default_filter((isset($context["bp_body_attributes"]) ? $context["bp_body_attributes"] : null), "")) : (""));
        echo ">
    ";
        // line 38
        $this->displayBlock('body', $context, $blocks);
        // line 105
        echo "    </body>
";
    }

    // line 38
    public function block_body($context, array $blocks = array())
    {
        // line 39
        echo "        ";
        $this->displayBlock('body_chromeframe', $context, $blocks);
        // line 44
        echo "        ";
        $this->displayBlock('body_container', $context, $blocks);
        // line 81
        echo "        ";
        $this->displayBlock('body_js', $context, $blocks);
        // line 104
        echo "    ";
    }

    // line 39
    public function block_body_chromeframe($context, array $blocks = array())
    {
        // line 40
        echo "            <!--[if lt IE 7]>
                <p class=\"chromeframe\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> or <a href=\"http://www.google.com/chromeframe/?redirect=true\">activate Google Chrome Frame</a> to improve your experience.</p>
            <![endif]-->
        ";
    }

    // line 44
    public function block_body_container($context, array $blocks = array())
    {
        // line 45
        echo "            <div id=\"container\">
                <header id=\"header\">
\t\t\t\t\t<section class=\"logo_container\">
\t\t\t\t\t\t<div class=\"cube\">
\t\t\t\t\t\t\t<figure class=\"front\"><p>O</p></figure>
\t\t\t\t\t\t\t<figure class=\"left\"><p><i class=\"fa fa-qrcode\"></i></p></figure>
\t\t\t\t\t\t\t<figure class=\"right\"><p>C</p></figure>
\t\t\t\t\t\t\t<figure class=\"top\"><p><i class=\"fa fa-cloud\"></i></p></figure>
\t\t\t\t\t\t\t<figure class=\"bottom\"><p><i class=\"fa fa-search\"></i></p></figure>
\t\t\t\t\t\t\t<figure class=\"back\"><p>D</p></figure>
\t\t\t\t\t\t</div>
\t\t\t\t\t</section>
\t\t\t\t\t<section class=\"title_container\">
                        <h1><a href=\"";
        // line 58
        echo $this->env->getExtension('routing')->getUrl("homepage");
        echo "\" title=\"homepage\">Open Code Development</a></h1>
\t\t\t\t\t\t";
        // line 59
        $this->displayBlock('body_container_header', $context, $blocks);
        // line 60
        echo "\t\t\t\t\t</section>
\t\t\t\t\t<nav class=\"navbar navbar-inverse page__nav\" role=\"navigation\">
\t\t\t\t\t\t<div class=\"container-fluid\">
\t\t\t\t\t\t\t";
        // line 63
        echo $this->env->getExtension('knp_menu')->render("main", array("template" => "OcdCorporateBundle:Menu:bootstrap.html.twig", "currentClass" => "active"));
        echo "

\t\t\t\t\t\t\t<ul class=\"nav  navbar-nav  navbar-right  navbar--external\">
\t\t\t\t\t\t\t\t<li><a href=\"http://cmf.symfony.com/\">Website</a></li>
\t\t\t\t\t\t\t\t<li><a href=\"http://symfony.com/doc/current/cmf/\">Documentation</a></li>
\t\t\t\t\t\t\t\t<li><a href=\"http://github.com/symfony-cmf\">Github</a></li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t</div>
\t\t\t\t\t</nav>
                </header>
                <div role=\"main\">
                    ";
        // line 74
        $this->displayBlock('body_container_main', $context, $blocks);
        // line 75
        echo "                </div>
                <footer>
                    ";
        // line 77
        $this->displayBlock('body_container_footer', $context, $blocks);
        // line 78
        echo "                </footer>
            </div>
        ";
    }

    // line 59
    public function block_body_container_header($context, array $blocks = array())
    {
    }

    // line 74
    public function block_body_container_main($context, array $blocks = array())
    {
    }

    // line 77
    public function block_body_container_footer($context, array $blocks = array())
    {
    }

    // line 81
    public function block_body_js($context, array $blocks = array())
    {
        // line 82
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "52a3f92_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_52a3f92_0") : $this->env->getExtension('asset')->getAssetUrl("js/52a3f92_jquery-2.1.4.min_1.js");
            // line 86
            echo "    <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\"></script>
";
            // asset "52a3f92_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_52a3f92_1") : $this->env->getExtension('asset')->getAssetUrl("js/52a3f92_bootstrap_2.js");
            echo "    <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\"></script>
";
            // asset "52a3f92_2"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_52a3f92_2") : $this->env->getExtension('asset')->getAssetUrl("js/52a3f92_corporate_3.js");
            echo "    <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\"></script>
";
        } else {
            // asset "52a3f92"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_52a3f92") : $this->env->getExtension('asset')->getAssetUrl("js/52a3f92.js");
            echo "    <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : null), "html", null, true);
            echo "\"></script>
";
        }
        unset($context["asset_url"]);
        // line 88
        echo "            ";
        $this->displayBlock('body_js_analytics', $context, $blocks);
        // line 103
        echo "        ";
    }

    // line 88
    public function block_body_js_analytics($context, array $blocks = array())
    {
        // line 89
        echo "                ";
        if (((array_key_exists("bp_analytics_id", $context)) ? (_twig_default_filter((isset($context["bp_analytics_id"]) ? $context["bp_analytics_id"] : null), null)) : (null))) {
            // line 90
            echo "                    <script>
                        (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
                        function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
                        e=o.createElement(i);r=o.getElementsByTagName(i)[0];
                        e.src='//www.google-analytics.com/analytics.js';
                        r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
                        var gao=gao||{};
                        ";
            // line 97
            if (((array_key_exists("bp_analytics_domain", $context)) ? (_twig_default_filter((isset($context["bp_analytics_domain"]) ? $context["bp_analytics_domain"] : null), null)) : (null))) {
                echo "gao.cookieDomain='";
                echo twig_escape_filter($this->env, (isset($context["bp_analytics_domain"]) ? $context["bp_analytics_domain"] : null), "html", null, true);
                echo "';";
            }
            // line 98
            echo "                        ";
            $this->displayBlock('body_js_analytics_extra', $context, $blocks);
            // line 99
            echo "                        ga('create','";
            echo twig_escape_filter($this->env, (isset($context["bp_analytics_id"]) ? $context["bp_analytics_id"] : null), "html", null, true);
            echo "',gao);";
            $this->displayBlock('body_js_analytics_track', $context, $blocks);
            // line 100
            echo "                    </script>
                ";
        }
        // line 102
        echo "            ";
    }

    // line 98
    public function block_body_js_analytics_extra($context, array $blocks = array())
    {
    }

    // line 99
    public function block_body_js_analytics_track($context, array $blocks = array())
    {
        echo "ga('send','pageview');";
    }

    public function getTemplateName()
    {
        return "OcdCorporateBundle::html5.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  430 => 99,  425 => 98,  421 => 102,  417 => 100,  412 => 99,  409 => 98,  403 => 97,  394 => 90,  391 => 89,  388 => 88,  384 => 103,  381 => 88,  355 => 86,  351 => 82,  348 => 81,  343 => 77,  338 => 74,  333 => 59,  327 => 78,  325 => 77,  321 => 75,  319 => 74,  305 => 63,  300 => 60,  298 => 59,  294 => 58,  279 => 45,  276 => 44,  269 => 40,  266 => 39,  262 => 104,  259 => 81,  256 => 44,  253 => 39,  250 => 38,  245 => 105,  243 => 38,  238 => 37,  235 => 36,  228 => 31,  225 => 30,  221 => 29,  183 => 27,  178 => 20,  175 => 19,  170 => 17,  165 => 14,  160 => 13,  147 => 12,  141 => 14,  136 => 13,  134 => 12,  130 => 10,  127 => 9,  123 => 33,  120 => 30,  118 => 19,  113 => 17,  110 => 16,  107 => 9,  104 => 8,  99 => 34,  97 => 8,  92 => 7,  89 => 6,  85 => 107,  83 => 36,  81 => 6,  73 => 5,  65 => 4,  57 => 3,  49 => 2,  41 => 1,);
    }
}
