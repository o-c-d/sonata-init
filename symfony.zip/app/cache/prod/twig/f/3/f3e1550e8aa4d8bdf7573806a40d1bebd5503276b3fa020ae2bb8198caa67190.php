<?php

/* OcdCorporateBundle:Home:index.html.twig */
class __TwigTemplate_f3e1550e8aa4d8bdf7573806a40d1bebd5503276b3fa020ae2bb8198caa67190 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("OcdCorporateBundle::html5.html.twig", "OcdCorporateBundle:Home:index.html.twig", 3);
        $this->blocks = array(
            'head_title' => array($this, 'block_head_title'),
            'body_container_header' => array($this, 'block_body_container_header'),
            'body_container_main' => array($this, 'block_body_container_main'),
            'body_container_footer' => array($this, 'block_body_container_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OcdCorporateBundle::html5.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_head_title($context, array $blocks = array())
    {
        echo "My cool HTML5 website";
    }

    // line 7
    public function block_body_container_header($context, array $blocks = array())
    {
        // line 8
        echo "\t<h2>Conseil, Stratégie, Dévelopment en communication Web</h2>
";
    }

    // line 11
    public function block_body_container_main($context, array $blocks = array())
    {
        // line 12
        echo "\t<h1>Agence de communication pour TPE</h1>
\t<p>OCD met à la disposition des TPE les outils de communication corporate des grands comptes.</p>
    <p>This is the home page of my wild web site!</p>

";
    }

    // line 19
    public function block_body_container_footer($context, array $blocks = array())
    {
        // line 20
        echo "    o-c-d copyright 2015
";
    }

    public function getTemplateName()
    {
        return "OcdCorporateBundle:Home:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  59 => 20,  56 => 19,  48 => 12,  45 => 11,  40 => 8,  37 => 7,  31 => 5,  11 => 3,);
    }
}
