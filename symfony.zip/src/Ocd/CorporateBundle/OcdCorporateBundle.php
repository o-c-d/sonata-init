<?php

namespace Ocd\CorporateBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OcdCorporateBundle extends Bundle
{
}
