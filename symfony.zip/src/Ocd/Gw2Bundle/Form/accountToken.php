<?php
// src/AppBundle/Form/Type/accountToken.php
namespace Ocd\Gw2Bundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;

class accountToken extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('token_key', null, array('mapped' => false))
            ->add('save', 'submit')
        ;
    }

    public function getName()
    {
        return 'Gw2accountToken';
    }
}