<?php

namespace Ocd\Gw2Bundle\Controller;

use Ocd\Gw2Bundle\Entity\Item;
use Ocd\Gw2Bundle\Library\OcdGw2ApiRequest;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;

class ItemController extends Controller
{
	
    /**
     * @Route("/item/updatelist")
     * @Template("OcdGw2Bundle:Item:updatelist.html.twig")
     */
    public function updatelistAction()
    {
		$api = $this->get('ocd_gw2.apirequest');
		$api_items = $api->listeItemsId();
		$nb_item_api = count($api_items) ;
		$repository = $this->getDoctrine()->getManager()->getRepository('OcdGw2Bundle:Item');
		$nb_item_db = $repository->getCountItems();
		$nb_item_added = 0 ;
		$last_id = $repository->getLastItem() ;
		//$item_to_add = array() ;
		foreach($api_items as $num=>$item_id) {
			if($item_id>$last_id&&$nb_item_added<50) {
				//$item_to_add[]=$item_id;
				$items = $api->getItem($item_id);
				$item = $items[0];
			$db_item = new Item() ;
			$db_item->setItemId($item_id) ;
			if(isset($item->name)) $db_item->setName($item->name) ;
			if(isset($item->icon)) $db_item->setIcon($item->icon) ;
			if(isset($item->description)) $db_item->setDescription($item->description) ;
			if(isset($item->type)) $db_item->setType($item->type) ;
			if(isset($item->rarity)) $db_item->setRarity($item->rarity) ;
			if(isset($item->level)) $db_item->setLevel($item->level) ;
			if(isset($item->vendor_value)) $db_item->setVendorValue($item->vendor_value) ;
			if(isset($item->default_skin)) $db_item->setDefaultSkin($item->default_skin) ;
			if(isset($item->flags)) $db_item->setFlags(serialize($item->flags)) ;
			if(isset($item->game_types)) $db_item->setGameTypes(serialize($item->game_types)) ;
			if(isset($item->restrictions)) $db_item->setRestrictions(serialize($item->restrictions)) ;
			if(isset($item->details)) $db_item->setDetails(serialize($item->details)) ;
			if(isset($item->recipe_id)) $db_item->setRecipeId($item->recipe_id) ;
			$db_item->setTimemaj(time()) ;
			$this->getDoctrine()->getManager()->persist($db_item) ;
				$nb_item_added++;
			}
		}
		// $list_item_to_add = implode(',', $item_to_add) ;
		// $items = $api->getItem($list_item_to_add);
		// foreach($items as $item) {
			// $db_item = new Item() ;
			// $db_item->setItemId($item->id) ;
			// if(isset($item->name)) $db_item->setName($item->name) ;
			// if(isset($item->icon)) $db_item->setIcon($item->icon) ;
			// if(isset($item->description)) $db_item->setDescription($item->description) ;
			// if(isset($item->type)) $db_item->setType($item->type) ;
			// if(isset($item->rarity)) $db_item->setRarity($item->rarity) ;
			// if(isset($item->level)) $db_item->setLevel($item->level) ;
			// if(isset($item->vendor_value)) $db_item->setVendorValue($item->vendor_value) ;
			// if(isset($item->default_skin)) $db_item->setDefaultSkin($item->default_skin) ;
			// if(isset($item->flags)) $db_item->setFlags(serialize($item->flags)) ;
			// if(isset($item->game_types)) $db_item->setGameTypes(serialize($item->game_types)) ;
			// if(isset($item->restrictions)) $db_item->setRestrictions(serialize($item->restrictions)) ;
			// if(isset($item->details)) $db_item->setDetails(serialize($item->details)) ;
			// if(isset($item->recipe_id)) $db_item->setRecipeId($item->recipe_id) ;
			// $db_item->setTimemaj(time()) ;
			// $this->getDoctrine()->getManager()->persist($db_item) ;
			
		// }
			$this->getDoctrine()->getManager()->flush() ;
		
		return array('nb_item_api' => $nb_item_api, 'nb_item_db' => $nb_item_db, 'nb_item_added' => $nb_item_added);
    }
	
    /**
     * @Route("/item/list/{page}", name="item_list")
     * @Template("OcdGw2Bundle:Item:list.html.twig")
     */
    public function listAction($page=1)
    {
        //$max_items_per_page = $this->container->getParameter('max_items_per_page');
		$max_items_per_page = 100 ;
        $articles_count = $this->getDoctrine()->getRepository('OcdGw2Bundle:Item')->getCountItems();
		 $request = $this->get('request');
		 $session = $this->get('session');
		 if ($request->getMethod() == 'POST') {
			$session->set('item_filter_type', $request->get('item_filter_type', ""));
			$session->set('item_filter_rarity', $request->get('item_filter_rarity', ""));
		 }
		 $item_filter_type = $session->get('item_filter_type');
		 $item_filter_rarity = $session->get('item_filter_rarity');
		 $filters = array('type'=>$item_filter_type, 'rarity'=>$item_filter_rarity) ;
        $pagination = array(
            'page' => $page,
            'route' => 'item_list',
            'pages_count' => ceil($articles_count / $max_items_per_page),
            'route_params' => array()
        //    'route_params' => array('type'=>$item_filter_type,'rarity'=>$item_filter_rarity)
        );
         $types = $this->getDoctrine()->getRepository('OcdGw2Bundle:Item')->getTypesList();
         $rarities = $this->getDoctrine()->getRepository('OcdGw2Bundle:Item')->getRaritiesList();
         $items = $this->getDoctrine()->getRepository('OcdGw2Bundle:Item')->getList($page, $max_items_per_page, $filters);
// print_r($types);
        return array('types' => $types, 'rarities' => $rarities, 'items' => $items, 'pagination' => $pagination, 'filters' => $filters);
		// $repository = $this->getDoctrine()->getManager()->getRepository('OcdGw2Bundle:Item');
		// $api = $this->get('ocd_gw2.apirequest');
		// $items = $api->listeItemsId();
		// foreach($items as $item_id) {
			
		// }
		// return array('name' => '', 'items' => $items);
    }
	
    /**
     * @Route("/item/{id}", name="item_view")
     * @Template("OcdGw2Bundle:Item:index.html.twig")
     */
    public function indexAction($id=null)
    {
		if(null == $id) {
			$url = $this->generateUrl('item', array('action'=>'list'));
			return $this->redirect($url);
		} else {
        $item = $this->getDoctrine()->getRepository('OcdGw2Bundle:Item')->findOneBy(array('item_id'=>$id));
		$item->setFlags(unserialize($item->getFlags()));
		$item->setGameTypes(unserialize($item->getGameTypes()));
		$item->setRestrictions(unserialize($item->getRestrictions()));
		$item->setDetails(unserialize($item->getDetails()));
		}
        
		return array('item' => $item);
    }
}
