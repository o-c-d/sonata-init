<?php

namespace Ocd\Gw2Bundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OcdGw2Bundle extends Bundle
{
}
